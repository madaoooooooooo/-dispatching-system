"""Jitsi Meet API 客户端封装

此模块负责生成会议 URL、可选使用 JWT 进行鉴权，供 FastAPI 业务逻辑调用。
所有注释均为中文。
"""
import time
import json
import base64
import hmac
import hashlib
from typing import Optional
from datetime import datetime, timedelta
import requests


class Jitsi会议客户端:
    """Jitsi Meet 简易客户端

    参数
    ------
    domain : str
        部署好的 Jitsi 域名，例如 "jitsi.example.com"。
    app_id : Optional[str]
        启用了 JWT 鉴权时的 app_id。
    app_secret : Optional[str]
        启用了 JWT 鉴权时的 app_secret。
    protocol : str
        协议 http 或 https，默认 https。
    prosody_host : str
        Prosody 容器在 Docker 网络中的主机名，默认 xmpp。
    muc_domain : Optional[str]
        MUC 组件域名，如 "muc.example.com"；为空时自动使用 "muc." + domain。
    """

    def __init__(self, domain: str, app_id: Optional[str] = None, app_secret: Optional[str] = None,
                 protocol: str = "https", prosody_host: str = "xmpp", muc_domain: Optional[str] = None):
        """初始化

        参数
        ------
        domain: Jitsi 主域名（XMPP_DOMAIN），不包含协议。
        protocol: http/https，用于生成会议 URL。
        prosody_host: Prosody 容器在 Docker 网络中的主机名，默认 xmpp。
        muc_domain: MUC 组件域名，如 "muc.example.com"；为空时自动使用 "muc." + domain。
        """
        self.domain = domain.rstrip("/")
        self.app_id = app_id
        self.app_secret = app_secret
        self.protocol = protocol
        self.prosody_host = prosody_host
        self.muc_domain = muc_domain or f"muc.{self.domain}"

    # ----------------------------------------
    # 公共方法
    # ----------------------------------------

    def 生成会议链接(self, room_name: str, user_name: str, exp_minutes: int = 60) -> str:
        """生成 Jitsi 会议 URL，可携带 JWT。

        若未配置 app_secret，则返回无需鉴权的公共链接。
        若配置 app_secret，则根据 app_id/app_secret 生成符合 Jitsi JWT 规范的 token。
        """
        base_url = f"{self.protocol}://{self.domain}/{room_name}"

        if not self.app_secret:
            # 无 JWT 模式
            return base_url

        token = self._生成_jwt(room_name, user_name, exp_minutes)
        return f"{base_url}?jwt={token}"

    # ----------------------------------------
    # 会议管理（占位符实现）
    # ----------------------------------------

    def 列出参会者(self, room_name: str) -> list[dict]:
        """列出房间参会者（依赖 Prosody `mod_muc_size`）。

        返回格式示例：
        [
            {"jid": "alice@10.10.10.117/8a74…", "nick": "Alice"},
            {"jid": "bob@10.10.10.117/a3bc…", "nick": "Bob"}
        ]
        若查询失败或模块未启用，返回空列表。
        """
        room_jid = room_name  # 仅本地数据库的纯数字 id
        url = f"http://{self.prosody_host}:5280/muc_size?room={room_jid}&domain={self.muc_domain}"
        try:
            resp = requests.get(url, timeout=3)
            if resp.status_code != 200:
                return []
            data = resp.json()
            occupants = data.get("occupants") or {}
            participants: list[dict] = []
            for jid, info in occupants.items():
                participants.append({
                    "jid": jid,
                    "nick": info.get("nick"),
                    "email": info.get("email")
                })
            return participants
        except Exception:
            # 网络异常或解析失败
            return []

    def 移除参会者(self, room_name: str, participant_id: str) -> bool:
        """移除指定参会者（踢人）。

        说明：
        需要房主/Moderator 权限，且同样依赖 Prosody HTTP API 或自定义 XMPP 指令。
        """
        # TODO: 调用 Prosody REST 或发送 XMPP <iq> 指令
        return False

    def 设置参会者静音(self, room_name: str, participant_id: str, mute: bool = True) -> bool:
        """远程静音/取消静音参会者麦克风（Mute/Unmute）。"""
        # TODO: 实际调用方式同上
        return False

    def 切换参会者摄像头(self, room_name: str, participant_id: str, camera: str = "front") -> bool:
        """切换参会者摄像头（前/后摄）。

        该功能无法直接通过 Jitsi 服务器端完成，通常需前端/终端配合完成，
        可通过 WebSocket/推送指令让客户端调用 `JitsiMeetJS.createLocalTracks` 切换。
        此处仅保留占位符。
        """
        return False

    # ----------------------------------------
    # 内部工具方法
    # ----------------------------------------

    def _生成_jwt(self, room_name: str, user_name: str, exp_minutes: int = 60) -> str:
        """参考 https://jitsi.github.io/handbook/docs/dev-guide/dev-guide-advanced#secure-domain 生成 JWT"""
        header = {"alg": "HS256", "typ": "JWT"}
        now = int(time.time())
        payload = {
            "aud": "jitsi",  # 固定值
            "iss": self.app_id,
            "sub": self.domain,  # 与 prosody 配置一致
            "room": room_name,
            "exp": now + exp_minutes * 60,
            "nbf": now - 10,
            "context": {
                "user": {
                    "name": user_name,
                    "avatar": "",
                    "email": "",
                    "id": user_name,
                }
            }
        }
        token = self._encode_jwt(header, payload, self.app_secret)
        return token

    @staticmethod
    def _encode_jwt(header: dict, payload: dict, secret: str) -> str:
        """用 HS256 手动编码 JWT，避免额外依赖"""
        def _b64(data: bytes) -> bytes:
            return base64.urlsafe_b64encode(data).rstrip(b"=")

        header_b64 = _b64(json.dumps(header, separators=(",", ":")).encode())
        payload_b64 = _b64(json.dumps(payload, separators=(",", ":")).encode())
        signing_input = b".".join([header_b64, payload_b64])
        signature = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
        signature_b64 = _b64(signature)
        return b".".join([header_b64, payload_b64, signature_b64]).decode() 