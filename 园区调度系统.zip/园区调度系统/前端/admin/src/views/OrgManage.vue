<template>
  <div class="org-manage-container">
    <el-card>
      <div style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;">
        <span style="font-size:18px;">组织管理</span>
        <div>
          <!-- 组织管理后续功能按钮占位 -->
          <el-button type="primary" @click="showAddDept">新增部门</el-button>
        </div>
      </div>
      <!-- 组织树 -->
      <el-tree
        :data="orgTree"
        node-key="id"
        :props="{ label: 'name', children: 'children' }"
        default-expand-all
        :expand-on-click-node="false"
        :loading="loading"
      >
        <template #default="{ data }">
          <span>{{ data.name }}</span>
          <span style="margin-left:8px;">
            <el-button type="text" size="small" @click.stop="showAddDept(data)">新增</el-button>
            <el-button type="text" size="small" @click.stop="showEditDept(data)">编辑</el-button>
            <el-button type="text" size="small" @click.stop="deleteDeptNode(data)">删除</el-button>
          </span>
        </template>
      </el-tree>
    </el-card>

    <!-- 新增/编辑部门弹窗 -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="400px">
      <el-form :model="deptForm" ref="formRef" label-width="80px">
        <el-form-item label="部门名称" prop="name" :rules="[{ required: true, message: '请输入名称', trigger: 'blur' }]">
          <el-input v-model="deptForm.name" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveDept">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { fetchOrgTree, addOrg, editOrg, deleteOrg } from '@/api/org'
import { ElMessage, ElMessageBox } from 'element-plus'

// 部门树数据
const orgTree = ref([])
const loading = ref(false)
const dialogVisible = ref(false)
const dialogTitle = ref('')
const deptForm = reactive({ id: null, name: '', parent_id: null })
const formRef = ref(null)

function loadTree () {
  loading.value = true
  fetchOrgTree().then(res => {
    orgTree.value = res.data || []
  }).finally(() => { loading.value = false })
}

onMounted(loadTree)

function showAddDept (parent = null) {
  dialogTitle.value = '新增部门'
  Object.assign(deptForm, { id: null, name: '', parent_id: parent?.id || null })
  dialogVisible.value = true
}

function saveDept () {
  formRef.value.validate(async (valid) => {
    if (!valid) return
    if (deptForm.id) {
      await editOrg(deptForm.id, { name: deptForm.name, parent_id: deptForm.parent_id })
      ElMessage.success('已更新')
    } else {
      await addOrg({ name: deptForm.name, parent_id: deptForm.parent_id })
      ElMessage.success('已新增')
    }
    dialogVisible.value = false
    loadTree()
  })
}

function showEditDept (data) {
  dialogTitle.value = '编辑部门'
  Object.assign(deptForm, { id: data.id, name: data.name, parent_id: data.parent_id })
  dialogVisible.value = true
}

function deleteDeptNode (data) {
  ElMessageBox.confirm('确定删除该部门及其子部门吗?', '提示', { type: 'warning' }).then(async () => {
    await deleteOrg(data.id)
    ElMessage.success('已删除')
    loadTree()
  })
}
</script>

<style scoped>
.org-manage-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style> 