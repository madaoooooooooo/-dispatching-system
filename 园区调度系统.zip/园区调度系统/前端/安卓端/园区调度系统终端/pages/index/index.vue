<template>
	<view class="home-container">
		<!-- 顶部横幅 -->
		<view class="banner nav-bar">
			<text class="park">{{ parkName }}</text>
			<view class="datetime">
				<text>{{ date }}</text>
				<text class="time">{{ time }}</text>
			</view>
			<view class="status-icons">
				<text class="icon">{{ gpsIcon }}</text>
				<text class="icon">{{ serverIcon }}</text>
			</view>
		</view>
		<!-- 功能区块 -->
		<view class="features">
			<view
				v-for="f in features"
				:key="f.name"
				class="feature"
				:style="{ background: f.color }"
				@click="openFeature(f)"
			>
				<text class="feature-icon">{{ f.icon }}</text>
				<text class="feature-name">{{ f.name }}</text>
			</view>
		</view>
	</view>
</template>

<script>
import { BASE_URL } from '../../config/index.js'
export default {
	name: 'Home',
	data() {
		return {
			parkName: 'XXX园区',
			date: '',
			time: '',
			gpsOk: false,
			serverOk: false,
			intervalId: null,
			pingId: null,
			features: [
				{ name: '对讲', icon: '📢', color: '#FFC107', route: '/pages/intercom/intercom' },
				{ name: '会议', icon: '🎥', color: '#4CAF50', route: '/pages/meeting/index' },
				{ name: '表单上传', icon: '📄', color: '#03A9F4', route: '' },
				{ name: '一键报警', icon: '🚨', color: '#F44336', route: '' }
			]
		}
	},
	computed: {
		// 根据状态返回 emoji
		gpsIcon() {
			return this.gpsOk ? '📡' : '❌'
		},
		serverIcon() {
			return this.serverOk ? '🖥️' : '❌'
		}
	},
	methods: {
		// 获取当前日期时间（中文格式）
		updateTime() {
			const now = new Date()
			const weekMap = ['日', '一', '二', '三', '四', '五', '六']
			const y = now.getFullYear()
			const m = `${now.getMonth() + 1}`.padStart(2, '0')
			const d = `${now.getDate()}`.padStart(2, '0')
			this.date = `${y}年${m}月${d}日 星期${weekMap[now.getDay()]}`
			this.time = now.toLocaleTimeString('zh-CN', { hour12: false })
		},
		// 检查定位是否成功（只取一次，失败则标红）
		checkGPS() {
			uni.getLocation({
				type: 'wgs84',
				success: () => { this.gpsOk = true },
				fail: () => { this.gpsOk = false }
			})
		},
		// 轮询服务器连通性
		pingServer() {
			uni.request({
				url: `${BASE_URL}/api/system/status`,
				method: 'GET',
				timeout: 3000,
				success: (res) => {
					this.serverOk = res.statusCode === 200
				},
				fail: () => { this.serverOk = false }
			})
		},
		// 打开功能（占位）
		openFeature(f) {
			if (f.route) {
				uni.navigateTo({ url: f.route })
			} else {
				uni.showToast({ title: f.name + ' 开发中', icon: 'none' })
			}
		}
	},
	mounted() {
		// 初始化时间
		this.updateTime()
		this.intervalId = setInterval(this.updateTime, 1000) // 每秒刷新时间
		// 检测 GPS
		this.checkGPS()
		// 每 30 秒检测一次服务器
		this.pingServer()
		this.pingId = setInterval(this.pingServer, 30000)
	},
	destroyed() {
		clearInterval(this.intervalId)
		clearInterval(this.pingId)
	}
}
</script>

<style lang="scss">
.home-container {
	display: flex;
	flex-direction: column;
	height: 100vh;
}
.banner {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 20rpx 30rpx;
	background: #2196f3;
	color: #fff;
}
.nav-bar {
	padding-top: var(--status-bar-height);
	height: calc(88rpx + var(--status-bar-height));
}
.park {
	font-size: 32rpx;
	font-weight: bold;
}
.datetime {
	display: flex;
	flex-direction: column;
	align-items: flex-end;
	font-size: 24rpx;
}
.datetime .time {
	font-size: 28rpx;
}
.status-icons {
	display: flex;
	gap: 20rpx;
}
.icon {
	font-size: 36rpx;
	line-height: 36rpx;
}
.features {
	flex: 1;
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	grid-gap: 30rpx;
	padding: 40rpx;
}
.feature {
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	border-radius: 16rpx;
	color: #fff;
	height: 200rpx;
}
.feature-icon {
	font-size: 60rpx;
	margin-bottom: 12rpx;
}
.feature-name {
	font-size: 28rpx;
}
</style>
