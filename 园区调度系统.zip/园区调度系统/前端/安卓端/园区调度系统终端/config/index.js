// 全局配置文件，用于管理可根据环境变动的参数
// 如需修改后端地址，仅修改 BASE_URL 即可。如需多环境，可在此文件中按需切换。

// 后端 API 基础地址
export const BASE_URL = 'http://10.10.10.117:8000'

export default {
  BASE_URL
} 