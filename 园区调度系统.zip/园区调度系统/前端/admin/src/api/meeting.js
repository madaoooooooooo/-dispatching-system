import request from './request'

export function fetchMeetingList(params) {
  return request({
    url: 'meeting/list',
    method: 'GET',
    params
  })
}

export function createMeeting(data) {
  return request({
    url: 'meeting/create',
    method: 'POST',
    data
  })
}

export function joinMeeting(meetingId) {
  return request({
    url: `meeting/join/${meetingId}`,
    method: 'POST'
  })
}

// 获取进行中的会议
export function fetchLiveMeeting() {
  return request({
    url: 'meeting/live',
    method: 'GET'
  })
}

export function fetchParticipants(meetingId) {
  return request({
    url: 'meeting/participants',
    method: 'POST',
    data: { meeting_id: meetingId }
  })
}

export function inviteUserToMeeting(meetingId, username) {
  return request({
    url: 'meeting/invite',
    method: 'POST',
    data: { meeting_id: meetingId, user: username }
  })
}

export function kickParticipant(meetingId, participantId) {
  return request({
    url: 'meeting/kick',
    method: 'POST',
    data: { meeting_id: meetingId, participant_id: participantId }
  })
}

export function controlParticipant(meetingId, participantId, action) {
  return request({
    url: 'meeting/control',
    method: 'POST',
    data: { meeting_id: meetingId, participant_id: participantId, action }
  })
} 