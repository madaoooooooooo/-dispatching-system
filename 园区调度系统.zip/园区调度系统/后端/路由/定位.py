from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlmodel import Session, select
from pydantic import BaseModel
from datetime import datetime
from sqlalchemy import func

from 后端.模型 import Location
from 后端.模型 import Geofence
from 后端.工具.数据库 import 获取会话

router = APIRouter(prefix="/api/location", tags=["location"])

class 上报定位请求(BaseModel):
    device_id: str
    lat: float
    lng: float
    type: str
    timestamp: Optional[datetime] = None

@router.post('/report')
def 上报定位(data: 上报定位请求, session: Session = Depends(获取会话)):
    loc = Location(device_id=data.device_id, lat=data.lat, lng=data.lng, type=data.type,
                   timestamp=data.timestamp or datetime.utcnow())
    session.add(loc)
    session.commit()
    return {"code": 0, "msg": "上报成功"}

@router.get('/realtime')
def 实时定位(device_id: Optional[str] = None, session: Session = Depends(获取会话)):
    query = select(Location)
    if device_id:
        query = query.where(Location.device_id == device_id)
    latest_subq = (
        select(Location.device_id, func.max(Location.timestamp).label('ts')).group_by(Location.device_id).subquery()
    )
    latest_query = select(Location).join(latest_subq, (Location.device_id == latest_subq.c.device_id) & (Location.timestamp == latest_subq.c.ts))
    result = session.exec(latest_query).all()
    return {"code": 0, "data": result} 

# ------------------- 历史轨迹 -------------------

@router.get('/history')
def 历史轨迹(device_id: str, start_time: datetime, end_time: datetime, interval: int = 0,
         session: Session = Depends(获取会话)):
    query = select(Location).where(Location.device_id == device_id,
                                 Location.timestamp.between(start_time, end_time))
    points = session.exec(query.order_by(Location.timestamp)).all()
    if interval > 0 and len(points) > 1:
        # 简易采样
        sampled = []
        last_ts = None
        for p in points:
            if last_ts is None or (p.timestamp - last_ts).total_seconds() >= interval:
                sampled.append(p)
                last_ts = p.timestamp
        points = sampled
    return {"code": 0, "data": points}

# ------------------- 地理围栏 -------------------

class 创建围栏请求(BaseModel):
    name: str
    coordinates: str  # GeoJSON 或自定义格式

@router.post('/geofence/create')
def 创建围栏(data: 创建围栏请求, session: Session = Depends(获取会话)):
    fence = Geofence(name=data.name, coordinates=data.coordinates)
    session.add(fence)
    session.commit()
    return {"code": 0, "msg": "创建成功", "data": {"fence_id": fence.id}}

@router.get('/geofence/list')
def 围栏列表(session: Session = Depends(获取会话)):
    fences = session.exec(select(Geofence)).all()
    return {"code": 0, "data": fences}

@router.delete('/geofence/{fence_id}')
def 删除围栏(fence_id: int, session: Session = Depends(获取会话)):
    fence = session.get(Geofence, fence_id)
    if not fence:
        raise HTTPException(404, "围栏不存在")
    session.delete(fence)
    session.commit()
    return {"code": 0, "msg": "已删除"} 