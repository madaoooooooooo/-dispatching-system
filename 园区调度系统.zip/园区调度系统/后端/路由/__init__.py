from .用户 import router as 用户路由
from .设备 import router as 设备路由
from .报警 import router as 报警路由
from .会议 import router as 会议路由
from .定位 import router as 定位路由
from .统计 import router as 统计路由
from .推送 import router as 推送路由
from .语音 import router as 语音路由
from .通讯 import router as 通讯路由
from .群聊 import router as 群聊路由
from .推送接口 import router as 推送接口路由
from .摄像头 import router as 摄像头路由
from .系统 import router as 系统路由
from .电话用户 import router as 电话用户路由
from .火箭用户 import router as 火箭用户路由
from .组织 import router as 组织路由
from .对讲信令 import router as 对讲信令路由

a__all__ = ['用户路由', '设备路由', '报警路由', '会议路由', '定位路由', '统计路由', '推送路由', '语音路由', '通讯路由', '群聊路由', '推送接口路由', '摄像头路由', '系统路由', '电话用户路由', '火箭用户路由', '组织路由', '对讲信令路由'] 