<template>
  <view class="index-root">
    <text class="title">会议</text>
    <input v-model="meetingName" placeholder="输入会议名称(可选)" class="input" />

    <view class="toggles">
      <button :class="['circle-btn', audioOn?'on':'off']" @click="audioOn=!audioOn">{{ audioOn? '🎤':'🔇' }}</button>
      <button :class="['circle-btn', videoOn?'on':'off']" @click="videoOn=!videoOn">{{ videoOn? '📹':'📷' }}</button>
      <button class="circle-btn" @click="invite">👥</button>
    </view>

    <button class="btn primary" @click="create">创建会议</button>
    <button class="btn" @click="join">加入会议</button>
  </view>
</template>

<script>
export default {
  data () {
    return { meetingName: '', audioOn: true, videoOn: true }
  },
  methods: {
    randomId() { return Math.floor(Math.random()*900+100) },
    buildUrl(id) {
      const name = this.meetingName.trim() || uni.getStorageSync('user_name') || '会议';
      return `/pages/meeting/room?meeting_id=${id}&mname=${encodeURIComponent(name)}&audio=${this.audioOn?1:0}&video=${this.videoOn?1:0}`
    },
    create() { const id = this.randomId(); uni.navigateTo({ url: this.buildUrl(id) }) },
    invite() { uni.showToast({ title: '邀请功能待实现', icon: 'none' }) },
    join() {
      uni.showModal({
        title: '加入会议',
        content: '请输入会议号',
        editable: true,
        placeholderText: '会议号',
        success: (res) => {
          if (res.confirm) {
            const id = (res.content || '').trim();
            if (!id) { uni.showToast({ title: '会议号不能为空', icon: 'none' }); return; }
            uni.navigateTo({ url: this.buildUrl(id) })
          }
        }
      })
    }
  }
}
</script>

<style>
.index-root{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;padding:0 40rpx;}
.title{font-size:48rpx;margin-bottom:60rpx;}
.input{width:100%;height:80rpx;border:1px solid #ccc;border-radius:8rpx;padding:0 20rpx;margin-bottom:30rpx;}
.btn{width:100%;height:80rpx;border:none;border-radius:8rpx;background:#5f6368;color:#fff;font-size:32rpx;margin-bottom:15rpx;}
.btn.primary{background:#0d6efd;}
.toggles{display:flex;justify-content:center;margin-bottom:30rpx;}
.circle-btn{width:80rpx;height:80rpx;border:none;border-radius:40rpx;margin:0 15rpx;font-size:40rpx;background:#5f6368;color:#fff;line-height:80rpx;}
.circle-btn.on{background:#0d6efd;}
.circle-btn.off{background:#a42828;}
</style> 