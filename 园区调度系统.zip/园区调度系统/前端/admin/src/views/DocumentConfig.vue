<template>
  <div class="doc-container">
    <el-card>
      <el-upload
        action="" :http-request="uploadRequest" multiple
        :before-upload="beforeUpload" :show-file-list="false">
        <el-button type="primary">上传文档</el-button>
      </el-upload>
      <el-table :data="docList" style="width:100%;margin-top:16px;" :loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="文件名" />
        <el-table-column prop="category" label="分类" width="120" />
        <el-table-column prop="size" label="大小(KB)" width="120" />
        <el-table-column prop="upload_time" label="上传时间" width="180" />
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="link" size="small" @click="onDownload(scope.row)">下载</el-button>
            <el-button type="link" size="small" @click="onDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        @current-change="fetchData"
        @size-change="fetchData"
        layout="total, sizes, prev, pager, next, jumper"
        :page-sizes="[10,20,50]"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { uploadDoc, fetchDocList, deleteDoc } from '@/api/doc'
import { ElMessage, ElMessageBox } from 'element-plus'

const docList = ref([])
const loading = ref(false)
const page = ref(1)
const size = ref(10)
const total = ref(0)

onMounted(() => {
  fetchData()
})

function fetchData () {
  loading.value = true
  fetchDocList({ page: page.value, size: size.value }).then(res => {
    docList.value = res.data.list
    total.value = res.data.total
  }).finally(() => (loading.value = false))
}

function uploadRequest (option) {
  const form = new FormData()
  form.append('file', option.file)
  uploadDoc(form).then(() => {
    ElMessage.success('上传成功')
    fetchData()
  }).catch(() => {
    ElMessage.error('上传失败')
  }).finally(() => option.onSuccess())
}

function beforeUpload (file) {
  const allow = ['pdf', 'doc', 'docx', 'xlsx']
  const ext = file.name.split('.').pop().toLowerCase()
  if (!allow.includes(ext)) {
    ElMessage.error('仅支持文档类型文件')
    return false
  }
  return true
}

function onDelete (row) {
  ElMessageBox.confirm('确定删除该文档?', '提示', { type: 'warning' }).then(() => {
    deleteDoc(row.id).then(() => {
      ElMessage.success('删除成功')
      fetchData()
    })
  })
}

function onDownload (row) {
  window.open(`/api/doc/download/${row.id}`)
}
</script>

<style scoped>
.doc-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style>
