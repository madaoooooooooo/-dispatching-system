"""系统配置接口 (/api/system/*)
角色、权限、菜单占位，只实现角色与权限 CRUD。
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List, Optional
from pydantic import BaseModel
from sqlalchemy import delete

from 后端.工具.数据库 import 获取会话
from 后端.模型 import Role, Permission, RolePermission

router = APIRouter(prefix="/api/system", tags=["system"])

# -------- 角色 --------

class 角色请求(BaseModel):
    name: str
    description: Optional[str] = None

class 角色权限请求(BaseModel):
    permissions: list[str]

@router.get('/roles')
def 角色列表(session: Session = Depends(获取会话)):
    """获取角色列表，同时附带权限信息。

    为保持前端使用简便，接口直接在每个角色对象上增加 `permissions` 字段，
    其值为该角色拥有的权限标识列表（list[str]）。
    """
    # 先拉取所有角色
    roles = session.exec(select(Role)).all()

    # 提前将所有权限映射到字典，避免 N+1 查询
    role_ids = [r.id for r in roles]
    if not role_ids:
        return {"code": 0, "data": []}

    # 查询 RolePermission 关系表
    rp_rows: list[RolePermission] = session.exec(
        select(RolePermission).where(RolePermission.role_id.in_(role_ids))
    ).all()

    # 一次性查询涉及到的 Permission
    perm_ids = {rp.permission_id for rp in rp_rows}
    perms = {}
    if perm_ids:
        perm_objs = session.exec(select(Permission).where(Permission.id.in_(perm_ids))).all()
        perms = {p.id: p.name for p in perm_objs}

    # 构造 role -> permissions 映射
    perm_map: dict[int, list[str]] = {rid: [] for rid in role_ids}
    for rp in rp_rows:
        perm_name = perms.get(rp.permission_id)
        if perm_name:
            perm_map[rp.role_id].append(perm_name)

    # 将 permissions 注入到角色 dict 中
    data = []
    for role in roles:
        item = role.dict()
        item["permissions"] = perm_map.get(role.id, [])
        data.append(item)

    return {"code": 0, "data": data}

@router.post('/roles')
def 创建角色(data: 角色请求, session: Session = Depends(获取会话)):
    if session.exec(select(Role).where(Role.name == data.name)).first():
        raise HTTPException(400, "角色已存在")
    role = Role(name=data.name, description=data.description)
    session.add(role)
    session.commit()
    return {"code": 0, "msg": "创建成功", "data": {"id": role.id}}

@router.put('/roles/{role_id}')
def 更新角色(role_id: int, data: 角色请求, session: Session = Depends(获取会话)):
    role = session.get(Role, role_id)
    if not role:
        raise HTTPException(404, "角色不存在")
    role.name = data.name
    role.description = data.description
    session.add(role)
    session.commit()
    return {"code": 0, "msg": "更新成功"}

@router.delete('/roles/{role_id}')
def 删除角色(role_id: int, session: Session = Depends(获取会话)):
    role = session.get(Role, role_id)
    if not role:
        raise HTTPException(404, "角色不存在")
    session.delete(role)
    session.commit()
    return {"code": 0, "msg": "已删除"}

@router.post('/roles/{role_id}/set_permissions')
def 设置角色权限(role_id: int, data: 角色权限请求, session: Session = Depends(获取会话)):
    role = session.get(Role, role_id)
    if not role:
        raise HTTPException(404, "角色不存在")
    # 清除现有角色权限映射
    session.exec(delete(RolePermission).where(RolePermission.role_id == role_id))
    session.commit()  # 先提交删除，以免唯一约束导致后续插入失败
    for perm_name in data.permissions:
        perm = session.exec(select(Permission).where(Permission.name == perm_name)).first()
        if not perm:
            perm = Permission(name=perm_name)
            session.add(perm)
            session.commit()
        session.add(RolePermission(role_id=role_id, permission_id=perm.id))
    session.commit()
    return {"code": 0, "msg": "权限已更新"}

# -------- 权限 --------

class 权限请求(BaseModel):
    name: str
    description: Optional[str] = None

@router.get('/permissions')
def 权限列表(session: Session = Depends(获取会话)):
    perms = session.exec(select(Permission)).all()
    return {"code": 0, "data": perms}

@router.post('/permissions')
def 创建权限(data: 权限请求, session: Session = Depends(获取会话)):
    if session.exec(select(Permission).where(Permission.name == data.name)).first():
        raise HTTPException(400, "权限已存在")
    perm = Permission(name=data.name, description=data.description)
    session.add(perm)
    session.commit()
    return {"code": 0, "msg": "创建成功", "data": {"id": perm.id}}

@router.put('/permissions/{permission_id}')
def 更新权限(permission_id: int, data: 权限请求, session: Session = Depends(获取会话)):
    perm = session.get(Permission, permission_id)
    if not perm:
        raise HTTPException(404, "权限不存在")
    perm.name = data.name
    perm.description = data.description
    session.add(perm)
    session.commit()
    return {"code": 0, "msg": "更新成功"}

# ---- 系统状态心跳 ----

@router.get('/status')
async def 系统状态():
    """供前端轮询服务器是否在线，简单返回 200+OK 字符串。"""
    return {"code": 0, "msg": "ok"} 