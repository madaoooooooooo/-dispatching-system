import request from './request'

// 获取报警列表
export function fetchAlarmList(params) {
  return request({
    url: '/alarm/list',
    method: 'GET',
    params
  })
}

// 确认报警
export function confirmAlarm(alarmId) {
  return request({
    url: `/alarm/confirm/${alarmId}`,
    method: 'POST'
  })
}

// 处理报警
export function handleAlarm(alarmId, data) {
  return request({
    url: `/alarm/handle/${alarmId}`,
    method: 'POST',
    data
  })
}

// 关闭报警
export function closeAlarm(alarmId) {
  return request({
    url: `/alarm/close/${alarmId}`,
    method: 'POST'
  })
} 