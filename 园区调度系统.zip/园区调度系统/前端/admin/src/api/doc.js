import request from './request'

export function uploadDoc(data) {
  return request({
    url: 'doc/upload',
    method: 'POST',
    data,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export function fetchDocList(params) {
  return request({
    url: 'doc/list',
    method: 'GET',
    params
  })
}

export function deleteDoc(docId) {
  return request({
    url: `doc/${docId}`,
    method: 'DELETE'
  })
} 