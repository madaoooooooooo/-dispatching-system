"""Rocket.Chat 通讯路由

提供发送消息、创建群组等 REST API 的转发。
注意：这里只做演示，生产环境应对异常做更多处理。
"""
from typing import Optional, List

from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from pydantic import BaseModel

from 后端.第三方.火箭聊天.客户端 import 火箭聊天客户端
from 后端.工具.配置 import get_settings

router = APIRouter(prefix="/api/message", tags=["message"])

# 全局 Rocket.Chat 客户端实例
rc_client: Optional[火箭聊天客户端] = None

def get_rc_client() -> 火箭聊天客户端:
    global rc_client
    if rc_client is None:
        s = get_settings()
        rc_client = 火箭聊天客户端(s.rocketchat_url, s.rocketchat_user, s.rocketchat_password, verify_ssl=False)
        rc_client.登录()
    return rc_client

class 发送消息请求(BaseModel):
    room_id: str
    text: str

@router.post('/send')
def 发送消息(data: 发送消息请求):
    rc = get_rc_client()
    try:
        msg_id = rc.发送消息(data.room_id, data.text)
        return {"code": 0, "msg": "发送成功", "data": {"message_id": msg_id}}
    except Exception as e:
        raise HTTPException(500, f"Rocket.Chat 发送失败: {e}")

class 创建群组请求(BaseModel):
    name: str
    members: Optional[List[str]] = None
    read_only: bool = False

@router.post('/group/create')
def 创建群组(data: 创建群组请求):
    rc = get_rc_client()
    try:
        group_id = rc.创建群组(data.name, data.members, data.read_only)
        return {"code": 0, "msg": "创建成功", "data": {"group_id": group_id}}
    except Exception as e:
        raise HTTPException(500, f"创建群组失败: {e}")

# ------------------- 消息撤回 -------------------

@router.delete('/{message_id}')
def 撤回消息(message_id: str, room_id: str = Query(...)):
    rc = get_rc_client()
    try:
        rc.删除消息(room_id, message_id)
        return {"code": 0, "msg": "撤回成功"}
    except Exception as e:
        raise HTTPException(500, f"撤回失败: {e}")

# ------------------- 群组列表 -------------------

@router.get('/chat/group/list')
def 群组列表():
    rc = get_rc_client()
    try:
        groups = rc.群组列表()
        return {"code": 0, "data": groups}
    except Exception as e:
        raise HTTPException(500, f"获取群组列表失败: {e}")

# ------------------- 加入/退出群组 -------------------

class 群组操作请求(BaseModel):
    room_id: str

@router.post('/chat/group/join')
def 加入群组(data: 群组操作请求):
    rc = get_rc_client()
    try:
        rc.加入群组(data.room_id)
        return {"code": 0, "msg": "已加入群组"}
    except Exception as e:
        raise HTTPException(500, f"加入失败: {e}")

@router.post('/chat/group/leave')
def 退出群组(data: 群组操作请求):
    rc = get_rc_client()
    try:
        rc.退出群组(data.room_id)
        return {"code": 0, "msg": "已退出群组"}
    except Exception as e:
        raise HTTPException(500, f"退出失败: {e}")

# ------------------- 文件下载 & 分享 -------------------

from fastapi.responses import StreamingResponse

@router.get('/file/download/{file_id}')
def 下载文件(file_id: str):
    rc = get_rc_client()
    try:
        content = rc.获取文件下载(file_id)
        return StreamingResponse(iter([content]), media_type='application/octet-stream', headers={"Content-Disposition": f"attachment; filename={file_id}"})
    except Exception as e:
        raise HTTPException(500, f"下载失败: {e}")

class 分享文件请求(BaseModel):
    room_id: str
    file_id: str

@router.post('/file/share')
def 分享文件(data: 分享文件请求):
    rc = get_rc_client()
    try:
        rc.分享文件(data.room_id, data.file_id)
        return {"code": 0, "msg": "分享成功"}
    except Exception as e:
        raise HTTPException(500, f"分享失败: {e}")

# ------------------- 文件上传 -------------------

@router.post('/file/upload')
async def 上传文件(room_id: str = Query(...), file: UploadFile = File(...)):
    rc = get_rc_client()
    try:
        content = await file.read()
        file_id = rc.上传文件(room_id, content, file.filename)
        return {"code": 0, "msg": "上传成功", "data": {"file_id": file_id}}
    except Exception as e:
        raise HTTPException(500, f"文件上传失败: {e}")

# ------------------- 消息历史 -------------------

@router.get('/history')
def 获取历史(room_id: str, count: int = 50):
    rc = get_rc_client()
    try:
        msgs = rc.获取历史(room_id, count)
        return {"code": 0, "data": msgs}
    except Exception as e:
        raise HTTPException(500, f"获取历史失败: {e}") 