module.exports = {
    root: true,
    env: {
      node: true,
    },
    extends: [
      'plugin:vue/vue3-essential',
      'eslint:recommended'
    ],
    parserOptions: {
      ecmaVersion: 2020,
    },
    rules: {
      // 这里可以自定义规则，比如关闭某些校验
      'no-console': 'off',
      'no-debugger': 'off',
      'vue/multi-word-component-names': 'off'
    }
  }