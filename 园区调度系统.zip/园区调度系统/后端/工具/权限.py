"""权限校验工具

用法：

```
from fastapi import Depends
from 后端.工具.权限 import 权限依赖

@router.get('/secure', dependencies=[Depends(权限依赖('device_manage'))])
async def secure_endpoint():
    ...
```
"""
from functools import wraps
from typing import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlmodel import Session, select

from 后端.工具.数据库 import 获取会话
from 后端.模型 import User, UserRole, RolePermission, Permission
from 后端.工具.认证 import 解析令牌

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/user/login")


def 获取当前用户(token: str = Depends(oauth2_scheme), session: Session = Depends(获取会话)) -> User:
    payload = 解析令牌(token)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token 无效")
    user = session.exec(select(User).where(User.id == payload.get('id'))).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="用户不存在")
    return user


def 用户权限列表(user: User, session: Session) -> list[str]:
    query = (
        select(Permission.name)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(UserRole, UserRole.role_id == RolePermission.role_id)
        .where(UserRole.user_id == user.id)
    )
    return [row[0] for row in session.exec(query).all()]


def 权限依赖(permission: str) -> Callable:
    async def _checker(user: User = Depends(获取当前用户), session: Session = Depends(获取会话)):
        if permission not in 用户权限列表(user, session):
            raise HTTPException(status_code=403, detail="权限不足")
    return _checker


def 权限装饰器(permission: str):
    """函数装饰器用在路由函数上"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, user: User = Depends(获取当前用户), session: Session = Depends(获取会话), **kwargs):
            if permission not in 用户权限列表(user, session):
                raise HTTPException(status_code=403, detail="权限不足")
            return await func(*args, **kwargs)
        return wrapper
    return decorator 