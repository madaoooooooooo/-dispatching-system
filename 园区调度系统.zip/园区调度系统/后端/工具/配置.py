"""全局配置模块

使用 Pydantic BaseSettings 读取 .env 或环境变量，以便在 Docker Compose
中通过 environment 覆盖。
"""
from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Rocket.Chat
    rocketchat_url: str = Field("http://rocketchat:3000", description="Rocket.Chat 服务器地址")
    rocketchat_user: str = Field("admin", description="Rocket.Chat 管理员用户名")
    rocketchat_password: str = Field("admin", description="Rocket.Chat 管理员密码")

    # Jitsi
    jitsi_domain: str = Field("localhost", description="Jitsi 域名，不含 https://")
    jitsi_app_id: str | None = None
    jitsi_app_secret: str | None = None

    # Jitsi MUC 域
    jitsi_muc_domain: str = Field("muc.localhost", description="Jitsi MUC 域名，用于查询房间参会者")

    # FreeSWITCH
    freeswitch_host: str = Field("freeswitch", description="FreeSWITCH ESL 主机名")
    freeswitch_port: int = Field(8021, description="FreeSWITCH ESL 端口")
    freeswitch_password: str = Field("ClueCon", description="FreeSWITCH ESL 密码")

    # Pydantic v2 配置
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

@lru_cache()
def get_settings() -> Settings:
    return Settings() 