from fastapi import APIRouter, Depends, HTTPException, Header
from typing import Optional
from sqlmodel import Session, select
from pydantic import BaseModel
from sqlalchemy import func
from datetime import datetime, timedelta
import secrets
import json
from fastapi.encoders import jsonable_encoder

from 后端.模型 import Meeting
from 后端.工具.数据库 import 获取会话
from 后端.第三方.Jitsi会议.客户端 import Jitsi会议客户端
from 后端.工具.配置 import get_settings

router = APIRouter(prefix="/api/meeting", tags=["meeting"])

class 创建会议请求(BaseModel):
    title: str
    description: Optional[str] = None
    start_time: datetime
    duration: int
    participants: Optional[list[str]] = None
    type: str  # video/voice/screen_share
    password: Optional[str] = None

class TokenRequest(BaseModel):
    room: str
    moderator: bool = False

@router.post('/create')
def 创建会议(data: 创建会议请求, session: Session = Depends(获取会话)):
    meeting = Meeting(title=data.title, description=data.description, start_time=data.start_time,
                      duration=data.duration, status='ongoing')
    # 生成 jitsi url
    session.add(meeting)
    session.commit()
    session.refresh(meeting)
    s = get_settings()
    jitsi = Jitsi会议客户端(domain=s.jitsi_domain, app_id=s.jitsi_app_id, app_secret=s.jitsi_app_secret,
                          muc_domain=s.jitsi_muc_domain)
    meeting.jitsi_url = jitsi.生成会议链接(room_name=str(meeting.id), user_name="system")
    session.add(meeting)
    session.commit()
    return {"code": 0, "msg": "创建成功", "data": {"id": meeting.id, "jitsi_url": meeting.jitsi_url}}

@router.get('/list')
def 会议列表(status: Optional[str] = None, date: Optional[str] = None, session: Session = Depends(获取会话)):
    query = select(Meeting)
    if status:
        query = query.where(Meeting.status == status)
    if date:
        day_start = datetime.fromisoformat(date)
        day_end = day_start + timedelta(days=1)
        query = query.where(Meeting.start_time.between(day_start, day_end))
    meetings = session.exec(query.order_by(Meeting.start_time.desc())).all()
    return {"code": 0, "data": jsonable_encoder(meetings)}

@router.post('/join/{meeting_id}')
def 加入会议(meeting_id: int, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, meeting_id)
    if not meeting:
        raise HTTPException(404, "会议不存在")
    # 如果会议 URL 未生成（异常情况），返回 500
    if not meeting.jitsi_url:
        raise HTTPException(500, "会议URL缺失")
    return {"code": 0, "data": {"jitsi_url": meeting.jitsi_url}}

@router.post('/leave/{meeting_id}')
def 退出会议(meeting_id: int):
    return {"code": 0, "msg": "已退出会议"}

@router.post('/end/{meeting_id}')
def 结束会议(meeting_id: int, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, meeting_id)
    if not meeting:
        raise HTTPException(404, "会议不存在")
    meeting.status = 'finished'
    session.add(meeting)
    session.commit()
    return {"code": 0, "msg": "会议已结束"}

@router.get('/info/{meeting_id}')
def 会议信息(meeting_id: int, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, meeting_id)
    if not meeting:
        raise HTTPException(404, "会议不存在")
    return {"code": 0, "data": meeting}

@router.post('/token')
def 获取会议token(data: TokenRequest, authorization: str | None = Header(default=None)):
    """返回 Jitsi JWT，用于前端/APP 调用。

    当前示例仅演示签发，不校验系统登录 token。生产环境应解析 Authorization，
    校验用户身份后再签发。
    """
    s = get_settings()
    jitsi = Jitsi会议客户端(domain=s.jitsi_domain, app_id=s.jitsi_app_id, app_secret=s.jitsi_app_secret,
                          muc_domain=s.jitsi_muc_domain)
    # 使用请求头或随机用户 ID
    user_name = secrets.token_hex(4)
    jwt_url = jitsi.生成会议链接(room_name=data.room, user_name=user_name)
    # 拆出 token
    if 'jwt=' in jwt_url:
        token = jwt_url.split('jwt=')[1]
    else:
        token = ''
    return {"code": 0, "data": {"jwt": token}}

# ------------------- 调度管理接口 -------------------

@router.get('/live')
def 实时会议列表(session: Session = Depends(获取会话)):
    """获取当前进行中的会议列表。"""
    meetings = session.exec(select(Meeting).where(Meeting.status == 'ongoing').order_by(Meeting.start_time.desc())).all()
    return {"code": 0, "data": jsonable_encoder(meetings)}

class ParticipantsRequest(BaseModel):
    meeting_id: int

@router.post('/participants')
def 获取参会者列表(req: ParticipantsRequest, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, req.meeting_id)
    if not meeting:
        raise HTTPException(404, '会议不存在')
    s = get_settings()
    client = Jitsi会议客户端(domain=s.jitsi_domain, app_id=s.jitsi_app_id, app_secret=s.jitsi_app_secret,
                          muc_domain=s.jitsi_muc_domain)
    room_name = str(meeting.id)
    participants = client.列出参会者(room_name)
    # 持久化到数据库，便于后期统计
    meeting.participants = json.dumps(participants, ensure_ascii=False)
    session.add(meeting)
    session.commit()
    return {"code": 0, "data": participants}

class InviteRequest(BaseModel):
    meeting_id: int
    user: str  # 目标用户名或 ID

@router.post('/invite')
def 邀请用户(req: InviteRequest):
    """邀请用户加入会议（占位符）。"""
    # TODO: 实际实现通过推送 / Rocket.Chat DM / SMS 等方式通知用户
    return {"code": 0, "msg": f"已向 {req.user} 发送会议邀请"}

class KickRequest(BaseModel):
    meeting_id: int
    participant_id: str

@router.post('/kick')
def 踢出参会者(req: KickRequest, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, req.meeting_id)
    if not meeting:
        raise HTTPException(404, '会议不存在')
    s = get_settings()
    client = Jitsi会议客户端(domain=s.jitsi_domain, app_id=s.jitsi_app_id, app_secret=s.jitsi_app_secret,
                          muc_domain=s.jitsi_muc_domain)
    success = client.移除参会者(room_name=str(meeting.id), participant_id=req.participant_id)
    if not success:
        raise HTTPException(500, '踢出失败，服务器端未实现')
    return {"code": 0, "msg": '已踢出参会者'}

class ControlRequest(BaseModel):
    meeting_id: int
    participant_id: str
    action: str  # mute/unmute/video_on/video_off/camera_front/camera_back

@router.post('/control')
def 远程控制(req: ControlRequest, session: Session = Depends(获取会话)):
    meeting = session.get(Meeting, req.meeting_id)
    if not meeting:
        raise HTTPException(404, '会议不存在')

    s = get_settings()
    client = Jitsi会议客户端(domain=s.jitsi_domain, app_id=s.jitsi_app_id, app_secret=s.jitsi_app_secret,
                          muc_domain=s.jitsi_muc_domain)
    room = str(meeting.id)

    if req.action == 'mute':
        success = client.设置参会者静音(room, req.participant_id, mute=True)
    elif req.action == 'unmute':
        success = client.设置参会者静音(room, req.participant_id, mute=False)
    elif req.action in ('camera_front', 'camera_back'):
        camera = 'front' if req.action == 'camera_front' else 'back'
        success = client.切换参会者摄像头(room, req.participant_id, camera=camera)
    else:
        raise HTTPException(400, '未知 action')

    if not success:
        raise HTTPException(501, '该控制动作尚未实现')

    return {"code": 0, "msg": '控制指令已发送'} 