<template>
  <view class="room-root">
    <!-- 顶部导航 -->
    <view class="top-bar">
      <text class="back" @click="goBack">←</text>
      <text class="title">{{ titleText }}</text>
      <text class="time">{{ formattedTime }}</text>
    </view>

    <!-- 视频区 -->
    <Filmstrip
      ref="filmstrip"
      :myId="myId || '0'"
      class="filmstrip-fill"
      @switch-large="onSwitchLarge"
    />

    <!-- 底部工具栏 -->
    <Toolbox
      :micOn="micOn"
      :camOn="camOn"
      @toggle-mic="toggleMic"
      @toggle-cam="toggleCam"
      @hangup="leaveMeeting"
      @toggle-share="shareScreen"
      @toggle-participants="showParticipants=!showParticipants"
    />

    <!-- 右侧成员列表 -->
    <ParticipantsPane
      :visible="showParticipants"
      :members="members"
      :myId="myId"
      :isHost="isHost"
      @close="showParticipants=false"
      @kick="kickUser"
    />
  </view>
</template>

<script>
import Toolbox from './components/Toolbox.vue'
import Filmstrip from './components/Filmstrip.vue'
import ParticipantsPane from './components/ParticipantsPane.vue'
import { BASE_URL } from '../../config/index.js'
export default {
  components: { Toolbox, Filmstrip, ParticipantsPane },
  data () {
    return {
      meetingId: null,
      myId: null,
      isHost: false,
      micOn: true,
      camOn: true,
      showParticipants: false,
      members: [],
      startTime: null,
      audioAuto: true,
      videoAuto: true,
      meetingName: ''
    }
  },
  computed: {
    titleText() {
      return `会议 ${this.meetingName || (uni.getStorageSync('user_name')||'')} ${this.meetingId}`
    },
    formattedTime() {
      return this.startTime ? this.startTime.toLocaleString() : ''
    }
  },
  methods: {
    goBack () { uni.navigateBack() },
    async startMeeting() {
      // 获取jwt
      let jwt = ''
      try {
        const res = await uni.request({ url: BASE_URL + '/api/meeting/token', method: 'POST', data: { room: this.meetingId } })
        jwt = res.data?.data?.jwt || ''
      } catch (e) {
        uni.showToast({ title: '获取会议token失败', icon: 'none' })
        uni.navigateBack()
        return
      }
      // 调用原生Jitsi插件
      const jitsi = uni.requireNativePlugin('JitsiMeetModule')
      jitsi.launchMeeting(
        this.meetingId + '',
        uni.getStorageSync('user_name') || '用户',
        jwt,
        this.audioAuto,
        this.videoAuto,
        (ret) => {
          console.log('Jitsi插件回调:', ret); // 增加详细日志
          if (ret === true) {
            // 会议正常启动
          } else if (ret === false) {
            uni.showToast({ title: '启动会议失败', icon: 'none' })
            uni.navigateBack()
          } else if (ret && ret.code === 'END') {
            // 会议结束回调
            uni.showToast({ title: '会议已结束', icon: 'none' })
            uni.navigateBack()
          } else if (ret && ret.code === 'ERROR') {
            uni.showToast({ title: ret.msg || '会议异常', icon: 'none' })
            uni.navigateBack()
          } else {
            // 其他情况
            uni.showToast({ title: '会议异常', icon: 'none' })
            uni.navigateBack()
          }
        }
      )
    },
    toggleMic () {
      this.micOn = !this.micOn;
      const jitsi = uni.requireNativePlugin('JitsiMeetModule'); // 调用原生插件控制麦克风
      jitsi.toggleMic && jitsi.toggleMic(this.micOn);
    },
    toggleCam () {
      this.camOn = !this.camOn;
      const jitsi = uni.requireNativePlugin('JitsiMeetModule'); // 调用原生插件控制摄像头
      jitsi.toggleCam && jitsi.toggleCam(this.camOn);
    },
    leaveMeeting () {
      const jitsi = uni.requireNativePlugin('JitsiMeetModule'); // 调用原生插件挂断会议
      jitsi.hangup && jitsi.hangup();
      uni.navigateBack();
    },
    shareScreen () {
      const jitsi = uni.requireNativePlugin('JitsiMeetModule'); // 调用原生插件屏幕共享
      jitsi.shareScreen && jitsi.shareScreen();
    },
    onSwitchLarge (pid) { /* 如需同步成员侧栏高亮，可在此处理 */ },
    kickUser (u) { uni.showToast({ title:`已踢出 ${u.name||u.username}`, icon:'none' }) },
    onLoad (opt) {
      this.meetingId = opt.meeting_id || 'X';
      this.myId = uni.getStorageSync('user_id') || 'me';
      this.startTime = new Date();
      this.audioAuto = opt.audio === '1';
      this.videoAuto = opt.video === '1';
      this.micOn = this.audioAuto;
      this.camOn = this.videoAuto;
      this.meetingName = decodeURIComponent(opt.mname || '');
      // 等待 plusready 后再申请权限并启动会议，确保摄像头/麦克风可用
      const startFlow = () => {
      this.requestPermissions()
          .then(() => { this.startMeeting(); })
        .catch(() => {
          uni.showToast({ title: '未授予摄像头/麦克风权限', icon: 'none' });
          uni.navigateBack();
        });
      };
      if (window.plus) {
        startFlow();
      } else {
        document.addEventListener('plusready', startFlow, false);
      }
    },
    beforeDestroy () {
      const jitsi = uni.requireNativePlugin('JitsiMeetModule'); // 挂断并释放资源
      jitsi.hangup && jitsi.hangup();
    },
    requestPermissions() {
      return new Promise((resolve, reject) => {
        // #ifdef APP-PLUS
        if (!plus || !plus.android) return resolve();
        const perms = [
          'android.permission.CAMERA',
          'android.permission.RECORD_AUDIO'
        ];
        plus.android.requestPermissions(perms, (e) => {
          // 检查是否全部授权
          let allGranted = e.granted && e.granted.length === perms.length;
          if (allGranted) resolve();
          else reject();
        }, (e) => {
          console.warn('权限被拒绝', e);
          uni.showToast({ title: '未授予摄像头/麦克风权限，可能无法正常开会', icon: 'none' });
          reject();
        });
        // #endif
        // #ifndef APP-PLUS
        resolve();
        // #endif
      });
    }
  }
}
</script>

<style>
.room-root { width:100%;height:100vh;background:#000;display:flex;flex-direction:column; }
.top-bar { height:48px;background:#202124;color:#fff;display:flex;align-items:center;padding:0 12px; }
.back { font-size:20px;margin-right:12px; }
.title { flex:1;text-align:center;font-weight:bold; }
.time { color: #fff; font-size: 12px; position: absolute; top: 52px; left: 12px; }
.filmstrip-fill { flex:1; }
</style> 