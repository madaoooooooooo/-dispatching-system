"""群聊管理路由 (/api/chat/*)
对接 Rocket.Chat 群组功能，与接口文档保持一致。
"""
from typing import Optional, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from 后端.第三方.火箭聊天.客户端 import 火箭聊天客户端
from 后端.工具.配置 import get_settings

router = APIRouter(prefix="/api/chat", tags=["chat"])

rc_client: Optional[火箭聊天客户端] = None

def get_rc() -> 火箭聊天客户端:
    global rc_client
    if rc_client is None:
        s = get_settings()
        rc_client = 火箭聊天客户端(s.rocketchat_url, s.rocketchat_user, s.rocketchat_password, verify_ssl=False)
        rc_client.登录()
    return rc_client

class 创建群组请求(BaseModel):
    name: str
    members: Optional[List[str]] = None
    read_only: bool = False

@router.post('/group/create')
def 创建群组(data: 创建群组请求):
    rc = get_rc()
    try:
        group_id = rc.创建群组(data.name, data.members, data.read_only)
        return {"code": 0, "msg": "创建成功", "data": {"group_id": group_id}}
    except Exception as e:
        raise HTTPException(500, f"创建群组失败: {e}")

@router.get('/group/list')
def 获取群组列表():
    rc = get_rc()
    try:
        groups = rc.群组列表()
        return {"code": 0, "data": groups}
    except Exception as e:
        raise HTTPException(500, f"获取群组列表失败: {e}")

class 群组操作(BaseModel):
    room_id: str

@router.post('/group/join')
def 加入群组(data: 群组操作):
    rc = get_rc()
    try:
        rc.加入群组(data.room_id)
        return {"code": 0, "msg": "已加入群组"}
    except Exception as e:
        raise HTTPException(500, f"加入群组失败: {e}")

@router.post('/group/leave')
def 退出群组(data: 群组操作):
    rc = get_rc()
    try:
        rc.退出群组(data.room_id)
        return {"code": 0, "msg": "已退出群组"}
    except Exception as e:
        raise HTTPException(500, f"退出群组失败: {e}") 