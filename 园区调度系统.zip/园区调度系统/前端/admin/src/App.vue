<template>
  <router-view v-if="$route.path === '/login'" />
  <el-container v-else style="min-height: 100vh;">
    <el-aside width="200px">
      <el-menu :default-active="$route.path" router>
        <el-menu-item index="/">数据大屏</el-menu-item>
        <el-menu-item index="/map">实时定位</el-menu-item>
        <el-menu-item index="/meeting">会议管理</el-menu-item>
        <el-menu-item index="/dispatch">调度屏</el-menu-item>
        <el-menu-item index="/alarm">报警监控</el-menu-item>
        <el-menu-item index="/document">文档配置</el-menu-item>
        <el-sub-menu index="/user">
          <template #title>
            <span @click.stop="goUserProfile" style="cursor:pointer;">人员管理</span>
          </template>
          <el-menu-item index="/user/profile">资料</el-menu-item>
          <el-menu-item index="/user/org">组织</el-menu-item>
          <el-menu-item index="/user/role">角色</el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header style="background:#409EFF;color:#fff;font-size:20px;display:flex;justify-content:space-between;align-items:center;">
        <span>园区调度管理后台</span>
        <el-dropdown>
          <span class="el-dropdown-link" style="cursor:pointer;color:#fff;">
            {{ userInfo.name || '管理员' }}
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-header>
      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

const store = useStore()
const userInfo = computed(() => store.state.userInfo)
const router = useRouter()

function logout () {
  store.dispatch('logout')
}

function goUserProfile () {
  router.push('/user/profile')
}
</script>

<style scoped>
.el-header {
  padding: 0 16px;
}
</style> 