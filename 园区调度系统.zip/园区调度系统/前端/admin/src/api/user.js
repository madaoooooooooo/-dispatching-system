import request from './request'

// 用户登录
export function login(data) {
  return request({
    url: 'user/login',
    method: 'POST',
    data
  })
}

// 获取用户列表
export function fetchUserList(params) {
  return request({
    url: 'user/list',
    method: 'GET',
    params
  })
}

// 新增用户
export function addUser(data) {
  return request({
    url: 'user/add',
    method: 'POST',
    data
  })
}

// 编辑用户
export function editUser(userId, data) {
  return request({
    url: `user/edit/${userId}`,
    method: 'PUT',
    data
  })
}

// 删除用户
export function deleteUser(userId) {
  return request({
    url: `user/delete/${userId}`,
    method: 'DELETE'
  })
}

// 分配角色给用户
export function assignRole(userId, roleName) {
  return request({
    url: `user/assign_role/${userId}`,
    method: 'POST',
    data: { role: roleName }
  })
} 