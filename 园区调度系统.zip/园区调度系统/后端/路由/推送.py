from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import List
from 后端.工具.认证 import 解析令牌

router = APIRouter()

active_connections: List[WebSocket] = []

async def connect_ws(ws: WebSocket):
    await ws.accept()
    active_connections.append(ws)

async def disconnect_ws(ws: WebSocket):
    if ws in active_connections:
        active_connections.remove(ws)

# 广播 JSON 工具
async def 广播消息(message: dict):
    """向所有在线客户端广播 JSON 消息

    如果发送失败（连接已关闭），自动移除。
    """
    disconnect_list = []
    for ws in active_connections:
        try:
            await ws.send_json(message)
        except Exception:
            disconnect_list.append(ws)
    for ws in disconnect_list:
        await disconnect_ws(ws)

@router.websocket('/ws/connect')
async def websocket_endpoint(ws: WebSocket):
    token = ws.query_params.get('token')
    payload = 解析令牌(token) if token else None
    if not payload:
        await ws.close(code=1008)
        return
    await connect_ws(ws)
    try:
        while True:
            data = await ws.receive_text()
            if data == 'ping':
                await ws.send_text('pong')
    except WebSocketDisconnect:
        await disconnect_ws(ws)

# 兼容旧路径 /ws
@router.websocket('/ws')
async def websocket_endpoint_兼容(ws: WebSocket):
    # 旧前端可能不携带 token，允许匿名连接
    token = ws.query_params.get('token')
    payload = 解析令牌(token) if token else None
    await connect_ws(ws)
    try:
        while True:
            data = await ws.receive_text()
            if data == 'ping':
                await ws.send_text('pong')
    except WebSocketDisconnect:
        await disconnect_ws(ws) 