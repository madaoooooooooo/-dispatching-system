// axios 封装，统一处理请求拦截和响应拦截
import axios from 'axios'
import store from '@/store'
import router from '@/router'

// 创建 axios 实例
const service = axios.create({
  // 基础 URL 可根据环境变量动态修改
  baseURL: process.env.VUE_APP_BASE_API || '/api',
  timeout: 10000
})

// 请求拦截器：在发送请求之前附加 token
service.interceptors.request.use(
  (config) => {
    // 从 Vuex 中获取 token
    const token = store.state.token
    if (token) {
      // 将 token 放到请求头
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    // 请求错误处理
    return Promise.reject(error)
  }
)

// 响应拦截器：统一处理业务错误和 HTTP 错误
service.interceptors.response.use(
  (response) => {
    const res = response.data
    // 后端约定 code 为 0 表示成功
    if (res.code !== 0) {
      // 401 表示未认证或者 token 失效
      if (res.code === 1002) {
        store.dispatch('logout')
        router.push('/login')
      }
      // 将业务错误抛出，由调用方自行处理
      return Promise.reject(new Error(res.msg || '请求失败'))
    }
    return res
  },
  (error) => {
    // 处理 HTTP 错误
    if (error.response && error.response.status === 401) {
      store.dispatch('logout')
      router.push('/login')
    }
    return Promise.reject(error)
  }
)

export default service 