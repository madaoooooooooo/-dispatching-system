<template>
  <div class="alarm-container">
    <el-card>
      <div style="display:flex;align-items:center;margin-bottom:16px;">
        <el-select v-model="filter.type" placeholder="报警类型" style="width:150px;margin-right:8px;">
          <el-option label="全部" value="" />
          <el-option label="紧急" value="emergency" />
          <el-option label="火灾" value="fire" />
          <el-option label="安防" value="security" />
          <el-option label="医疗" value="medical" />
        </el-select>
        <el-select v-model="filter.level" placeholder="报警等级" style="width:150px;margin-right:8px;">
          <el-option label="全部" value="" />
          <el-option label="低" value="low" />
          <el-option label="中" value="medium" />
          <el-option label="高" value="high" />
          <el-option label="严重" value="critical" />
        </el-select>
        <el-date-picker v-model="filter.date" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" style="margin-right:8px;" />
        <el-button type="primary" @click="fetchData">查询</el-button>
    </div>

      <el-table :data="alarmList" style="width:100%;" :loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="type" label="类型" width="100" />
        <el-table-column prop="level" label="等级" width="100" />
        <el-table-column prop="description" label="描述" />
        <el-table-column prop="timestamp" label="时间" width="180" />
        <el-table-column label="操作" width="220">
          <template #default="scope">
            <el-button type="text" size="small" @click="onConfirm(scope.row)" :disabled="scope.row.status!=='new'">确认</el-button>
            <el-button type="text" size="small" @click="onHandle(scope.row)" :disabled="scope.row.status!=='confirmed'">处理</el-button>
            <el-button type="text" size="small" @click="onClose(scope.row)" :disabled="scope.row.status==='closed'">关闭</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        @current-change="fetchData"
        @size-change="fetchData"
        layout="total, sizes, prev, pager, next, jumper"
        :page-sizes="[10,20,50]"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { fetchAlarmList, confirmAlarm, handleAlarm, closeAlarm } from '@/api/alarm'
import { ElMessage, ElMessageBox } from 'element-plus'
import socket from '@/utils/socket'

const alarmList = ref([])
const loading = ref(false)
const page = ref(1)
const size = ref(10)
const total = ref(0)
const filter = reactive({ type: '', level: '', date: [] })

onMounted(() => {
  fetchData()
  socket.on('new_alarm', () => {
    fetchData()
  })
})

function fetchData () {
  loading.value = true
  const params = { page: page.value, size: size.value, type: filter.type, level: filter.level }
  if (filter.date && filter.date.length === 2) {
    params.start_time = filter.date[0]
    params.end_time = filter.date[1]
  }
  fetchAlarmList(params).then(res => {
    alarmList.value = res.data.list
    total.value = res.data.total
  }).finally(() => (loading.value = false))
}

function onConfirm (row) {
  ElMessageBox.confirm('确认该报警？', '提示', { type: 'warning' }).then(() => {
    confirmAlarm(row.id).then(() => {
      ElMessage.success('已确认')
      fetchData()
    })
  })
}

function onHandle (row) {
  ElMessageBox.confirm('标记为已处理？', '提示', { type: 'warning' }).then(() => {
    handleAlarm(row.id).then(() => {
      ElMessage.success('已处理')
      fetchData()
    })
  })
}

function onClose (row) {
  ElMessageBox.confirm('确定关闭该报警？', '提示', { type: 'warning' }).then(() => {
    closeAlarm(row.id).then(() => {
      ElMessage.success('已关闭')
      fetchData()
    })
  })
}
</script>

<style scoped>
.alarm-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style>
