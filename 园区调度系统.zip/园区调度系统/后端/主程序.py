import sys, pathlib
BASE_DIR = pathlib.Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import Session, select
from 后端.工具.数据库 import engine
from 后端.模型 import Permission

from 后端.工具.数据库 import 初始化数据库, 获取会话
from 后端 import 路由 as 全部路由
from 后端.模型 import User
from 后端.工具.认证 import 生成密码哈希
from 后端.第三方.自由交换.事件监听 import 启动事件监听
import asyncio
from sqlalchemy import inspect, text

app = FastAPI(title="园区调度系统后端", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化数据库
初始化数据库()

# 启动 FreeSWITCH 事件监听
@app.on_event("startup")
async def _start_listeners():
    loop = asyncio.get_event_loop()
    启动事件监听(loop)

@app.on_event("startup")
async def startup_event():
    # 插入默认权限
    with Session(engine) as session:
        existing = {p.name for p in session.exec(select(Permission)).all()}
        for perm in DEFAULT_PERMS:
            if perm not in existing:
                session.add(Permission(name=perm))
        session.commit()

    # 检查并补充 Meeting.participants 列（老数据库升级兼容）
    insp = inspect(engine)
    if 'meeting' in insp.get_table_names():
        cols = {c['name'] for c in insp.get_columns('meeting')}
        if 'participants' not in cols:
            with engine.begin() as conn:
                conn.execute(text('ALTER TABLE meeting ADD COLUMN participants TEXT'))
            print('[DB] 已自动为 meeting 表添加 participants 列')

    # 自动为 user 表添加新字段（若老库缺失）
    user_expected_cols = {
        'sex': 'TEXT', 'mobile': 'TEXT', 'tel': 'TEXT', 'id_card': 'TEXT',
        'entry_time': 'DATETIME', 'leave_time': 'DATETIME', 'org_id': 'INTEGER'
    }
    if 'user' in insp.get_table_names():
        existing_cols = {c['name'] for c in insp.get_columns('user')}
        for col, typ in user_expected_cols.items():
            if col not in existing_cols:
                with engine.begin() as conn:
                    conn.execute(text(f'ALTER TABLE user ADD COLUMN {col} {typ}'))
                print(f'[DB] user 表已添加列 {col}')

    # 创建默认管理员（放在字段补齐后）
    with Session(engine) as session:
        if not session.exec(select(User).where(User.username == 'admin')).first():
            session.add(User(username='admin', password_hash=生成密码哈希('admin123'), name='管理员', role='管理员'))
            session.commit()

# 注册路由
app.include_router(全部路由.用户路由)
app.include_router(全部路由.设备路由)
app.include_router(全部路由.报警路由)
app.include_router(全部路由.会议路由)
app.include_router(全部路由.定位路由)
app.include_router(全部路由.统计路由)
app.include_router(全部路由.推送路由)
app.include_router(全部路由.语音路由)
app.include_router(全部路由.通讯路由)
app.include_router(全部路由.群聊路由)
app.include_router(全部路由.推送接口路由)
app.include_router(全部路由.摄像头路由)
app.include_router(全部路由.系统路由)
app.include_router(全部路由.电话用户路由)
app.include_router(全部路由.火箭用户路由)
app.include_router(全部路由.组织路由)
app.include_router(全部路由.对讲信令路由)

# 默认权限列表
DEFAULT_PERMS = [
    'device_manage', 'user_manage', 'alarm_handle', 'meeting_manage'
]

@app.get("/")
async def root():
    return {"msg": "Backend is running"}


# 运行: uvicorn 后端.主程序:app --reload --port 8000
