<template>
  <div class="dashboard-container">
    <!-- 数据大屏 ECharts 图表区域 -->
    <div id="main-chart" style="width: 100%; height: 600px;"></div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
// 引入 ECharts
import * as echarts from 'echarts'
import { fetchSystemStats } from '@/api/statistics'

const chartInstance = ref(null)

onMounted(() => {
  initChart()
  loadData()
  // 每30秒刷新一次
  setInterval(loadData, 30000)
})

function initChart () {
  const chartDom = document.getElementById('main-chart')
  chartInstance.value = echarts.init(chartDom)
  chartInstance.value.setOption({
    title: { text: '园区调度数据大屏' },
    tooltip: {},
    legend: { data: ['设备在线数', '报警数'] },
    xAxis: { data: [] },
    yAxis: {},
    series: [
      { name: '设备在线数', type: 'bar', data: [] },
      { name: '报警数', type: 'line', data: [] }
    ]
  })
}

async function loadData () {
  try {
    const res = await fetchSystemStats()
    const { dates, device_online, alarm_count } = res.data // 假设后端这样返回
    chartInstance.value.setOption({
      xAxis: { data: dates },
      series: [
        { name: '设备在线数', data: device_online },
        { name: '报警数', data: alarm_count }
      ]
    })
  } catch (e) {
    console.error('统计数据获取失败', e)
  }
}
</script>

<style scoped>
.dashboard-container {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
</style>
