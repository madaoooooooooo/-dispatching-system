import os
from pathlib import Path
from sqlmodel import SQLModel, create_engine, Session

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # 项目根目录
DB_DIR = BASE_DIR / '数据库' / 'sqlite'
DB_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_URL = f'sqlite:///{DB_DIR}/数据.db'

engine = create_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False}
)


def 初始化数据库():
    """创建所有表"""
    import 后端.模型  # noqa: F401
    SQLModel.metadata.create_all(engine)


def 获取会话():
    """FastAPI 依赖，生成 session"""
    with Session(engine) as session:
        yield session 