import request from './request'

// 获取组织树
export function fetchOrgTree () {
  return request({ url: 'org/tree', method: 'GET' })
}

// 获取组织列表（平铺）
export function fetchOrgList () {
  return request({ url: 'org', method: 'GET' })
}

// 新增组织
export function addOrg (data) {
  return request({ url: 'org', method: 'POST', data })
}

// 更新组织
export function editOrg (orgId, data) {
  return request({ url: `org/${orgId}`, method: 'PUT', data })
}

// 删除组织
export function deleteOrg (orgId) {
  return request({ url: `org/${orgId}`, method: 'DELETE' })
} 