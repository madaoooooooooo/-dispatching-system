<template>
  <view class="intercom-container">
    <!-- 自定义栏 -->
    <view class="nav-bar">
      <text class="back" @click="goBack">←</text>
      <text class="title">对讲</text>
    </view>

    <view class="body">
      <view class="settings">
        <input v-model="customIp" placeholder="例如 10.10.10.117 或 10.10.10.117:8000" class="url-input" />
        <view class="btn-group">
          <button class="connect-btn" @click="connectCustom">连接</button>
          <button class="disconnect-btn" @click="disconnect">断开</button>
          <view class="listen-switch">
            <switch :checked="listening" @change="toggleListen" />
            <text class="switch-label">全局监听</text>
          </view>
        </view>
      </view>
      <button class="ptt"
              @touchstart="pressTalk" @touchend="releaseTalk"
              @mousedown="pressTalk" @mouseup="releaseTalk">
        按住 说话
      </button>
      <text class="hint">{{ currentStatus }}</text>
    </view>
  </view>
</template>

<script>
import intercom from '../../common/intercom.js'
export default {
  data() {
    return {
      unwatch: null,
      statusText: intercom.getStatus(),
      customIp: '10.10.10.117:8000',
      listening: true,
    }
  },
  computed: {
    // 实时读取连接状态，避免监听丢失
    currentStatus() {
      return intercom.getStatus()
    }
  },
  methods: {
    async init() {
      await intercom.init('default')
      // 监听状态文字
      this.unwatch = intercom.watchStatus((s) => {
        this.statusText = s
      })
      this.statusText = intercom.getStatus()
    },
    pressTalk() {
      console.log('[UI] pressTalk, wsState=', intercom.getStatus(), 'recorder=', intercom.__debug.recorder)
      intercom.enableMic(true)
      this.statusText = '发言中...'
    },
    releaseTalk() {
      console.log('[UI] releaseTalk, wsState=', intercom.getStatus(), 'recorder=', intercom.__debug.recorder)
      intercom.enableMic(false)
      this.statusText = '已静音'
    },
    goBack() {
      uni.navigateBack()
    },
    connectCustom() {
      const ip = this.customIp.trim()
      if (ip) {
        const wsUrl = `ws://${ip}/ws/intercom/default`
        intercom.init('default', wsUrl)
      } else {
        uni.showToast({ title: '请输入服务器 IP', icon: 'none' })
      }
    },
    disconnect() {
      intercom.disconnect()
    },
    toggleListen(e) {
      this.listening = e.detail.value
      console.log('[Intercom] 全局监听', this.listening)
      if (this.listening) {
        const ip = this.customIp.trim()
        const wsUrl = ip ? `ws://${ip}/ws/intercom/default` : null
        intercom.init('default', wsUrl)
      } else {
        intercom.disconnect()
      }
    },
  },
  mounted() {
    this.init()
  },
  onUnload() {
    if (this.unwatch) this.unwatch()
  }
}
</script>

<style>
.nav-bar {
  padding-top: var(--status-bar-height);
  height: calc(88rpx + var(--status-bar-height));
  background: #2196f3;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  color: #fff;
  font-size: 32rpx;
}
.back {
  position: absolute;
  left: 30rpx;
  font-size: 40rpx;
}
.title {
  font-weight: bold;
}
.body {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 120rpx;
}
.ptt {
  width: 300rpx;
  height: 300rpx;
  border-radius: 50%;
  background: #ffc107;
  color: #000;
  font-size: 32rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}
.hint {
  margin-top: 40rpx;
  color: #666;
}
.settings {
  width: 90%;
  margin: 0 auto 40rpx auto;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.url-input {
  width: 100%;
  padding: 16rpx 24rpx;
  background: #fff;
  border: 2rpx solid #ccc;
  border-radius: 12rpx;
  font-size: 28rpx;
}
.btn-group {
  margin-top: 24rpx;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.connect-btn,
.disconnect-btn {
  flex: 1;
  margin: 0 8rpx;
  padding: 20rpx 0;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #fff;
}
.connect-btn {
  background: #4caf50;
}
.disconnect-btn {
  background: #f44336;
}
.listen-switch {
  display: flex;
  align-items: center;
  margin-left: 16rpx;
}
.switch-label {
  margin-left: 12rpx;
  color: #333;
  font-size: 24rpx;
}
</style> 