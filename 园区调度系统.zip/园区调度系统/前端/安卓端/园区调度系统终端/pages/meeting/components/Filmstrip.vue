<template>
  <!-- Jitsi Web 风格视频排布 -->
  <div class="filmstrip-root">
    <!-- 大画面区域 -->
    <div class="large-video" ref="largeVideo"></div>

    <!-- 缩略条 -->
    <div class="thumbnails-wrapper">
      <!-- 本地缩略 -->
      <div class="thumb" :class="{ active: activeId===myId }" @click="select(myId)">
        <video v-if="tracks.local" ref="localVideo" autoplay muted playsinline></video>
        <div v-else class="placeholder self">我</div>
      </div>
      <!-- 远端缩略 -->
      <div
        v-for="(obj, pid) in tracks.remote"
        :key="pid"
        class="thumb"
        :class="{ active: activeId===pid }"
        @click="select(pid)"
      >
        <video v-if="obj.track" :ref="'remote_'+pid" autoplay playsinline></video>
        <div v-else class="placeholder">{{ pid }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Filmstrip',
  props: {
    myId: { type: [String, Number], required: true }
  },
  data () {
    return {
      /* 统一保存本地/远端视频 track 引用，供父组件调用 attach */
      tracks: {
        local: null, // 本地 video track
        remote: {}   // { pid: { track } }
      },
      activeId: null // 当前大画面对应的 participantId
    }
  },
  methods: {
    /* 供父组件调用，将 track 附着到缩略图 */
    attachLocal (track) {
      this.tracks.local = track;
      this.$nextTick(() => {
        const el = this.$refs.localVideo;
        el && track.attach(el);
        if (!this.activeId) this.select(this.myId);
      });
    },
    attachRemote (pid, track) {
      this.$set(this.tracks.remote, pid, { track });
      this.$nextTick(() => {
        const el = this.$refs['remote_'+pid];
        el && track.attach(el);
        if (!this.activeId) this.select(pid);
      });
    },
    detachRemote (pid) {
      this.$delete(this.tracks.remote, pid);
      if (this.activeId === pid) this.activeId = null;
    },
    /* 切换大画面 */
    select (pid) {
      this.activeId = pid;
      this.$emit('switch-large', pid);
    }
  }
}
</script>

<style scoped>
.filmstrip-root {
  position: relative;
  width: 100%;
  height: 100%;
  background: #000;
  display: flex;
  flex-direction: column;
  padding-bottom: 120px;
}
.large-video {
  flex: 1;
  background: #000;
}
.thumbnails-wrapper {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 120px;
  height: 88px;
  background: rgba(0,0,0,.6);
  display: flex;
  align-items: center;
  overflow-x: auto;
  padding: 0 8px;
}
.thumb {
  width: 120px;
  height: 72px;
  margin-right: 8px;
  background: #222;
  border-radius: 4px;
  overflow: hidden;
  border: 2px solid transparent;
  cursor: pointer;
}
.thumb.active { border-color: #0d6efd; }
.thumb video { width: 100%; height: 100%; object-fit: cover; }
.placeholder { color:#fff;display:flex;align-items:center;justify-content:center;width:100%;height:100%; font-size:14px; }
.placeholder.self { background:#003366; }
</style> 