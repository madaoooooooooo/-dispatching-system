"""Rocket.Chat REST API 客户端封装

供 FastAPI 业务逻辑调用，完成登录、发消息、创建群组等常用操作。
依赖 requests。
"""
import logging
from typing import Optional, Dict, Any, List

import requests

logger = logging.getLogger(__name__)


class 火箭聊天客户端:
    """Rocket.Chat 简易客户端"""

    def __init__(self, base_url: str, user: str, password: str, verify_ssl: bool = True):
        self.base_url = base_url.rstrip("/")
        self.user = user
        self.password = password
        self.verify_ssl = verify_ssl
        self._token: Optional[str] = None
        self._user_id: Optional[str] = None

    # ----------------------------------------
    # 内部工具
    # ----------------------------------------

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._token and self._user_id:
            headers.update({
                "X-Auth-Token": self._token,
                "X-User-Id": self._user_id,
            })
        return headers

    def _post(self, path: str, json_data: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        resp = requests.post(url, json=json_data, headers=self._headers(), verify=self.verify_ssl, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        resp = requests.get(url, params=params or {}, headers=self._headers(), verify=self.verify_ssl, timeout=10)
        resp.raise_for_status()
        return resp.json()

    # ----------------------------------------
    # 公开接口
    # ----------------------------------------

    def 登录(self) -> None:
        """使用用户名密码登录，缓存 token"""
        data = self._post("/api/v1/login", {"user": self.user, "password": self.password})
        if not data.get("status") == "success":
            raise RuntimeError(f"Rocket.Chat 登录失败: {data}")
        self._token = data["data"]["authToken"]
        self._user_id = data["data"]["userId"]
        logger.info("Rocket.Chat 登录成功 user=%s", self.user)

    def 发送消息(self, room_id: str, text: str) -> str:
        """向指定房间发送文本消息，返回 message_id"""
        payload = {"roomId": room_id, "text": text}
        data = self._post("/api/v1/chat.postMessage", payload)
        if not data.get("success"):
            raise RuntimeError(f"发送消息失败: {data}")
        return data["message"]["_id"]

    def 创建群组(self, name: str, members: Optional[List[str]] = None, read_only: bool = False) -> str:
        """创建群组并返回 group_id"""
        payload = {"name": name, "members": members or [], "readOnly": read_only}
        data = self._post("/api/v1/groups.create", payload)
        if not data.get("success"):
            raise RuntimeError(f"创建群组失败: {data}")
        return data["group"]["_id"]

    def 获取未读(self, room_id: str) -> int:
        """返回房间未读消息数量"""
        data = self._get("/api/v1/subscriptions.getOne", params={"roomId": room_id})
        if not data.get("success"):
            raise RuntimeError(f"获取未读失败: {data}")
        return data["subscription"].get("unread", 0)

    # ----------------------------------------
    # 消息/群组 维护
    # ----------------------------------------

    def 删除消息(self, room_id: str, message_id: str):
        payload = {"roomId": room_id, "msgId": message_id}
        data = self._post("/api/v1/chat.delete", payload)
        if not data.get("success"):
            raise RuntimeError(f"删除消息失败: {data}")

    def 群组列表(self):
        data = self._get("/api/v1/groups.list")
        if not data.get("success"):
            raise RuntimeError(f"获取群组列表失败: {data}")
        return data["groups"]

    def 加入群组(self, room_id: str):
        payload = {"roomId": room_id}
        data = self._post("/api/v1/groups.join", payload)
        if not data.get("success"):
            raise RuntimeError(f"加入群组失败: {data}")

    def 退出群组(self, room_id: str):
        payload = {"roomId": room_id}
        data = self._post("/api/v1/groups.leave", payload)
        if not data.get("success"):
            raise RuntimeError(f"退出群组失败: {data}")

    # ----------------------------------------
    # 文件操作
    # ----------------------------------------

    def 获取文件下载(self, file_id: str) -> bytes:
        url = f"{self.base_url}/api/v1/files.get"
        params = {"fileId": file_id}
        resp = requests.get(url, params=params, headers=self._headers(), verify=self.verify_ssl, timeout=30)
        resp.raise_for_status()
        return resp.content

    def 分享文件(self, room_id: str, file_id: str):
        payload = {"roomId": room_id, "fileId": file_id}
        data = self._post("/api/v1/chat.shareFile", payload)
        if not data.get("success"):
            raise RuntimeError(f"文件分享失败: {data}")

    # ----------------------------------------
    # 文件上传 & 历史
    # ----------------------------------------

    def 上传文件(self, room_id: str, file_bytes: bytes, filename: str) -> str:
        """向房间上传文件，返回 file_id"""
        url = f"{self.base_url}/api/v1/rooms.upload/{room_id}"
        # form-data 需带 token 头而非在 headers
        headers = {
            "X-Auth-Token": self._token,
            "X-User-Id": self._user_id,
        }
        files = {"file": (filename, file_bytes)}
        resp = requests.post(url, files=files, headers=headers, verify=self.verify_ssl, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if not data.get("success"):
            raise RuntimeError(f"文件上传失败: {data}")
        return data["file"]["_id"]

    def 获取历史(self, room_id: str, count: int = 50):
        """获取房间消息历史，返回列表"""
        params = {"roomId": room_id, "count": count}
        data = self._get("/api/v1/channels.history", params=params)
        if not data.get("success"):
            raise RuntimeError(f"获取历史失败: {data}")
        return data["messages"] 