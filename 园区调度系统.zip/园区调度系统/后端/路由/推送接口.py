"""推送管理接口 (/api/push/*)
利用 WebSocket 广播实现推送历史记录。
"""
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlmodel import Session, select

from 后端.路由.推送 import 广播消息
from 后端.工具.数据库 import 获取会话
from 后端.模型 import PushLog

router = APIRouter(prefix="/api/push", tags=["push"])

class 推送请求(BaseModel):
    type: str
    data: Optional[dict] = None

@router.post('/send')
async def 发送推送(req: 推送请求, session: Session = Depends(获取会话)):
    payload = {"type": req.type, "data": req.data, "timestamp": datetime.utcnow().isoformat()}
    await 广播消息(payload)
    session.add(PushLog(type=req.type, data=str(req.data)))
    session.commit()
    return {"code": 0, "msg": "推送已发送"}

@router.post('/broadcast')
async def 广播(req: 推送请求, session: Session = Depends(获取会话)):
    return await 发送推送(req, session)

@router.get('/history')
def 推送历史(count: int = 50, session: Session = Depends(获取会话)):
    logs = session.exec(select(PushLog).order_by(PushLog.timestamp.desc()).limit(count)).all()
    return {"code": 0, "data": logs} 