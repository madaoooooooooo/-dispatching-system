from typing import Optional
from sqlmodel import SQLModel, Field
from datetime import datetime

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, nullable=False, unique=True)
    password_hash: str
    name: str
    sex: Optional[str] = None  # male/female/other
    mobile: str | None = None  # 手机号
    tel: str | None = None  # 电话/座机
    id_card: Optional[str] = None  # 身份证号
    entry_time: Optional[datetime] = None  # 入职时间
    leave_time: Optional[datetime] = None  # 离职时间
    status: str = 'active'  # active=在职 / left=离职
    role: str
    org_id: Optional[int] = Field(default=None, foreign_key="organization.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Device(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    device_id: str = Field(index=True, nullable=False, unique=True)
    name: str
    type: str
    status: str = 'offline'
    battery: Optional[int] = 0
    last_active: Optional[datetime]
    lat: Optional[float]
    lng: Optional[float]

class Alarm(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    device_id: str
    type: str
    level: str
    description: str
    lat: Optional[float]
    lng: Optional[float]
    status: str = 'new'
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Meeting(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str] = None
    start_time: datetime
    duration: int
    status: str = 'upcoming'  # upcoming/ongoing/finished
    jitsi_url: Optional[str]
    participants: Optional[str] = None  # JSON 字符串，保存当前参会者列表

class Location(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    device_id: str
    lat: float
    lng: float
    type: str  # gps/wifi/hybrid
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Role(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(unique=True)
    description: Optional[str] = None

class Permission(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(unique=True)
    description: Optional[str] = None

class UserRole(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    role_id: int = Field(foreign_key="role.id")

class RolePermission(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    role_id: int = Field(foreign_key="role.id")
    permission_id: int = Field(foreign_key="permission.id")

class DocCategory(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str] = None

class Document(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    path: str
    size: int  # KB
    category_id: Optional[int] = Field(foreign_key="doccategory.id")
    upload_time: datetime = Field(default_factory=datetime.utcnow)

class SystemLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    level: str  # info/warning/error
    message: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class Geofence(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    coordinates: str  # GeoJSON 字符串或自定义格式
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PushLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    type: str
    data: str  # JSON 字符串
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# ------------------- 摄像头 / 语音广播 / 系统 -------------------

class Camera(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    camera_id: str = Field(unique=True)
    name: str
    status: str = 'offline'

class VoiceBroadcast(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    status: str = 'ongoing'  # ongoing/finished
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: Optional[datetime]

class IntercomGroup(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    members: str  # JSON 数组字符串

class Backup(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    path: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class SystemConfig(SQLModel, table=True):
    id: int = Field(default=1, primary_key=True)
    configs: str  # JSON

class OperationLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user: str
    action: str
    detail: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# ------------------- FreeSWITCH 分机用户 -------------------

class SipUser(SQLModel, table=True):
    """内部电话 SIP 分机用户表

    保存分机号、SIP 密码以及可选的系统用户关联。
    """
    id: Optional[int] = Field(default=None, primary_key=True)
    extension: str = Field(unique=True, index=True)
    password: str
    display_name: Optional[str] = None
    bind_user: Optional[int] = Field(default=None, foreign_key="user.id")
    status: str = "active"

# ------------------- 组织管理 -------------------

class Organization(SQLModel, table=True):
    """组织/部门表

    支持父子层级，通过 parent_id 自引用实现树结构。
    """
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    parent_id: Optional[int] = Field(default=None, foreign_key="organization.id")
    description: Optional[str] = None 