const CopyWebpackPlugin = require('copy-webpack-plugin')
const path = require('path')
const cesiumBuild = 'node_modules/cesium/Build/Cesium'
const webpack = require('webpack')

module.exports = {
  configureWebpack: {
    plugins: [
      new CopyWebpackPlugin({
        patterns: [
          { from: path.join(cesiumBuild, 'Workers'), to: 'Cesium/Workers' },
          { from: path.join(cesiumBuild, 'Assets'), to: 'Cesium/Assets' },
          { from: path.join(cesiumBuild, 'ThirdParty'), to: 'Cesium/ThirdParty' },
          { from: path.join(cesiumBuild, 'Widgets'), to: 'Cesium/Widgets' }
        ]
      }),
      new webpack.DefinePlugin({
        CESIUM_BASE_URL: JSON.stringify('./Cesium'),
        __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: false
      })
    ],
    resolve: {
      alias: {
        cesium: path.resolve(__dirname, cesiumBuild)
      }
    },
    module: {
      rules: [
        {
          test: /cesium[\\/]Build[\\/]Cesium[\\/].*\.js$/,
          type: 'javascript/auto',
          use: {
            loader: 'babel-loader',
            options: {
              presets: [['@babel/preset-env', { targets: { esmodules: true }, modules: false }]],
              plugins: ['@babel/plugin-syntax-import-meta']
            }
          }
        }
      ]
    }
  },
  devServer: {
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        pathRewrite: { '^/api': '/api' }
      },
      '/ws/connect': {
        target: 'ws://localhost:8000',
        changeOrigin: true,
        ws: true,
        pathRewrite: { '^/ws/connect': '/ws/connect' }
      }
    }
  },
  publicPath: '/'
} 