<template>
  <div class="map-container">
    <el-radio-group v-model="mode" style="margin-bottom: 16px;">
      <el-radio-button label="2D">2D自定义地图</el-radio-button>
      <el-radio-button label="3D">3D园区白模</el-radio-button>
    </el-radio-group>
    <div v-show="mode === '2D'">
      <div id="custom-map" style="width: 100%; height: 700px;"></div>
    </div>
    <div v-show="mode === '3D'">
      <div id="cesiumContainer" style="width: 100%; height: 700px;"></div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import * as L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import * as Cesium from 'cesium'
import 'cesium/Widgets/widgets.css'
import { fetchDeviceList } from '@/api/device'
import socket from '@/utils/socket'

const mode = ref('2D')
let leafletMap = null
let cesiumViewer = null

onMounted(() => {
  initLeaflet()
  loadDeviceMarkers()
  watch(mode, (val) => {
    if (val === '2D') {
      setTimeout(() => {
        initLeaflet()
        loadDeviceMarkers()
      }, 100)
    } else {
      setTimeout(() => {
        initCesium()
        loadDeviceMarkers3D()
      }, 100)
    }
  })
  // 监听实时位置更新
  socket.on('location_update', (data) => {
    // data: { device_id, lat, lng }
    if (mode.value === '2D') {
      L.marker([data.lat, data.lng]).addTo(leafletMap)
    } else {
      cesiumViewer.entities.add({
        position: Cesium.Cartesian3.fromDegrees(data.lng, data.lat, 10),
        billboard: { image: '/static/marker.png', width: 32, height: 32 }
      })
    }
  })
})

// 加载设备列表并渲染 2D 地图
async function loadDeviceMarkers () {
  const res = await fetchDeviceList()
  res.data.list.forEach(device => {
    const { lat, lng } = device.location || {}
    if (!lat || !lng) return
    L.marker([lat, lng])
      .addTo(leafletMap)
      .bindPopup(`${device.name}`)
  })
}

// 加载设备列表并渲染 3D 场景
async function loadDeviceMarkers3D () {
  const res = await fetchDeviceList()
  res.data.list.forEach(device => {
    const { lat, lng } = device.location || {}
    if (!lat || !lng) return
    cesiumViewer.entities.add({
      position: Cesium.Cartesian3.fromDegrees(lng, lat, 10),
      billboard: { image: '/static/marker.png', width: 32, height: 32 },
      label: { text: device.name, font: '14px sans-serif', fillColor: Cesium.Color.WHITE }
    })
  })
}

function initLeaflet() {
  if (leafletMap) {
    leafletMap.remove()
    leafletMap = null
  }
  leafletMap = L.map('custom-map').setView([31.2304, 121.4737], 16)
  L.tileLayer('http://localhost:8081/tiles/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '自定义地图'
  }).addTo(leafletMap)
}

function initCesium() {
  if (cesiumViewer) {
    cesiumViewer.destroy()
    cesiumViewer = null
  }
  cesiumViewer = new Cesium.Viewer('cesiumContainer', {
    timeline: false,
    animation: false,
    baseLayerPicker: false,
    geocoder: false,
    homeButton: false,
    sceneModePicker: false,
    navigationHelpButton: false,
    infoBox: false,
    selectionIndicator: false
  })
  // 加载园区白模（请替换为你的gltf模型路径）
  cesiumViewer.scene.primitives.add(
    Cesium.Model.fromGltf({
      url: '/static/park.gltf',
      modelMatrix: Cesium.Transforms.eastNorthUpToFixedFrame(
        Cesium.Cartesian3.fromDegrees(121.4737, 31.2304, 0)
      ),
      scale: 1.0
    })
  )
}
</script>

<style scoped>
.map-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style>
