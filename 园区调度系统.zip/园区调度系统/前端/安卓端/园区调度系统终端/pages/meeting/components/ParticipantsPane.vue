<template>
  <!-- Jitsi Web 风格右侧成员列表 -->
  <transition name="slide">
    <div v-if="visible" class="pane-root">
      <!-- 头部 -->
      <div class="pane-header">
        <span>与会者 ({{ members.length }})</span>
        <button class="close" @click="$emit('close')">×</button>
      </div>
      <!-- 列表 -->
      <div class="pane-body">
        <div v-for="m in members" :key="m.id" class="user-row" :class="{ me: m.id===myId }">
          <img class="avatar" :src="avatarUrl(m)" />
          <span class="name">{{ m.name || m.username }}</span>
          <span class="icon">{{ m.audioOn ? '🎙️' : '🔇' }}</span>
          <span class="icon">{{ m.videoOn ? '📹' : '📷' }}</span>
          <button v-if="isHost && m.id!==myId" class="kick" @click="$emit('kick', m)">踢出</button>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'ParticipantsPane',
  props: {
    visible: Boolean,
    members: Array,
    myId: [String, Number],
    isHost: Boolean
  },
  data () {
    const base = 'https://meet.jit.si/images/toolbox/';
    return {
      icons: {
        mic: base + 'microphone.svg',
        micOff: base + 'microphone-disabled.svg',
        cam: base + 'camera.svg',
        camOff: base + 'camera-disabled.svg'
      }
    }
  },
  methods: {
    avatarUrl (m) {
      // 如有用户头像字段可替换，此处占位
      return 'https://meet.jit.si/images/avatar2.png';
    }
  }
}
</script>

<style scoped>
.slide-enter-active, .slide-leave-active { transition: transform .3s ease; }
.slide-enter, .slide-leave-to { transform: translateX(100%); }
.pane-root {
  position: fixed;
  top: 0;
  right: 0;
  width: 320px;
  height: 100vh;
  background: #262626;
  color: #fff;
  display: flex;
  flex-direction: column;
  z-index: 950;
}
.pane-header {
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  background: #202124;
  font-size: 16px;
  font-weight: bold;
}
.close { background:none;border:none;color:#fff;font-size:24px; }
.pane-body { flex:1; overflow-y:auto; }
.user-row {
  display: flex;
  align-items: center;
  padding: 8px 16px;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
.user-row.me { background: rgba(255,255,255,.05); }
.avatar { width:32px;height:32px;border-radius:16px;margin-right:8px; }
.name { flex:1; }
.icon { width:20px;height:20px;margin:0 4px;font-size:18px; }
.kick { background:#d93025;border:none;color:#fff;font-size:12px;padding:2px 6px;border-radius:4px; }
</style> 