<template>
  <view class="cp-container">
    <view class="nav-bar">
      <text class="back" @click="goBack">←</text>
      <text class="nav-title">修改密码</text>
    </view>
    <view class="form">
      <input v-model="form.old" type="password" placeholder="旧密码" class="input" />
      <input v-model="form.new1" type="password" placeholder="新密码" class="input" />
      <input v-model="form.new2" type="password" placeholder="再次输入新密码" class="input" />
      <button class="btn" @click="submit">提交</button>
    </view>
  </view>
</template>

<script>
import { BASE_URL } from '../../config/index.js'
export default {
  data() {
    return {
      form: { old: '', new1: '', new2: '' }
    }
  },
  methods: {
    goBack() {
      uni.navigateBack()
    },
    async submit() {
      const { old, new1, new2 } = this.form
      if (!old || !new1 || !new2) {
        uni.showToast({ title: '请填写完整', icon: 'none' })
        return
      }
      if (new1 !== new2) {
        uni.showToast({ title: '两次密码不一致', icon: 'none' })
        return
      }
      const token = uni.getStorageSync('token')
      const info = uni.getStorageSync('user_info') || {}
      const userId = info.id
      if (!userId) {
        uni.showToast({ title: '用户信息缺失，请重新登录', icon: 'none' })
        return
      }
      try {
        const res = await uni.request({
          url: `${BASE_URL}/api/user/edit/${userId}`,
          method: 'PUT',
          header: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          data: { password: new1 }
        })
        const data = res.data || res[1]?.data
        if (data && data.code === 0) {
          uni.showToast({ title: '修改成功，请重新登录', icon: 'success' })
          setTimeout(() => {
            uni.clearStorageSync()
            uni.reLaunch({ url: '/pages/login/login' })
          }, 800)
        } else {
          uni.showToast({ title: (data && data.msg) || '修改失败', icon: 'none' })
        }
      } catch (e) {
        uni.showToast({ title: '网络错误', icon: 'none' })
      }
    }
  }
}
</script>

<style lang="scss">
.cp-container {
  display: flex;
  flex-direction: column;
  padding: 0;
}
.nav-bar {
  padding-top: var(--status-bar-height);
  height: calc(88rpx + var(--status-bar-height));
  background: #2196f3;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  color: #fff;
  font-size: 32rpx;
}
.back {
  position: absolute;
  left: 30rpx;
  font-size: 40rpx;
}
.nav-title {
  font-weight: bold;
}
.form {
  margin-top: 100rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30rpx;
}
.input {
  width: 80%;
  height: 88rpx;
  border: 1rpx solid #ccc;
  border-radius: 8rpx;
  padding: 0 20rpx;
}
.btn {
  width: 80%;
  background: #2196f3;
  color: #fff;
  border-radius: 8rpx;
  height: 88rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30rpx;
}
</style> 