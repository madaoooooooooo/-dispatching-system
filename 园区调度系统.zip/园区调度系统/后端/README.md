# 园区调度系统后端说明

## 简介
本目录为园区调度系统后端，基于 FastAPI + SQLModel 实现，支持 IM、会议、对讲、报警、推送等综合调度功能。后端已集成 Rocket.Chat、Jitsi Meet、FreeSWITCH，支持 WebSocket 实时推送。

---

## 主要功能
- 用户、设备、会议、定位、报警等 RESTful API
- Rocket.Chat IM 消息、群组、文件、历史
- Jitsi 会议创建，支持 JWT 鉴权
- FreeSWITCH 语音对讲（呼叫、挂断、事件推送）
- WebSocket 实时推送（报警、通话、系统消息等）
- 统一权限、认证、操作日志

---

## 目录结构
```
后端/
├─ 应用/           # 业务代码
├─ 工具/           # 通用工具、配置、认证、数据库
├─ 路由/           # 各业务API路由
├─ 第三方/         # Rocket.Chat、Jitsi会议、自由交换(FreeSWITCH)客户端
├─ 辅助工具/       # 预留
├─ 主程序.py       # FastAPI入口
├─ 依赖清单.txt    # requirements.txt
├─ README.md       # 本说明
```

---

## 部署与运行

### 后端准备清单（私有化部署前快速核查）
1. 启动方式
   - 开发环境：`python -m uvicorn 后端.主程序:app --reload --port 8000`
   - 生产/云服务器：`docker compose up -d`
2. 接口文档：浏览 `http://<host>:8000/docs` 可实时查看全部 API，便于调试。
3. CORS 已全开，前端域名无须额外配置。
4. 认证与 JWT
   - 默认管理员：`admin / admin123`
   - 登录获取 token 后，在请求头加入 `Authorization: Bearer <token>`
5. WebSocket
   - 连接：`ws://<host>:8000/ws/connect?token=<jwt>`
   - 心跳：前端每 30 秒发送 `ping`，后端返回 `pong`。
6. 文件上传示例
   ```js
   uni.uploadFile({
     url: baseURL + '/api/message/file/upload?room_id=ROOM123',
     filePath: tempPath,
     name: 'file',
     header: { Authorization: 'Bearer ' + token }
   })
   ```
7. 数据库
   - 首次启动 `SQLModel` 会自动为缺失表建表（无需手动迁移）。
   - 若迁移到 MySQL，只需修改 `DATABASE_URL` 并使用 Alembic 生成迁移脚本。

---

## 主要依赖
- fastapi、uvicorn、sqlmodel、pydantic
- requests、python-jose、passlib
- freeswitch-esl（对讲）、python-dotenv

---

## 第三方服务集成
- **Rocket.Chat**：IM/群聊/文件/推送，容器服务名 `rocketchat`
- **Jitsi Meet**：会议/视频/语音，容器服务名 `jitsi_web`
- **FreeSWITCH**：语音对讲，容器服务名 `freeswitch`，ESL端口8021，SIP端口5060

---

## 主要接口说明（部分）
- `/api/user/login` 用户登录
- `/api/device/list` 设备列表
- `/api/meeting/create` 创建会议（返回带JWT的jitsi_url）
- `/api/message/send` 发送IM消息
- `/api/message/history` 获取IM历史
- `/api/message/file/upload` 上传文件
- `/api/voice/call/start` 发起对讲
- `/api/voice/call/hangup/{uuid}` 挂断对讲
- `/api/alarm/report` 上报报警
- `/ws/connect` WebSocket实时推送

详见 `../文档/接口文档.md`

---

## WebSocket 推送类型
- `device_status_change` 设备状态变更
- `location_update` 位置更新
- `new_alarm` 新报警
- `meeting_notification` 会议通知
- `system_message` 系统消息
- `voice_call_event` 对讲事件（FreeSWITCH）

---

## 环境变量与配置
- 支持 `.env` 文件或 Docker Compose `environment` 覆盖
- 主要参数：
  - `rocketchat_url` Rocket.Chat地址
  - `rocketchat_user` Rocket.Chat管理员
  - `rocketchat_password` Rocket.Chat密码
  - `jitsi_domain` Jitsi域名
  - `jitsi_app_id` Jitsi JWT AppID
  - `jitsi_app_secret` Jitsi JWT密钥
  - `freeswitch_host` FreeSWITCH主机
  - `freeswitch_port` FreeSWITCH ESL端口
  - `freeswitch_password` FreeSWITCH ESL密码

---

## 注意事项
- 所有接口返回统一格式：`{"code":0, "msg":"ok", "data":..., "timestamp":...}`
- 认证接口需带 `Authorization: Bearer <token>`
- 详细接口参数、返回值请查阅 `../文档/接口文档.md`
- 建议所有部署均使用 docker compose，便于服务编排与升级

---

## 常见问题（Troubleshooting）

### 1. 局域网访问 `https://<IP>:8443` 报 400 Bad Request

**现象**：浏览器显示 `400 Bad Request – The plain HTTP request was sent to HTTPS port`。

**原因**：
1. 访问 URL 使用了 **HTTP** 协议，但 `jitsi_web` 8443 端口只接受 **HTTPS** 流量。
2. `PUBLIC_URL` 仍配置为 `https://localhost:8443`，当 Host 变成 `<IP>` 时，nginx 视为非法主机名同样会返回 400。

**解决方法**：
1. 在 `后端/第三方/Jitsi会议/Jitsi配置.env` 中将
   ```env
   PUBLIC_URL=https://<LAN_IP>:8443
   DOCKER_HOST_ADDRESS=<LAN_IP>
   ```
   替换为实际局域网地址，例如 `10.10.10.117`。
2. 重新执行
   ```powershell
   docker compose -p park down
   docker compose -p park up -d
   ```
3. 浏览器用 `https://<LAN_IP>:8443` 访问，若证书提示不安全请选择"继续访问"。

### 2. 手机/局域网设备无法加入会议（PreJoin rejected / ICE 失败）

**现象**：本机浏览器能创建会议，但第二台设备加入时提示 "Failed to get a successful response"、"PreJoin rejected undefined"等。

**原因**：媒体转发器 jitsi-jvb 的 UDP 端口 **10000** 未暴露，或被 Windows 防火墙阻断，导致 ICE 无法建立。

**解决方法**：
1. 在 `docker-compose.yml` 的 `jitsi_jvb` 服务下添加端口映射：
   ```yaml
   ports:
     - "10000:10000/udp"  # 已在代码仓库中添加
   ```
2. 放行防火墙（Windows）：
   ```powershell
   netsh advfirewall firewall add rule name="Jitsi JVB UDP 10000" dir=in action=allow protocol=UDP localport=10000
   ```
3. 重新 `docker compose -p park up -d` 后，再次加入会议即正常。

### 3. 修改 IP 后仍连到 localhost？

**定位**：在容器内查看 `/config/config.js`，若仍包含 `localhost`：
```powershell
# 查看
docker compose -p park exec jitsi_web bash -c "grep -E 'websocket|bosh' -n /config/config.js | head"
```

**快速修复**（一次性）：
```powershell
# 将 localhost 批量替换为实际局域网 IP，例如 10.10.10.117
docker compose -p park exec jitsi_web bash -c "sed -i 's|localhost|10.10.10.117|g' /config/config.js"
# 重启 web 容器
docker compose -p park restart jitsi_web
```
刷新浏览器即可。

**可选自动化**：
在 `启动后端.cmd` 的 compose 启动之后加入：
```bat
rem === 修正 Jitsi config.js 域名 ===
set LAN_IP=10.10.10.117   rem 请按实际 IP 修改
for /f %%i in ('docker compose -p park ps -q jitsi_web') do docker exec %%i sed -i "s|localhost|%LAN_IP%|g" /config/config.js >nul 2>&1
```
这样离线包部署完自动替换，无须每次手动进入容器。

---

## 联系与支持
如有问题请联系项目维护者或查阅接口文档。

---

## 离线部署与一键安装包方案

> 以下指南基于 **Windows Server** 环境，Linux 可参考思路自行修改脚本。
>
> 目标：在无公网的内网服务器上，通过**一个 EXE 文件**完成 Docker 安装、镜像导入、Compose 启动；亦支持将整体系统拆分为三台节点服务器分别部署。

### 1. 单节点离线包（ParkDeploy.exe）

1. 目录结构
   ```text
   park-package/
   ├─ compose/              # docker-compose.yml、.env.example
   ├─ images/               # park_images.tar.gz（所有镜像 save 后压缩）
   ├─ scripts/
   │  ├─ install.ps1        # PowerShell 部署脚本
   │  └─ docker-23.0.6.msi  # 可选：离线 Docker 安装包
   ├─ 7zS.sfx               # 7-Zip 自解压模块
   └─ build_sfx.cmd         # 一键打包为 EXE
   ```
2. 制作镜像包
   ```powershell
   docker compose build            # 构建 backend 镜像
   docker save \
     dockerproxy.com/jitsi/web:stable \
     dockerproxy.com/jitsi/prosody:stable \
     dockerproxy.com/jitsi/jvb:stable \
     dockerproxy.com/library/mongo:6 \
     dockerproxy.com/rocketchat/rocket.chat:latest \
     ghcr.io/ittoyxk/freeswitch:v1.10.11 \
     backend:latest \
     -o park_images.tar
   gzip park_images.tar            # 得到 park_images.tar.gz
   ```
3. PowerShell 安装脚本核心逻辑
   ```powershell
   param([string]$ip="127.0.0.1")
   # 1. 若无 Docker 则静默安装
   # 2. 生成 .env：把 {IP} 占位替换为实际 IP
   # 3. docker load -i images/park_images.tar.gz
   # 4. docker compose -p park up -d
   ```
4. build_sfx.cmd 将以上文件合并为 **ParkDeploy.exe**，用户只需双击 → 输入 IP → 自动完成。

### 2. 三节点拆分包

| 节点 | 承载服务 | EXE 名称 | 镜像内容 |
| ---- | -------- | -------- | -------- |
| Park-Core  | FastAPI 后端、Rocket.Chat、Mongo | park-core.exe | backend、rocket.chat、mongo |
| Park-Video | Jitsi-web / prosody / jvb        | park-video.exe | jitsi-web/prosody/jvb |
| Park-Voice | FreeSWITCH + ESL 监听            | park-voice.exe | freeswitch |

* 三个包的 `install_*.ps1` 均接受 `/ip=` 参数，用于写入各自 `.env`；
* 后端 `.env` 还需填写其它节点的地址，例如：
  ```env
  ROCKETCHAT_URL=http://{IP_CORE}:3000
  JITSI_URL=https://{IP_VIDEO}
  FREESWITCH_HOST={IP_VOICE}
  ```
  脚本可在安装时提示用户一次性填写。

### 3. NSIS 打包示例片段
```nsis
!include "MUI2.nsh"
OutFile "park-core.exe"
InstallDir "$PROGRAMFILES\ParkSystem-Core"
RequestExecutionLevel admin

; 页面流程
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
Page custom IPPage IPPageLeave  ; 让用户输入 IP
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

Section "Main"
  SetOutPath "$INSTDIR"
  File /r images\park_core.tar.gz
  File /r compose
  File scripts\install_core.exe
  DetailPrint "正在离线部署，请稍候…"
  ExecWait '"$INSTDIR\install_core.exe" /ip=$0'
SectionEnd
```
* **源码安全**：`