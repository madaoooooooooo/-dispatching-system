from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from sqlalchemy import func
from datetime import datetime, timedelta

from 后端.模型 import Device, Alarm
from 后端.工具.数据库 import 获取会话

router = APIRouter(prefix="/api/statistics", tags=["statistics"])

@router.get('/system')
def 系统统计(session: Session = Depends(获取会话)):
    # 最近7天设备在线数和报警数示例
    dates = []
    device_online = []
    alarm_count = []
    today = datetime.utcnow().date()
    try:
        for i in range(6, -1, -1):
            day = today - timedelta(days=i)
            next_day = day + timedelta(days=1)
            dates.append(day.strftime('%m-%d'))
            # 设备在线数
            online_row = session.exec(
                select(func.count()).select_from(Device).where(Device.status == 'online')
            ).first()
            online = online_row[0] if isinstance(online_row, (list, tuple)) else online_row or 0
            # 当日报警数
            alarms_row = session.exec(
                select(func.count()).select_from(Alarm).where(Alarm.timestamp.between(day, next_day))
            ).first()
            alarms = alarms_row[0] if isinstance(alarms_row, (list, tuple)) else alarms_row or 0
            device_online.append(online)
            alarm_count.append(alarms)
        return {"code": 0, "data": {"dates": dates, "device_online": device_online, "alarm_count": alarm_count}}
    except Exception as e:
        # 打印异常并返回空数据，防止前端报错
        print("系统统计接口异常：", e)
        return {"code": 0, "data": {"dates": dates or [today.strftime('%m-%d')], "device_online": [0]*7, "alarm_count": [0]*7}} 