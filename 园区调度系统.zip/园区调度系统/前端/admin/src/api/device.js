import request from './request'

// 获取设备列表
export function fetchDeviceList(params) {
  return request({
    url: '/device/list',
    method: 'GET',
    params
  })
}

// 上报设备状态
export function reportDeviceStatus(data) {
  return request({
    url: '/device/status',
    method: 'POST',
    data
  })
}

// 远程控制 - 示例重启
export function rebootDevice(deviceId) {
  return request({
    url: `/device/reboot/${deviceId}`,
    method: 'POST'
  })
} 