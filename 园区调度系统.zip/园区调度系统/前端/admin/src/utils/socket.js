// WebSocket 封装，支持事件订阅
// 这里使用浏览器原生 WebSocket 并简单实现事件分发

class WSService {
  constructor () {
    this.ws = null
    this.eventMap = {}
    // 开关逻辑：在开发环境(dev server)默认关闭，生产构建自动开启；
    // 如需在开发阶段测试，可在启动命令前注入环境变量 VUE_APP_ENABLE_WS=true
    const envFlag = process.env.VUE_APP_ENABLE_WS
    if (process.env.NODE_ENV === 'development') {
      this.enabled = envFlag === 'true'
    } else {
      this.enabled = envFlag !== 'false'
    }
  }

  connect (token) {
    if (!this.enabled) {
      // 开发阶段可通过 VUE_APP_ENABLE_WS=false 关闭连接以避免无后端刷屏
      console.info('[WS] 已禁用，跳过建立连接')
      return
    }
    if (this.ws) return
    const wsOrigin = window.location.protocol === 'https:' ? 'wss://' : 'ws://'
    // 默认使用当前 host，但若前端在 8080 端口运行（开发环境），则将端口改为 8000 转到后端
    const { hostname, port } = window.location
    // 允许通过环境变量 VUE_APP_WS_PORT 指定后端端口，优先级最高
    const backendPort = process.env.VUE_APP_WS_PORT || (port === '8080' ? '8000' : port)
    const wsUrl = `${wsOrigin}${hostname}:${backendPort}/ws/connect?token=${token}`
    this.ws = new WebSocket(wsUrl)
    this.ws.onmessage = (event) => {
      const msg = JSON.parse(event.data)
      const handlers = this.eventMap[msg.type] || []
      handlers.forEach((cb) => cb(msg.data))
    }
    this.ws.onclose = () => {
      this.ws = null
      // 可实现重连逻辑
    }
  }

  on (event, handler) {
    if (!this.eventMap[event]) this.eventMap[event] = []
    this.eventMap[event].push(handler)
  }

  off (event, handler) {
    if (!this.eventMap[event]) return
    this.eventMap[event] = this.eventMap[event].filter((h) => h !== handler)
  }
}

export default new WSService() 