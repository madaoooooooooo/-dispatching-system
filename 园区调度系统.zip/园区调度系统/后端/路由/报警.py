from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlmodel import Session, select, col
from pydantic import BaseModel
from sqlalchemy import func
from datetime import datetime, timedelta
import asyncio

from 后端.模型 import Alarm
from 后端.工具.数据库 import 获取会话
from 后端.路由.推送 import 广播消息

router = APIRouter(prefix="/api/alarm", tags=["alarm"])

class 报警上报请求(BaseModel):
    device_id: str
    type: str
    level: str
    description: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None

@router.post('/report')
def 上报报警(data: 报警上报请求, session: Session = Depends(获取会话)):
    alarm = Alarm(device_id=data.device_id, type=data.type, level=data.level, description=data.description,
                  lat=data.lat, lng=data.lng)
    session.add(alarm)
    session.commit()
    # WebSocket 广播
    asyncio.create_task(广播消息({
        "type": "new_alarm",
        "data": {
            "id": alarm.id,
            "device_id": alarm.device_id,
            "level": alarm.level,
            "type": alarm.type,
            "description": alarm.description,
            "timestamp": str(alarm.timestamp)
        }
    }))
    return {"code": 0, "msg": "上报成功"}

@router.get('/list')
def 获取报警列表(page: int = 1, size: int = 20, type: Optional[str] = None, level: Optional[str] = None,
            session: Session = Depends(获取会话)):
    query = select(Alarm)
    if type:
        query = query.where(Alarm.type == type)
    if level:
        query = query.where(Alarm.level == level)
    count_row = session.exec(select(func.count()).select_from(Alarm)).first()
    total = count_row[0] if isinstance(count_row, (list, tuple)) else count_row
    alarms = session.exec(query.order_by(Alarm.timestamp.desc()).offset((page-1)*size).limit(size)).all()
    return {"code": 0, "data": {"total": total, "list": alarms}}

@router.post('/confirm/{alarm_id}')
def 确认报警(alarm_id: int, session: Session = Depends(获取会话)):
    alarm = session.get(Alarm, alarm_id)
    if not alarm:
        raise HTTPException(404, "报警不存在")
    alarm.status = 'confirmed'
    session.add(alarm)
    session.commit()
    return {"code": 0, "msg": "已确认"}

@router.post('/handle/{alarm_id}')
def 处理报警(alarm_id: int, session: Session = Depends(获取会话)):
    alarm = session.get(Alarm, alarm_id)
    if not alarm:
        raise HTTPException(404, "报警不存在")
    alarm.status = 'handled'
    session.add(alarm)
    session.commit()
    return {"code": 0, "msg": "已处理"}

@router.post('/close/{alarm_id}')
def 关闭报警(alarm_id: int, session: Session = Depends(获取会话)):
    alarm = session.get(Alarm, alarm_id)
    if not alarm:
        raise HTTPException(404, "报警不存在")
    alarm.status = 'closed'
    session.add(alarm)
    session.commit()
    return {"code": 0, "msg": "已关闭"}

# ------------------- 统计 -------------------

@router.get('/statistics')
def 报警统计(session: Session = Depends(获取会话)):
    total = session.exec(select(func.count()).select_from(Alarm)).first()[0]
    by_level = session.exec(select(Alarm.level, func.count()).group_by(Alarm.level)).all()
    return {"code": 0, "data": {"total": total, "by_level": by_level}}

# ------------------- 趋势 -------------------

@router.get('/trend')
def 报警趋势(days: int = 7, session: Session = Depends(获取会话)):
    end = datetime.utcnow()
    start = end - timedelta(days=days)
    rows = session.exec(select(func.date(Alarm.timestamp).label('d'), func.count()).where(Alarm.timestamp >= start).group_by('d').order_by('d')).all()
    return {"code": 0, "data": rows} 