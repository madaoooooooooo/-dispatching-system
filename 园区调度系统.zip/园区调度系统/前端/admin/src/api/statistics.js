import request from './request'

export function fetchSystemStats() {
  return request({
    url: '/statistics/system',
    method: 'GET'
  })
}

export function fetchDeviceStats() {
  return request({
    url: '/statistics/device',
    method: 'GET'
  })
}

export function fetchMeetingStats() {
  return request({
    url: '/statistics/meeting',
    method: 'GET'
  })
} 