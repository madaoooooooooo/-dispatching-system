"""FreeSWITCH ESL(Event Socket Library) 客户端封装

本模块用于在后端控制 FreeSWITCH，实现呼叫、挂断、DTMF 等操作，
以及订阅来电 / 事件通知。

依赖 pip 包: freeswitch-esl
镜像已在 docker-compose 中提供 freeswitch 服务，ESL 默认端口 8021，密码 'ClueCon'。
"""
from typing import Optional
import logging

try:
    import greenswitch  # type: ignore
except ImportError:  # 容器构建阶段可能尚未安装 greenswitch
    greenswitch = None  # type: ignore

logger = logging.getLogger(__name__)


class 自由交换客户端:
    """FreeSWITCH Event Socket 简易封装"""

    def __init__(self, host: str = "freeswitch", port: int = 8021, password: str = "ClueCon"):
        if greenswitch is None:
            raise RuntimeError("未安装 greenswitch，请检查依赖清单")
        self.host = host
        self.port = port
        self.password = password
        # greenswitch.InboundESL 实例
        self.conn: Optional["greenswitch.InboundESL"] = None
        self._connect()

    # ----------------------------------------
    def _connect(self):
        """建立 ESL 连接"""
        self.conn = greenswitch.InboundESL(host=self.host, port=self.port, password=self.password)
        self.conn.connect()
        if not self.conn.is_connected:
            raise ConnectionError(f"无法连接 FreeSWITCH ESL {self.host}:{self.port}")
        logger.info("连接 FreeSWITCH ESL 成功")

    # ----------------------------------------
    # 呼叫控制
    # ----------------------------------------

    def 外呼(self, from_ext: str, to_number: str, context: str = "public") -> str:
        """发起呼叫，返回 uuid"""
        cmd = f"originate {{origination_caller_id_number={from_ext}}}sofia/{context}/{to_number} &park()"
        response = self.conn.send(f"api {cmd}")
        uuid = (response.data or "").strip()
        logger.info("FreeSWITCH 外呼 cmd=%s uuid=%s", cmd, uuid)
        return uuid

    def 挂断(self, uuid: str):
        self.conn.send(f"api uuid_kill {uuid}")
        logger.info("FreeSWITCH 挂断 uuid=%s", uuid)

    def 发送_dtmf(self, uuid: str, digits: str):
        self.conn.send(f"api uuid_send_dtmf {uuid} {digits}")

    # ----------------------------------------
    # 事件订阅（示例：订阅全部）
    # ----------------------------------------

    def 订阅事件(self, event: str = "all"):
        if not self.conn:
            self._connect()
        self.conn.send(f"events plain {event}")
        logger.info("订阅 FreeSWITCH 事件: %s", event)

    def 获取事件(self, blocking: bool = True):
        if not self.conn:
            self._connect()
        if blocking:
            e = self.conn.recv()
        else:
            e = self.conn.recv(timeout=0.1)
        return e 