<template>
  <div class="role-manage-container">
    <el-card>
      <div style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;">
        <span style="font-size:18px;">角色管理</span>
        <div>
          <el-button type="primary" @click="showAdd">新增角色</el-button>
        </div>
      </div>
      <el-table :data="roleList" style="width:100%" :loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="角色名称" />
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="link" size="small" @click="editRole(scope.row)">编辑</el-button>
            <el-button type="link" size="small" @click="deleteRole(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/编辑弹窗 -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="500px">
      <el-form :model="form" ref="formRef" label-width="80px">
        <el-form-item label="名称" prop="name" :rules="[{ required: true, message: '请输入角色名称', trigger: 'blur' }]">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="权限" prop="permissions">
          <el-select v-model="form.permissions" multiple placeholder="选择权限" style="width:100%">
            <el-option v-for="p in permissionList" :key="p" :label="p" :value="p" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="onSubmit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
// 角色管理逻辑
import { ref, reactive, onMounted } from 'vue'
import { fetchRoleList, addRole as apiAddRole, editRole as apiEditRole, deleteRole as apiDeleteRole } from '@/api/role'
import { fetchPermissionList, setRolePermissions } from '@/api/permission'
import { ElMessage, ElMessageBox } from 'element-plus'

const loading = ref(false)
const roleList = ref([])
const permissionList = ref([])

const dialogVisible = ref(false)
const dialogTitle = ref('')
const form = reactive({ id: null, name: '', permissions: [] })
const formRef = ref(null)
const isEdit = ref(false)

onMounted(() => {
  loadRoles()
  loadPermissions()
})

function loadRoles () {
  loading.value = true
  fetchRoleList().then(res => {
    roleList.value = res.data || []
  }).finally(() => { loading.value = false })
}

function loadPermissions () {
  fetchPermissionList().then(res => {
    permissionList.value = res.data || []
  })
}

function showAdd () {
  dialogTitle.value = '新增角色'
  isEdit.value = false
  Object.assign(form, { id: null, name: '', permissions: [] })
  dialogVisible.value = true
}

function editRole (row) {
  dialogTitle.value = '编辑角色'
  isEdit.value = true
  Object.assign(form, { id: row.id, name: row.name, permissions: row.permissions || [] })
  dialogVisible.value = true
}

function deleteRole (row) {
  ElMessageBox.confirm('确定删除该角色吗?', '提示', { type: 'warning' }).then(async () => {
    await apiDeleteRole(row.id)
    ElMessage.success('删除成功')
    loadRoles()
  })
}

function onSubmit () {
  formRef.value.validate(async (valid) => {
    if (!valid) return
    if (isEdit.value) {
      await apiEditRole(form.id, { name: form.name })
      await setRolePermissions(form.id, form.permissions)
      ElMessage.success('已更新')
    } else {
      const res = await apiAddRole({ name: form.name })
      const roleId = res?.data?.id
      if (roleId) {
        await setRolePermissions(roleId, form.permissions)
      }
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    loadRoles()
  })
}
</script>

<style scoped>
.role-manage-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style> 