"""语音通话 / 对讲 路由

提供呼叫、接听、挂断接口，后台通过 FreeSWITCH ESL 调用完成动作。
注意：此示例仅作后台控制信令，具体媒体流仍需终端（如安卓 APK）使用 SIP/WebRTC 客户端接入。
"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from 后端.工具.配置 import get_settings
from 后端.第三方.自由交换.客户端 import 自由交换客户端

router = APIRouter(prefix="/api/voice/call", tags=["voice"])

# 全局 FreeSWITCH 客户端（简单示例）
fs_client: Optional[自由交换客户端] = None

def get_fs_client() -> 自由交换客户端:
    global fs_client
    if fs_client is None:
        s = get_settings()
        fs_client = 自由交换客户端(host=s.freeswitch_host, port=s.freeswitch_port, password=s.freeswitch_password)
    return fs_client

class 呼叫请求(BaseModel):
    caller: str  # 主叫分机 / 号码
    callee: str  # 被叫号码

class 挂断请求(BaseModel):
    uuid: str

class 广播请求(BaseModel):
    title: str

@router.post('/start')
def 发起呼叫(data: 呼叫请求):
    fs = get_fs_client()
    uuid = fs.外呼(from_ext=data.caller, to_number=data.callee)
    if not uuid:
        raise HTTPException(500, "呼叫失败")
    return {"code": 0, "msg": "呼叫已发起", "data": {"uuid": uuid}}

@router.post('/hangup/{uuid}')
def 挂断通话(uuid: str):
    fs = get_fs_client()
    fs.挂断(uuid)
    return {"code": 0, "msg": "已挂断"}

@router.post('/broadcast/start')
def 开始广播(data: 广播请求):
    # TODO: 调用 FreeSWITCH 实现群呼
    return {"code": 0, "msg": "广播已开始", "data": {"broadcast_id": 1}}

@router.post('/broadcast/stop/{broadcast_id}')
def 停止广播(broadcast_id: int):
    return {"code": 0, "msg": "广播已停止"}

# ------------------- 对讲 -------------------

class 对讲请求(BaseModel):
    group_id: Optional[int] = None
    members: Optional[list[str]] = None

@router.post('/intercom/start')
def 开始对讲(data: 对讲请求):
    return {"code": 0, "msg": "对讲已开始", "data": {"intercom_id": 1}}

@router.post('/intercom/stop/{intercom_id}')
def 结束对讲(intercom_id: int):
    return {"code": 0, "msg": "对讲已结束"}

@router.post('/intercom/group')
def 对讲群组(data: 对讲请求):
    return {"code": 0, "msg": "群组已创建", "data": {"group_id": 1}}

# FreeSWITCH 来电事件通知可通过 WebSocket 推送，此处略 