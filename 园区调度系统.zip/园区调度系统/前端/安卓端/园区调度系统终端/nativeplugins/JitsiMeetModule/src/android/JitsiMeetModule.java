package io.dcloud.feature.jitsimeet;

import android.app.Activity;
import io.dcloud.feature.uniapp.common.UniModule;
import io.dcloud.feature.uniapp.common.UniJSCallback;
import io.dcloud.feature.uniapp.common.annotation.UniJSMethod;
import org.jitsi.meet.sdk.JitsiMeet;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.content.Intent;

public class JitsiMeetModule extends UniModule {

    /**
     * 启动 Jitsi 会议
     */
    @UniJSMethod(uiThread = true)
    public void launchMeeting(String roomName, String displayName, String jwt,
                              boolean audioMuted, boolean videoMuted,
                              UniJSCallback callback) {
        try {
            Activity activity = getUniSDKInstance().getActivity();
            // 默认会议选项，请替换为你的 Jitsi 服务地址
            JitsiMeetConferenceOptions defaultOptions =
                new JitsiMeetConferenceOptions.Builder()
                    .setServerURL(new java.net.URL("https://your.jitsi.server"))
                    .setToken(jwt)
                    .setWelcomePageEnabled(false)
                    .build();
            JitsiMeet.setDefaultConferenceOptions(defaultOptions);

            // 构建会议启动参数
            JitsiMeetConferenceOptions options =
                new JitsiMeetConferenceOptions.Builder()
                    .setRoom(roomName)
                    .setAudioMuted(audioMuted)
                    .setVideoMuted(videoMuted)
                    .build();
            // 启动会议
            JitsiMeetActivity.launch(activity, options);
            callback.invoke(true);
        } catch (Exception e) {
            callback.invoke(false, e.getMessage());
        }
    }

    /** 切换麦克风静音/开麦 */
    @UniJSMethod(uiThread = true)
    public void toggleMic(boolean muted) {
        Intent intent = new Intent("org.jitsi.meet.SET_AUDIO_MUTED");
        intent.putExtra("muted", muted);
        LocalBroadcastManager.getInstance(getUniSDKInstance().getActivity()).sendBroadcast(intent);
    }

    /** 切换摄像头开/关 */
    @UniJSMethod(uiThread = true)
    public void toggleCam(boolean muted) {
        Intent intent = new Intent("org.jitsi.meet.SET_VIDEO_MUTED");
        intent.putExtra("muted", muted);
        LocalBroadcastManager.getInstance(getUniSDKInstance().getActivity()).sendBroadcast(intent);
    }

    /** 挂断会议 */
    @UniJSMethod(uiThread = true)
    public void hangup() {
        Intent intent = new Intent("org.jitsi.meet.HANG_UP");
        LocalBroadcastManager.getInstance(getUniSDKInstance().getActivity()).sendBroadcast(intent);
    }
} 