<template>
  <div class="user-manage-container">
    <el-card>
      <div style="margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
        <span style="font-size: 18px;">用户管理</span>
        <div>
          <el-button style="margin-right:8px" @click="openRoleDialog">角色管理</el-button>
          <el-button type="primary" @click="showAdd">新增用户</el-button>
        </div>
      </div>
      <el-table :data="userList" style="width: 100%" :loading="loading">
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="name" label="姓名" />
        <el-table-column prop="mobile" label="手机号" />
        <el-table-column prop="role" label="角色" />
        <el-table-column prop="status" label="在职状态">
          <template #default="scope">
            <span :style="{color: scope.row.status==='active'?'#67C23A':'#F56C6C'}">
              {{ scope.row.status==='active' ? '在职' : '离职' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="140">
          <template #default="scope">
            <el-button type="link" size="small" @click="editUser(scope.row)">编辑</el-button>
            <el-button v-if="scope.row.username!=='admin'" type="link" size="small" @click="deleteUserRow(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        @current-change="fetchData"
        @size-change="fetchData"
        layout="total, sizes, prev, pager, next, jumper"
        :page-sizes="[10, 20, 50]"
      />
    </el-card>

    <!-- 新增/编辑用户弹窗 -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="500px">
      <!-- 自定义标题，右侧放"修改密码"按钮 -->
      <template #header>
        <span>{{ dialogTitle }}</span>
        <el-button v-if="isEdit" size="small" type="primary" style="float:right" @click="showPwdDialog">修改密码</el-button>
      </template>
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" :disabled="isAdmin" />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" :disabled="isAdmin" />
        </el-form-item>
        <el-form-item label="性别" prop="sex">
          <el-radio-group v-model="form.sex">
            <el-radio label="male">男</el-radio>
            <el-radio label="female">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="手机号" prop="mobile">
          <el-input v-model="form.mobile" :disabled="isAdmin" />
        </el-form-item>
        <el-form-item label="身份证号" prop="id_card">
          <el-input v-model="form.id_card" :disabled="isAdmin" />
        </el-form-item>
        <el-form-item label="入职时间" prop="entry_time">
          <el-date-picker v-model="form.entry_time" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD" />
        </el-form-item>
        <el-form-item label="在职状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio label="active">在职</el-radio>
            <el-radio label="left">离职</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-if="form.status==='left'" label="离职时间" prop="leave_time">
          <el-date-picker v-model="form.leave_time" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD" />
        </el-form-item>
        <el-form-item label="密码" prop="password" v-if="!isEdit">
          <el-input v-model="form.password" type="password" />
        </el-form-item>
        <el-form-item label="角色" prop="role">
          <el-select v-model="form.role" :disabled="isAdmin" placeholder="选择角色" style="width: 100%;">
            <el-option
              v-for="r in roleList"
              :key="r.id"
              :label="r.name"
              :value="r.name"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="组织" prop="org_id">
          <el-select v-model="form.org_id" :disabled="isAdmin" placeholder="选择组织" style="width:100%">
            <el-option v-for="o in orgList" :key="o.id" :label="o.name" :value="o.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="权限" prop="permissions" v-if="!isAdmin">
          <el-select v-model="form.permissions" multiple placeholder="选择权限" style="width:100%">
            <el-option v-for="p in permissionList" :key="p" :label="p" :value="p" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="onSubmit">确定</el-button>
      </template>
    </el-dialog>

    <!-- 角色管理弹窗 -->
    <el-dialog title="角色管理" v-model="roleDialogVisible" width="500px">
      <el-form :model="newRole" ref="roleForm" label-width="80px" :inline="true">
        <el-form-item label="角色名称" prop="name" :rules="[{ required: true, message: '请输入角色名称', trigger: 'blur' }]">
          <el-input v-model="newRole.name" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="addRoleHandler">新增</el-button>
        </el-form-item>
      </el-form>
      <el-table :data="roleList" style="width:100%;margin-top:16px">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="角色名称" />
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="link" size="small" @click="showEditRole(scope.row)">编辑</el-button>
            <el-button type="link" size="small" @click="deleteRoleHandler(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <!-- 编辑角色弹窗 -->
    <el-dialog title="编辑角色" v-model="editRoleDialogVisible" width="600px">
      <el-form :model="editRoleForm" ref="editRoleFormRef" label-width="100px">
        <el-form-item label="角色名称" prop="name" :rules="[{ required: true, message: '请输入角色名称', trigger: 'blur' }]">
          <el-input v-model="editRoleForm.name" />
        </el-form-item>
        <el-form-item label="权限" prop="permissions">
          <el-select v-model="editRoleForm.permissions" multiple placeholder="选择权限" style="width:100%">
            <el-option v-for="p in permissionList" :key="p" :label="p" :value="p" />
          </el-select>
        </el-form-item>
        <el-form-item label="新增权限">
          <el-input v-model="newPerm" placeholder="权限标识，如 device_manage" style="width:60%" />
          <el-button type="primary" size="small" style="margin-left:8px" @click="addPermissionHandler">新增</el-button>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editRoleDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="updateRoleHandler">保存</el-button>
      </template>
    </el-dialog>

    <!-- 修改密码弹窗 -->
    <el-dialog title="修改密码" v-model="pwdDialogVisible" width="400px">
      <el-form :model="pwdForm" :rules="pwdRules" ref="pwdFormRef" label-width="100px">
        <el-form-item label="新密码" prop="password">
          <el-input v-model="pwdForm.password" type="password" />
        </el-form-item>
        <el-form-item label="确认密码" prop="confirm">
          <el-input v-model="pwdForm.confirm" type="password" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="pwdDialogVisible=false">取消</el-button>
        <el-button type="primary" @click="onPwdSubmit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { fetchUserList, addUser, editUser as apiEditUser, deleteUser as apiDeleteUser, assignRole } from '@/api/user'
import { fetchRoleList, addRole as apiAddRole, editRole as apiEditRole, deleteRole as apiDeleteRole } from '@/api/role'
import { fetchPermissionList, setRolePermissions, setUserPermissions, addPermission as apiAddPermission } from '@/api/permission'
import { fetchOrgList } from '@/api/org'
import { ElMessage, ElMessageBox } from 'element-plus'

const userList = ref([])
const loading = ref(false)
const page = ref(1)
const size = ref(10)
const total = ref(0)

const dialogVisible = ref(false)
const dialogTitle = ref('')
const isEdit = ref(false)
const form = reactive({
  id: null,
  username: '',
  name: '',
  password: '',
  sex: 'male',
  mobile: '',
  id_card: '',
  entry_time: '',
  status: 'active',
  leave_time: '',
  role: '',
  org_id: null,
  permissions: []
})
const rules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  mobile: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}
const formRef = ref(null)

// 角色管理
const roleList = ref([])
const roleDialogVisible = ref(false)
const newRole = reactive({ name: '' })
const roleForm = ref(null)

// 编辑角色
const editRoleDialogVisible = ref(false)
const editRoleForm = reactive({ id: null, name: '', permissions: [] })
const editRoleFormRef = ref(null)

// 权限列表
const permissionList = ref([])
const newPerm = ref('')

// 组织列表
const orgList = ref([])

const isAdmin = computed(() => form.username === 'admin')

// 修改密码弹窗逻辑
const pwdDialogVisible = ref(false)
const pwdForm = reactive({ password: '', confirm: '' })
const pwdRules = {
  password: [{ required: true, message: '请输入新密码', trigger: 'blur' }],
  confirm: [{ required: true, message: '请再次输入新密码', trigger: 'blur' },
    { validator: (rule, value, callback) => {
      if (value !== pwdForm.password) {
        callback(new Error('两次密码不一致'))
      } else { callback() }
    }, trigger: 'blur' }
  ]
}
const pwdFormRef = ref(null)

onMounted(() => {
  fetchData()
  fetchRoles()
  fetchAllPermissions()
  loadOrg()
})

function fetchData () {
  loading.value = true
  fetchUserList({ page: page.value, size: size.value }).then(res => {
    userList.value = res.data.list
    total.value = res.data.total
  }).finally(() => { loading.value = false })
}

function loadOrg () {
  fetchOrgList().then(res => { orgList.value = res.data || [] })
}

function showAdd () {
  dialogTitle.value = '新增用户'
  isEdit.value = false
  Object.assign(form, {
    id: null,
    username: '',
    name: '',
    password: '',
    sex: 'male',
    mobile: '',
    id_card: '',
    entry_time: '',
    status: 'active',
    leave_time: '',
    role: '',
    org_id: null,
    permissions: []
  })
  dialogVisible.value = true
}

function editUser (row) {
  dialogTitle.value = '编辑用户'
  isEdit.value = true
  Object.assign(form, { ...row, password: '', permissions: row.permissions || [] })
  dialogVisible.value = true
}

function deleteUserRow (row) {
  if (row.username === 'admin') return // 双保险
  ElMessageBox.confirm('确定删除该用户吗?', '提示', { type: 'warning' }).then(() => {
    apiDeleteUser(row.id).then(() => {
      ElMessage.success('删除成功')
      fetchData()
    }).catch(()=>{})
  }).catch(()=>{})
}

function onSubmit () {
  formRef.value.validate(async (valid) => {
    if (!valid) return
    if (isEdit.value) {
      await apiEditUser(form.id, form)
      // 更新角色映射
      await assignRole(form.id, form.role)
      // 更新个人权限（可选覆盖）
      if (form.permissions && form.permissions.length) {
        await setUserPermissions(form.id, form.permissions)
      }
      ElMessage.success('更新成功')
    } else {
      const res = await addUser(form)
      // 新增后返回用户 ID，若无则重新拉取列表再匹配
      const newUserId = res?.data?.id
      if (newUserId) {
        await assignRole(newUserId, form.role)
        if (form.permissions && form.permissions.length) {
          await setUserPermissions(newUserId, form.permissions)
        }
      }
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    fetchData()
  })
}

function fetchRoles () {
  fetchRoleList().then(res => {
    roleList.value = res.data || []
  })
}

function openRoleDialog () {
  roleDialogVisible.value = true
}

function addRoleHandler () {
  roleForm.value.validate(async (valid) => {
    if (!valid) return
    await apiAddRole(newRole)
    ElMessage.success('新增角色成功')
    newRole.name = ''
    fetchRoles()
  })
}

function showEditRole (row) {
  // 打开编辑弹窗并填充数据
  Object.assign(editRoleForm, { id: row.id, name: row.name, permissions: row.permissions || [] })
  editRoleDialogVisible.value = true
}

function updateRoleHandler () {
  editRoleFormRef.value.validate(async (valid) => {
    if (!valid) return
    const { id, name, permissions } = editRoleForm
    // 更新角色名称
    await apiEditRole(id, { name })
    // 更新角色权限
    await setRolePermissions(id, permissions)
    ElMessage.success('角色已更新')
    editRoleDialogVisible.value = false
    fetchRoles()
  })
}

function deleteRoleHandler (row) {
  ElMessageBox.confirm('确定删除该角色吗?', '提示', { type: 'warning' }).then(async () => {
    await apiDeleteRole(row.id)
    ElMessage.success('删除成功')
    fetchRoles()
  })
}

function fetchAllPermissions () {
  fetchPermissionList().then(res => {
    permissionList.value = res.data || []
  })
}

function addPermissionHandler () {
  if (!newPerm.value) return
  apiAddPermission({ name: newPerm.value }).then(() => {
    ElMessage.success('已添加')
    newPerm.value = ''
    fetchAllPermissions()
  }).catch(err => {
    ElMessage.error(err.message || '添加失败')
  })
}

function showPwdDialog () {
  pwdForm.password = ''
  pwdForm.confirm = ''
  pwdDialogVisible.value = true
}

async function onPwdSubmit () {
  pwdFormRef.value.validate(async (valid) => {
    if (!valid) return
    await apiEditUser(form.id, { password: pwdForm.password })
    ElMessage.success('密码已更新')
    pwdDialogVisible.value = false
  })
}
</script>

<style scoped>
.user-manage-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style>
