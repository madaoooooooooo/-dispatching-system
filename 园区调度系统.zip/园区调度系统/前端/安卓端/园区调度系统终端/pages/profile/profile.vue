<template>
  <view class="profile-container">
    <!-- 自定义导航栏 -->
    <view class="nav-bar">
      <text class="back" @click="goBack">←</text>
      <text class="nav-title">个人中心</text>
    </view>
    <view class="header">
      <image :src="user.avatar" class="avatar" />
      <view class="info">
        <text class="name">{{ user.name }}</text>
        <text v-if="user.team" class="org">{{ user.team }}</text>
      </view>
    </view>

    <view class="actions">
      <button class="btn" @click="changePassword">修改密码</button>
      <button class="btn logout" type="warn" @click="logout">退出登录</button>
    </view>
  </view>
</template>

<script>
import { BASE_URL } from '../../config/index.js'

export default {
  name: 'Profile',
  data() {
    return {
      user: {
        avatar: '/static/avatar.png',
        name: '',
        position: '',
        team: ''
      },
      baseURL: ''
    }
  },
  methods: {
    changePassword() {
      uni.navigateTo({ url: '/pages/profile/change-password' })
    },
    logout() {
      uni.showModal({
        title: '提示',
        content: '确定退出登录？',
        success: (res) => {
          if (res.confirm) {
            uni.clearStorageSync()
            uni.reLaunch({ url: '/pages/login/login' })
          }
        }
      })
    },
    goBack() {
      const pages = getCurrentPages()
      if (pages.length > 1) {
        uni.navigateBack()
      } else {
        uni.switchTab({ url: '/pages/index/index' })
      }
    },
    async fetchProfile() {
      const token = uni.getStorageSync('token')
      if (!token) return
      try {
        const info = uni.getStorageSync('user_info') || {}
        const res = await uni.request({
          url: `${BASE_URL}/api/user/${info.id}`,
          method: 'GET',
          header: { Authorization: `Bearer ${token}` }
        })
        const data = res.data || res[1]?.data
        if (data && data.code === 0) {
          const d = data.data
          this.user.name = d.name
          this.user.position = d.role || ''
          this.user.team = d.org_path || ''
          // 更新缓存，供下次启动使用
          const newCache = { ...uni.getStorageSync('user_info'), ...d }
          uni.setStorageSync('user_info', newCache)
        }
      } catch (e) {
        uni.showToast({ title: '网络错误', icon: 'none' })
      }
    }
  },
  mounted() {
    // 先从缓存加载，提升首屏体验
    const cached = uni.getStorageSync('user_info') || {}
    if (cached) {
      this.user.name = cached.name || ''
      this.user.position = cached.role || ''
      this.user.team = cached.org_path || ''
    }
    this.fetchProfile()
  }
}
</script>

<style lang="scss">
.nav-bar {
  padding-top: var(--status-bar-height);
  height: calc(88rpx + var(--status-bar-height));
  background: #2196f3;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  color: #fff;
  font-size: 32rpx;
}
.back {
  position: absolute;
  left: 30rpx;
  font-size: 40rpx;
  line-height: 1;
}
.nav-title {
  font-weight: bold;
}
.profile-container {
  display: flex;
  flex-direction: column;
  padding: 0;
}
.header {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 60rpx;
  margin-top: 60rpx;
}
.avatar {
  width: 180rpx;
  height: 180rpx;
  border-radius: 50%;
  margin-bottom: 20rpx;
  border: 4rpx solid #eee;
}
.name {
  font-size: 36rpx;
  font-weight: bold;
  display: block;
  text-align: center;
}
.org {
  font-size: 28rpx;
  color: #666;
  margin-top: 8rpx;
  display: block;
}
.actions {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30rpx;
  margin-top: 40rpx;
}
.btn {
  background: #2196f3;
  color: #fff;
  border-radius: 8rpx;
  font-size: 30rpx;
  height: 88rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 60%;
}
.logout {
  background: #f44336;
}
</style> 