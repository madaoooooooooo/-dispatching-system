<template>
	<view class="login-container">
		<!-- 自定义导航栏 -->
		<view class="nav-bar">
			<text class="nav-title">登录</text>
		</view>
		<image class="logo" src="../../static/logo.png" mode="widthFix" />
		<text class="title">园区调度系统终端</text>
		<view class="form-item">
			<input class="input" v-model="form.username" placeholder="请输入用户名" maxlength="50" />
		</view>
		<view class="form-item">
			<input class="input" v-model="form.password" placeholder="请输入密码" password maxlength="50" />
		</view>
		<button class="login-btn" @tap="handleLogin" :loading="loading">登录</button>
	</view>
</template>

<script>
// 登录页脚本部分
import { BASE_URL } from '../../config/index.js'
export default {
	data() {
		return {
			form: {
				username: '',
				password: ''
			},
			loading: false
		}
	},
	methods: {
		// 处理登录按钮点击
		handleLogin() {
			if (!this.form.username || !this.form.password) {
				uni.showToast({ title: '请输入账号和密码', icon: 'none' })
				return
			}
			this.loading = true
			// 调用后端登录接口
			uni.request({
				url: `${BASE_URL}/api/user/login`, // 使用全局配置
				method: 'POST',
				data: this.form,
				header: { 'Content-Type': 'application/json' },
				success: (res) => {
					// 按接口文档：{ code, msg, data: { token, user_info } }
					if (res.statusCode === 200 && res.data?.code === 0) {
						const token = res.data.data?.token
						if (token) {
							// 缓存 token 及用户信息
							uni.setStorageSync('token', token)
							uni.setStorageSync('user_info', res.data.data?.user_info || {})
							uni.showToast({ title: '登录成功', icon: 'success' })
							// 跳转到首页
							uni.reLaunch({ url: '/pages/index/index' })
						} else {
							uni.showToast({ title: '登录返回缺少 token', icon: 'none' })
						}
					} else {
						// 兼容旧格式或错误
						const errMsg = res.data?.msg || res.data?.detail || '登录失败'
						uni.showToast({ title: errMsg, icon: 'none' })
					}
				},
				fail: () => {
					uni.showToast({ title: '请求失败，请检查网络', icon: 'none' })
				},
				complete: () => {
					this.loading = false
				}
			})
		}
	}
}
</script>

<style lang="scss">
.login-container {
	display: flex;
	flex-direction: column;
	align-items: center;
	padding-top: calc(var(--status-bar-height) + 88rpx);
	min-height: 100vh;
	padding: 100rpx 60rpx;
	background: linear-gradient(135deg, #e0f7fa 0%, #ffffff 100%);
}

.logo {
	width: 200rpx;
	margin-bottom: 80rpx;
}

.title {
	font-size: 36rpx;
	font-weight: bold;
	color: #333;
	margin: 40rpx 0 60rpx;
}

.form-item {
	width: 100%;
	margin-bottom: 40rpx;
	box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);

	.input {
		border: 1rpx solid #ccc;
		border-radius: 8rpx;
		padding: 20rpx 24rpx;
		font-size: 28rpx;
	}
}

.login-btn {
	width: 100%;
	background-color: #42b983;
	color: #fff;
	border-radius: 8rpx;
	font-size: 32rpx;
	padding: 20rpx 0;
}

.nav-bar {
	padding-top: var(--status-bar-height);
	height: calc(88rpx + var(--status-bar-height));
	background: #2196f3;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #fff;
	font-size: 32rpx;
}

.nav-title {
	font-weight: bold;
}
</style> 