from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from typing import Optional
from pydantic import BaseModel
from sqlalchemy import func, delete
from datetime import datetime

from 后端.工具.数据库 import 获取会话
from 后端.模型 import User, Permission, Role, UserRole, RolePermission, Organization
from 后端.工具.认证 import 校验密码, 生成密码哈希, 创建令牌

router = APIRouter(prefix="/api/user", tags=["user"])


class 登录请求(BaseModel):
    username: str
    password: str


class 用户创建请求(BaseModel):
    username: str
    password: str
    name: str
    mobile: str
    tel: Optional[str] = None
    sex: str | None = None
    id_card: str | None = None
    entry_time: Optional[str] = None  # ISO 字符串
    role: str
    org_id: Optional[int] = None


class 用户编辑请求(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    name: Optional[str] = None
    mobile: Optional[str] = None
    tel: Optional[str] = None
    sex: Optional[str] = None
    id_card: Optional[str] = None
    entry_time: Optional[str] = None
    leave_time: Optional[str] = None
    status: Optional[str] = None  # active/left
    role: Optional[str] = None
    org_id: Optional[int] = None


@router.post("/login")
def login(data: 登录请求, session: Session = Depends(获取会话)):
    user = session.exec(select(User).where(User.username == data.username)).first()
    if not user or not 校验密码(data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = 创建令牌({"sub": user.username, "id": user.id})
    return {
        "code": 0,
        "msg": "登录成功",
        "data": {
            "token": token,
            "user_info": {
                "id": user.id,
                "username": user.username,
                "name": user.name,
                "role": user.role,
            }
        }
    }


@router.get("/list")
def get_users(page: int = 1, size: int = 20, role: str | None = None, session: Session = Depends(获取会话)):
    """获取用户列表，同时返回每个用户的权限列表。

    权限来源：
    1. 角色权限（通过 UserRole -> Role -> RolePermission）
    2. 针对个人的自定义角色（custom_用户ID）
    返回的数据中将为每个用户对象增加 `permissions` 字段，数组类型。
    """
    query = select(User)
    if role:
        query = query.where(User.role == role)

    count_row = session.exec(select(func.count()).select_from(User)).first()
    total = count_row[0] if isinstance(count_row, (list, tuple)) else count_row

    users = session.exec(query.offset((page - 1) * size).limit(size)).all()
    if not users:
        return {"code": 0, "data": {"total": total, "list": []}}

    # 取出所有 user_id
    user_ids = [u.id for u in users]

    # 查询 UserRole
    ur_rows: list[UserRole] = session.exec(select(UserRole).where(UserRole.user_id.in_(user_ids))).all()
    role_ids = {ur.role_id for ur in ur_rows}

    # 查询角色权限
    rp_rows: list[RolePermission] = []
    if role_ids:
        rp_rows = session.exec(select(RolePermission).where(RolePermission.role_id.in_(role_ids))).all()
    perm_ids = {rp.permission_id for rp in rp_rows}

    # 查询 Permission 表一次性获取名称
    perms_dict = {}
    if perm_ids:
        perm_objs = session.exec(select(Permission).where(Permission.id.in_(perm_ids))).all()
        perms_dict = {p.id: p.name for p in perm_objs}

    # 构造 role_id -> permission names
    role_perm_map: dict[int, list[str]] = {rid: [] for rid in role_ids}
    for rp in rp_rows:
        perm_name = perms_dict.get(rp.permission_id)
        if perm_name:
            role_perm_map[rp.role_id].append(perm_name)

    # 用户自定义权限（custom_用户id）也在 RolePermission 中，已被覆盖

    # 构造最终数据
    user_perm_map: dict[int, list[str]] = {uid: [] for uid in user_ids}
    for ur in ur_rows:
        user_perm_map[ur.user_id].extend(role_perm_map.get(ur.role_id, []))

    data_list = []
    for u in users:
        item = u.dict()
        # 去重权限
        item["permissions"] = list(set(user_perm_map.get(u.id, [])))
        data_list.append(item)

    return {"code": 0, "data": {"total": total, "list": data_list}}


@router.post("/add")
def add_user(data: 用户创建请求, session: Session = Depends(获取会话)):
    # 重名检查
    if session.exec(select(User).where(User.username == data.username)).first():
        raise HTTPException(400, '用户名已存在')

    # 必填校验
    if not data.mobile or not data.name:
        raise HTTPException(400, '姓名、手机号为必填')

    # 确保角色存在并建立映射
    role = session.exec(select(Role).where(Role.name == data.role)).first()
    if not role:
        role = Role(name=data.role)
        session.add(role)
        session.commit()

    def _parse_date(val: Optional[str]):
        if not val:
            return None
        try:
            # 支持 "YYYY-MM-DD" 或完整 ISO 字符串
            return datetime.fromisoformat(val)
        except ValueError:
            return None

    user_kwargs = data.dict(exclude={'password'})
    # 处理日期字段，若解析失败或为空，则移除字段避免写入空字符串
    et = _parse_date(user_kwargs.get('entry_time'))
    lt = _parse_date(user_kwargs.get('leave_time'))
    if et is not None:
        user_kwargs['entry_time'] = et
    else:
        user_kwargs.pop('entry_time', None)
    if lt is not None:
        user_kwargs['leave_time'] = lt
    else:
        user_kwargs.pop('leave_time', None)

    user = User(**{
        **user_kwargs,
        'password_hash': 生成密码哈希(data.password)
    })
    session.add(user)
    session.commit()
    session.add(UserRole(user_id=user.id, role_id=role.id))
    session.commit()
    return {"code": 0, "msg": "创建成功"}


@router.put("/edit/{user_id}")
def edit_user(user_id: int, data: 用户编辑请求, session: Session = Depends(获取会话)):
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    # 管理员账号保护：仅允许修改密码
    if user.username == 'admin':
        allowed_fields = {"password"}
    else:
        allowed_fields = set(data.dict(exclude_unset=True).keys())

    for field, value in data.dict(exclude_unset=True).items():
        if field not in allowed_fields:
            continue
        if field == "password":
            setattr(user, "password_hash", 生成密码哈希(value))
        else:
            setattr(user, field, value)

    # 如果非 admin 或 admin 未尝试修改受限字段时继续
    session.add(user)
    session.commit()
    # 如果 admin 则不处理 role 变更
    if user.username != 'admin' and data.role is not None:
        role = session.exec(select(Role).where(Role.name == data.role)).first()
        if not role:
            role = Role(name=data.role)
            session.add(role)
            session.commit()
        # 删除旧映射
        session.exec(delete(UserRole).where(UserRole.user_id == user_id))
        session.commit()
        session.add(UserRole(user_id=user_id, role_id=role.id))
        session.commit()
    return {"code": 0, "msg": "更新成功"}


@router.delete("/delete/{user_id}")
def delete_user(user_id: int, session: Session = Depends(获取会话)):
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    if user.username == 'admin':
        raise HTTPException(400, "默认管理员账号不可删除")
    session.delete(user)
    session.commit()
    return {"code": 0, "msg": "删除成功"}


@router.get('/{user_id}')
def get_user_detail(user_id: int, session: Session = Depends(获取会话)):
    """获取单个用户详情，用于移动端个人中心。

    返回示例：
    {
        "code": 0,
        "data": {
            "id": 1,
            "username": "handing",
            "name": "韩鼎",
            "role": "调度",
            "org_path": "调度-二组-组长"
        }
    }
    """
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(404, '用户不存在')

    # 计算组织层级路径（如 调度-二组-组长）
    org_path = ''
    if user.org_id:
        # 获取所有 org，一次性减少查询
        org_rows = session.exec(select(Organization)).all()
        org_map = {o.id: o for o in org_rows}
        parts = []
        oid = user.org_id
        # 向上递归
        while oid:
            org_obj = org_map.get(oid)
            if not org_obj:
                break
            parts.append(org_obj.name)
            oid = org_obj.parent_id
        org_path = '-'.join(reversed(parts)) if parts else ''

    return {
        "code": 0,
        "data": {
            "id": user.id,
            "username": user.username,
            "name": user.name,
            "role": user.role,
            "org_path": org_path
        }
    }


# ------------------- 设置用户权限 -------------------

class 权限列表请求(BaseModel):
    permissions: list[str]

@router.post('/set_permissions/{user_id}')
def 设置权限(user_id: int, data: 权限列表请求, session: Session = Depends(获取会话)):
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    # 为用户创建或找到"自定义"角色
    role_name = f"custom_{user_id}"
    role = session.exec(select(Role).where(Role.name == role_name)).first()
    if not role:
        role = Role(name=role_name, description="自定义角色")
        session.add(role)
        session.commit()
    # 清现有 RolePermission
    session.exec(delete(RolePermission).where(RolePermission.role_id == role.id))
    session.commit()
    for perm_name in data.permissions:
        perm = session.exec(select(Permission).where(Permission.name == perm_name)).first()
        if not perm:
            perm = Permission(name=perm_name)
            session.add(perm)
            session.commit()
        session.add(RolePermission(role_id=role.id, permission_id=perm.id))
    # 绑定用户角色
    if not session.exec(select(UserRole).where(UserRole.user_id == user_id, UserRole.role_id == role.id)).first():
        session.add(UserRole(user_id=user_id, role_id=role.id))
    session.commit()
    return {"code": 0, "msg": "权限已更新"}

# ------------------- 分配角色 -------------------

class 分配角色请求(BaseModel):
    role: str

@router.post('/assign_role/{user_id}')
def 分配角色(user_id: int, data: 分配角色请求, session: Session = Depends(获取会话)):
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    role = session.exec(select(Role).where(Role.name == data.role)).first()
    if not role:
        role = Role(name=data.role)
        session.add(role)
        session.commit()
    # 更新映射
    session.exec(delete(UserRole).where(UserRole.user_id == user_id))
    session.commit()
    # 更新 user.role 字段
    user.role = data.role
    session.add(user)
    session.commit()
    session.add(UserRole(user_id=user_id, role_id=role.id))
    session.commit()
    return {"code": 0, "msg": "角色已分配"}

@router.get('/permissions')
def 权限列表(session: Session = Depends(获取会话)):
    """获取所有权限，供前端使用（与 /api/system/permissions 等价）。"""
    perms = session.exec(select(Permission)).all()
    return {"code": 0, "data": [p.name for p in perms]} 