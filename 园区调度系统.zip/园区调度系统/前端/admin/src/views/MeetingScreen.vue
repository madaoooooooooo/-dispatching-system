<template>
  <div class="meeting-manage">
    <el-row :gutter="16">
      <!-- 会议实时列表 -->
      <el-col :span="6">
        <el-card>
          <div class="header">
            <span>实时会议</span>
            <el-button size="small" type="primary" @click="fetchMeetings">刷新</el-button>
          </div>
          <el-table :data="meetings" height="70vh" @row-click="selectMeeting" row-key="id">
            <el-table-column prop="id" label="ID" width="80" />
            <el-table-column prop="title" label="主题" />
            <el-table-column label="人数" width="80">
              <template #default="scope">{{ scope.row.participants?.length || '--' }}</template>
            </el-table-column>
            <el-table-column prop="start_time" label="开始时间" width="160" />
          </el-table>
        </el-card>
      </el-col>

      <!-- 参会者面板 -->
      <el-col :span="8" v-if="current">
        <el-card>
          <div class="header">
            <span>参会者 - {{ current.title }}</span>
            <el-button size="small" @click="openInvite">邀请用户</el-button>
          </div>
          <el-table :data="participants" height="70vh" row-key="id">
            <el-table-column prop="id" label="ID" />
            <el-table-column prop="name" label="昵称" />
            <el-table-column prop="role" label="角色" width="100" />
            <el-table-column label="操作" width="180">
              <template #default="scope">
                <el-button type="link" size="small" @click.stop="remoteCtrl(scope.row,'mute')">静音</el-button>
                <el-button type="link" size="small" @click.stop="remoteCtrl(scope.row,'unmute')">取消静音</el-button>
                <el-button type="link" size="small" @click.stop="kick(scope.row)">踢出</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 会议画面 -->
      <el-col :span="10" v-if="current">
        <el-card>
          <div class="header"><span>会议画面</span></div>
          <iframe v-if="current.jitsi_url" :src="current.jitsi_url" frameborder="0" style="width:100%;height:70vh;"></iframe>
        </el-card>
      </el-col>
    </el-row>

    <!-- 邀请弹窗 -->
    <el-dialog title="邀请用户" v-model="inviteDialog">
      <el-input v-model="inviteUser" placeholder="输入用户名" />
      <template #footer>
        <el-button @click="inviteDialog=false">取消</el-button>
        <el-button type="primary" @click="doInvite">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { fetchLiveMeeting, fetchParticipants, inviteUserToMeeting, kickParticipant, controlParticipant } from '@/api/meeting'
import { ElMessage } from 'element-plus'

const meetings = ref([])
const participants = ref([])
const current = ref(null)

const inviteDialog = ref(false)
const inviteUser = ref('')

onMounted(fetchMeetings)

function fetchMeetings () {
  fetchLiveMeeting().then(res => {
    meetings.value = res.data
  })
}

function selectMeeting (row) {
  current.value = row
  fetchParticipants(row.id).then(res => {
    participants.value = res.data
    // 把人数写回列表可视化
    row.participants = res.data
  })
}

function openInvite () {
  inviteDialog.value = true
  inviteUser.value = ''
}

function doInvite () {
  if (!inviteUser.value) return
  inviteUserToMeeting(current.value.id, inviteUser.value).then(() => {
    ElMessage.success('邀请已发送')
    inviteDialog.value = false
  })
}

function kick (row) {
  kickParticipant(current.value.id, row.id).then(() => {
    ElMessage.success('已踢出')
    selectMeeting(current.value) // 刷新参会者列表
  })
}

function remoteCtrl (row, action) {
  controlParticipant(current.value.id, row.id, action).then(() => {
    ElMessage.success('指令已发送')
  })
}
</script>

<style scoped>
.meeting-manage .header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  font-size: 16px;
}
</style>
