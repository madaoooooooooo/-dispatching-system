from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlmodel import Session, select
import secrets
import logging

from 后端.工具.数据库 import 获取会话
from 后端.第三方.火箭聊天.客户端 import 火箭聊天客户端
from 后端.工具.配置 import get_settings
from 后端.模型 import User

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/rocket/user", tags=["rocket_user"])

# 复用全局客户端逻辑
from 后端.路由.通讯 import get_rc_client  # noqa: E402

class SyncRequest(BaseModel):
    username: str
    name: Optional[str] = None
    password: Optional[str] = None
    email: Optional[str] = None

@router.post('/sync')
def sync_user(data: SyncRequest, session: Session = Depends(获取会话)):
    rc = get_rc_client()

    # 若 password 未提供，随机生成 10 位
    password = data.password or secrets.token_hex(5)

    # 判断 RC 是否已存在
    try:
        info = rc._get('/api/v1/users.info', params={'username': data.username})
        exists = info.get('success')
    except Exception:
        exists = False

    payload = {
        'name': data.name or data.username,
        'username': data.username,
        'password': password,
        'email': data.email or f"{data.username}@local.fake"
    }

    if not exists:
        # 创建
        result = rc._post('/api/v1/users.create', payload)
        if not result.get('success'):
            raise HTTPException(500, f"RC 创建失败: {result}")
        rocket_id = result['user']['_id']
    else:
        # 更新（需要 admin 权限）
        result = rc._post('/api/v1/users.update', {'userId': info['user']['_id'], **payload})
        if not result.get('success'):
            raise HTTPException(500, f"RC 更新失败: {result}")
        rocket_id = info['user']['_id']

    # 可选：写入系统数据库字段，如扩展表，示例略
    return {
        'code': 0,
        'msg': '同步成功',
        'data': {'rocket_user_id': rocket_id, 'password': password if data.password is None else None}
    } 