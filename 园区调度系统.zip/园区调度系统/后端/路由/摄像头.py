"""摄像头接口 (/api/camera/*)
占位实现，便于前端调试。
"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from 后端.模型 import Camera
from 后端.工具.数据库 import 获取会话

router = APIRouter(prefix="/api/camera", tags=["camera"])

class 控制请求(BaseModel):
    action: str  # on/off

@router.get('/list')
def 列表(session: Session = Depends(获取会话)):
    cams = session.exec(select(Camera)).all()
    return {"code": 0, "data": cams}

@router.get('/status/{camera_id}')
def 状态(camera_id: str, session: Session = Depends(获取会话)):
    cam = session.exec(select(Camera).where(Camera.camera_id == camera_id)).first()
    if not cam:
        raise HTTPException(404, "摄像头不存在")
    return {"code": 0, "data": cam}

@router.post('/control/{camera_id}')
def 控制(camera_id: str, data: 控制请求):
    # TODO: 调用实际控制
    return {"code": 0, "msg": f"已向 {camera_id} 发送 {data.action} 指令"}

@router.get('/stream/{camera_id}')
def 视频流(camera_id: str):
    # 返回流地址占位
    return {"code": 0, "data": {"url": f"rtsp://example/{camera_id}"}}

@router.post('/record/{camera_id}')
def 录制(camera_id: str):
    return {"code": 0, "msg": "已开始录制"}

@router.post('/snapshot/{camera_id}')
def 截图(camera_id: str):
    return {"code": 0, "msg": "已截图"}

@router.post('/preset/{camera_id}')
def 预置位(camera_id: str):
    return {"code": 0, "msg": "已调用预置位"} 