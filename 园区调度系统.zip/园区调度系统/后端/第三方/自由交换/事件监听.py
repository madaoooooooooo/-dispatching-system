"""FreeSWITCH 事件监听线程

启动后订阅 CHANNEL_* 事件，并把关键信息通过 广播消息(WebSocket) 发送到前端。
"""
from __future__ import annotations
import asyncio
import logging
import threading
from typing import Callable

try:
    import greenswitch  # type: ignore
except ImportError:
    greenswitch = None  # type: ignore

from 后端.工具.配置 import get_settings
from 后端.路由.推送 import 广播消息

logger = logging.getLogger(__name__)


class FreeSWITCH事件监听器:
    def __init__(self):
        if greenswitch is None:
            raise RuntimeError("未安装 greenswitch")
        s = get_settings()
        self.conn = greenswitch.InboundESL(host=s.freeswitch_host, port=s.freeswitch_port, password=s.freeswitch_password)
        self.conn.connect()
        if not self.conn.is_connected:
            raise ConnectionError("无法连接 FreeSWITCH ESL")
        # 订阅通道事件
        self.conn.send("events plain CHANNEL_CREATE CHANNEL_ANSWER CHANNEL_HANGUP")
        logger.info("已订阅 FreeSWITCH CHANNEL_* 事件")

    def _loop(self, loop: asyncio.AbstractEventLoop):
        while True:
            try:
                e = self.conn.recv()
                if not e:
                    continue
                event_name = e.headers.get("Event-Name") if hasattr(e, 'headers') else None
                uuid = e.headers.get("Unique-ID") if hasattr(e, 'headers') else None
                caller = e.headers.get("Caller-Caller-ID-Number") if hasattr(e, 'headers') else None
                callee = e.headers.get("Caller-Destination-Number") if hasattr(e, 'headers') else None
                timestamp = e.headers.get("Event-Date-Timestamp") if hasattr(e, 'headers') else None
                payload = {
                    "type": "voice_call_event",
                    "data": {
                        "event": event_name,
                        "uuid": uuid,
                        "caller": caller,
                        "callee": callee,
                        "timestamp": timestamp,
                    }
                }
                asyncio.run_coroutine_threadsafe(广播消息(payload), loop)
            except Exception as exc:
                logger.exception("FreeSWITCH 事件监听异常: %s", exc)
                # 简单重连策略
                asyncio.run_coroutine_threadsafe(asyncio.sleep(1), loop)

    def start(self, loop: asyncio.AbstractEventLoop):
        t = threading.Thread(target=self._loop, args=(loop,), daemon=True)
        t.start()
        logger.info("FreeSWITCH 事件监听线程启动")

def 启动事件监听(loop: asyncio.AbstractEventLoop):
    try:
        listener = FreeSWITCH事件监听器()
        listener.start(loop)
    except Exception as e:
        logger.error("启动 FreeSWITCH 事件监听失败: %s", e) 