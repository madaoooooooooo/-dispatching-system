// jitsi.js
// 封装lib-jitsi-meet会议核心逻辑，供会议房间页面调用
// 这里只做最简结构，后续可扩展

let JitsiMeetJS = null
let connection = null
let conference = null
let localTracks = []
let remoteTracks = {}

const JITSI_DOMAIN = '10.10.10.117'
const JITSI_SERVICE_URL = 'wss://10.10.10.117/xmpp-websocket'
const LOCAL_LIB_URL = `https://${JITSI_DOMAIN}:8443/libs/lib-jitsi-meet.min.js`
const FALLBACK_LIB_URL = 'https://meet.jit.si/libs/lib-jitsi-meet.min.js'
const ADAPTER_URL = 'https://webrtc.github.io/adapter/adapter-latest.js'

export async function loadJitsiLib() {
  if (JitsiMeetJS) return JitsiMeetJS
  if (window.JitsiMeetJS) {
    JitsiMeetJS = window.JitsiMeetJS
    return JitsiMeetJS
  }
  function appendScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script')
      script.src = src
      script.onload = () => resolve()
      script.onerror = reject
      document.head.appendChild(script)
    })
  }
  try {
    // 先加载 adapter.js，再加载 lib-jitsi
    await appendScript(ADAPTER_URL)
    await appendScript(LOCAL_LIB_URL)
    JitsiMeetJS = window.JitsiMeetJS
  } catch (e) {
    console.warn('加载本地 Jitsi 库失败，尝试公共 CDN', e)
    await appendScript(ADAPTER_URL)
    await appendScript(FALLBACK_LIB_URL)
    JitsiMeetJS = window.JitsiMeetJS
  }
  return JitsiMeetJS
}

export async function initJitsi({ room, jwt, onLocalTrack, onRemoteTrack, onUserLeft, audioOn = true, videoOn = true }) {
  await loadJitsiLib()
  JitsiMeetJS.init({
    disableAudioLevels: true,
    enableAnalyticsLogging: false,
    externalStorage: false
  })
  connection = new JitsiMeetJS.JitsiConnection(null, jwt, {
    hosts: {
      domain: JITSI_DOMAIN,
      muc: 'conference.' + JITSI_DOMAIN
    },
    serviceUrl: JITSI_SERVICE_URL
  })
  connection.addEventListener(JitsiMeetJS.events.connection.CONNECTION_ESTABLISHED, onConnected)
  connection.addEventListener(JitsiMeetJS.events.connection.CONNECTION_FAILED, (e) => {
    console.error('Jitsi 连接失败', e)
  })
  connection.addEventListener(JitsiMeetJS.events.connection.CONNECTION_DISCONNECTED, () => {})
  connection.connect()

  async function onConnected() {
    console.log('[Jitsi] Connection established, join room')
    conference = connection.initJitsiConference(room, {})
    conference.on(JitsiMeetJS.events.conference.TRACK_ADDED, track => {
      if (track.isLocal()) {
        localTracks.push(track)
        onLocalTrack && onLocalTrack(track)
      } else {
        const id = track.getParticipantId()
        if (!remoteTracks[id]) remoteTracks[id] = []
        remoteTracks[id].push(track)
        onRemoteTrack && onRemoteTrack(track, id)
      }
    })
    conference.on(JitsiMeetJS.events.conference.TRACK_REMOVED, track => {
      if (!track.isLocal()) {
        const id = track.getParticipantId()
        remoteTracks[id] = (remoteTracks[id] || []).filter(t => t !== track)
      }
    })
    conference.on(JitsiMeetJS.events.conference.USER_LEFT, id => {
      delete remoteTracks[id]
      onUserLeft && onUserLeft(id)
    })

    // 先加入房间，再添加本地轨道
    conference.join()

    try {
      const devices = []
      if (audioOn) devices.push('audio')
      if (videoOn) devices.push('video')
      console.log('[Jitsi] createLocalTracks with', devices)
      const tracks = await JitsiMeetJS.createLocalTracks({ devices })
      console.log('[Jitsi] local tracks count', tracks.length)
      tracks.forEach(track => {
        console.log('[Jitsi] got local track', track.getType())
        conference.addTrack(track)
        localTracks.push(track)
        onLocalTrack && onLocalTrack(track)
      })
    } catch (e) {
      console.error('[Jitsi] 创建本地音视频轨道失败', e)
    }
  }
}

export function toggleLocalAudio(mute) {
  localTracks.forEach(track => {
    if (track.getType() === 'audio') {
      mute ? track.mute() : track.unmute()
    }
  })
}

export function toggleLocalVideo(mute) {
  localTracks.forEach(track => {
    if (track.getType() === 'video') {
      mute ? track.mute() : track.unmute()
    }
  })
}

export function leaveConference() {
  if (conference) conference.leave()
  if (connection) connection.disconnect()
  localTracks = []
  remoteTracks = {}
} 