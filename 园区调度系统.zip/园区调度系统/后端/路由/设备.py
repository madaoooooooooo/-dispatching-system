from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlmodel import Session, select
from pydantic import BaseModel
from sqlalchemy import func
from datetime import datetime

from 后端.模型 import Device
from 后端.工具.数据库 import 获取会话

router = APIRouter(prefix="/api/device", tags=["device"])

class 设备状态上报请求(BaseModel):
    device_id: str
    status: str
    battery: Optional[int] = None
    timestamp: Optional[datetime] = None

@router.get('/list')
def 获取设备列表(page: int = 1, size: int = 20, status: Optional[str] = None, type: Optional[str] = None,
            session: Session = Depends(获取会话)):
    query = select(Device)
    if status:
        query = query.where(Device.status == status)
    if type:
        query = query.where(Device.type == type)
    count_row = session.exec(select(func.count()).select_from(Device)).first()
    total = count_row[0] if isinstance(count_row, (list, tuple)) else count_row
    devices = session.exec(query.offset((page-1)*size).limit(size)).all()
    return {"code": 0, "data": {"total": total, "list": devices}}

@router.post('/status')
def 设备状态上报(data: 设备状态上报请求, session: Session = Depends(获取会话)):
    device = session.exec(select(Device).where(Device.device_id == data.device_id)).first()
    if not device:
        device = Device(device_id=data.device_id, name=data.device_id, type='unknown')
    device.status = data.status
    device.battery = data.battery
    device.last_active = data.timestamp or datetime.utcnow()
    session.add(device)
    session.commit()
    return {"code": 0, "msg": "上报成功"}

@router.post('/reboot/{device_id}')
def 远程重启(device_id: str):
    return {"code": 0, "msg": f"已向 {device_id} 下发重启指令"}

# ------------------- 锁定 / 解锁 -------------------

@router.post('/lock/{device_id}')
def 远程锁定(device_id: str):
    return {"code": 0, "msg": f"已向 {device_id} 下发锁定指令"}

@router.post('/unlock/{device_id}')
def 远程解锁(device_id: str):
    return {"code": 0, "msg": f"已向 {device_id} 下发解锁指令"}

# ------------------- 远程配置 -------------------

class 配置请求(BaseModel):
    params: dict

@router.post('/config/{device_id}')
def 远程配置(device_id: str, data: 配置请求):
    # 这里只做示例，实际应保存或下发配置
    return {"code": 0, "msg": "配置已下发", "data": data.params}

# ------------------- 权限 -------------------

@router.get('/permissions/{device_id}')
def 获取设备权限(device_id: str):
    # 示例返回
    return {"code": 0, "data": {"device_id": device_id, "permissions": ["location", "camera"]}}

@router.post('/permissions/{device_id}')
def 设置设备权限(device_id: str, perms: dict):
    return {"code": 0, "msg": "权限已更新"} 