<template>
  <div class="dispatch-container">
    <el-card>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <span style="font-size:18px;">设备调度</span>
        <el-input v-model="keyword" placeholder="搜索设备" style="width:200px;" @input="fetchData" clearable />
      </div>
      <el-table :data="deviceList" style="width:100%;" :loading="loading">
        <el-table-column prop="id" label="ID" width="120" />
        <el-table-column prop="name" label="名称" />
        <el-table-column prop="status" label="状态" width="100" />
        <el-table-column prop="battery" label="电量" width="100" />
        <el-table-column label="操作" width="200">
          <template #default="scope">
            <el-button type="text" size="small" @click="onReboot(scope.row)">重启</el-button>
            <el-button type="text" size="small" @click="onLock(scope.row)">锁定</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        @current-change="fetchData"
        @size-change="fetchData"
        layout="total, sizes, prev, pager, next, jumper"
        :page-sizes="[10,20,50]"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { fetchDeviceList, rebootDevice } from '@/api/device'
import { ElMessage, ElMessageBox } from 'element-plus'

const deviceList = ref([])
const loading = ref(false)
const page = ref(1)
const size = ref(10)
const total = ref(0)
const keyword = ref('')

onMounted(() => {
  fetchData()
})

function fetchData () {
  loading.value = true
  fetchDeviceList({ page: page.value, size: size.value, keyword: keyword.value }).then(res => {
    deviceList.value = res.data.list
    total.value = res.data.total
  }).finally(() => (loading.value = false))
}

function onReboot (row) {
  ElMessageBox.confirm('确认远程重启设备?', '提示', { type: 'warning' }).then(() => {
    rebootDevice(row.id).then(() => {
      ElMessage.success('已下发重启指令')
    })
  })
}

function onLock (row) {
  // 示例：直接弹窗提示，后续可调用接口 lockDevice
  ElMessage.success(`已锁定 ${row.name}`)
}
</script>

<style scoped>
.dispatch-container {
  padding: 24px;
  background: #fff;
  min-height: 100vh;
}
</style>
