// 全局对讲模块，负责维护 WebSocket 与 WebRTC 连接，供任意页面调用
// 使用示例：
// import intercom from '@/common/intercom.js'
// await intercom.init('default')
// intercom.enableMic(true/false)

import { BASE_URL } from '../config/index.js'

// 私有变量
let ws = null
let pc = null
let localStream = null
let roomIdInUse = null
let wsUrlOverride = null
let isInitializing = false
const listeners = [] // 状态监听回调，可在页面中订阅显示
// 由于服务器暂未提供 WebRTC 信令，强制关闭 WebRTC，全部走纯 WebSocket 音频广播
const isWebRTCSupported = false

// ------- 非 WebRTC 录音模式变量 -------
let recorder = null

// 调试打印，避免过度打印（同一信息 2 秒内仅一次）
const lastLogTime = {}
function debugLog(label, msg) {
  const now = Date.now()
  if (!lastLogTime[label] || now - lastLogTime[label] > 2000) {
    console.log(`[Intercom] ${label}:`, msg || '')
    lastLogTime[label] = now
  }
}

function debugToast(label, msg, toastKey) {
  // 2秒内同一类型只弹一次toast
  const now = Date.now()
  if (!lastLogTime[toastKey] || now - lastLogTime[toastKey] > 2000) {
    uni.showToast({ title: label + (msg ? (':' + msg) : ''), icon: 'none', duration: 1200 })
    lastLogTime[toastKey] = now
  }
}

function notify(status) {
  listeners.forEach((fn) => fn(status))
  debugLog('status', status)
  debugToast('状态', status, 'status')
}

// 兼容 App/H5 的 WebSocket 构造
function createWebSocket(url) {
  debugLog('createWS', url)
  // H5环境下强制用原生WebSocket，避免uni.connectSocket兼容性问题
  if (typeof window !== 'undefined' && typeof WebSocket === 'function') {
    return new WebSocket(url)
  }
  // ==== 强制使用 uni.connectSocket，兼容所有小程序 + App-Plus 基座 ====
  if (typeof uni !== 'undefined' && typeof uni.connectSocket === 'function') {
    const task = uni.connectSocket({ url })
    // 0 Connecting, 1 Open, 2 Closing, 3 Closed
    let readyState = 0
    const pending = { open: null, message: null, error: null, close: null }
    const wsLike = {
      send(data) {
        task.send({ data })
      },
      close(code = 1000, reason = '') {
        task.close({ code, reason })
      },
      get readyState() {
        return readyState
      }
    }
    const bind = (method, evt) => {
      if (typeof task[method] === 'function') {
        task[method]((e) => {
          if (evt === 'open') readyState = 1
          if (evt === 'close' || evt === 'error') readyState = 3
          const handler = wsLike[`on${evt}`]
          if (typeof handler === 'function') {
            handler(e)
          } else {
            pending[evt] = e
          }
        })
      }
    }
    ;['open', 'message', 'error', 'close'].forEach((evt) => {
      const methodMap = { open: 'onOpen', message: 'onMessage', error: 'onError', close: 'onClose' }
      bind(methodMap[evt], evt)
      Object.defineProperty(wsLike, `on${evt}`, {
        configurable: true,
        enumerable: true,
        get() { return task[`__handler_${evt}`] || null },
        set(fn) {
          task[`__handler_${evt}`] = fn
          if (pending[evt] && typeof fn === 'function') {
            try { fn(pending[evt]) } catch(e) {}
            pending[evt] = null
          }
        }
      })
    })
    return wsLike
  }
  // 万一 uni.connectSocket 不可用，再尝试标准 WebSocket（H5 调试）
  if (typeof WebSocket === 'function') {
    return new WebSocket(url)
  }
  throw new Error('当前平台不支持 WebSocket')
}

async function init(room = 'default', urlOverride = null) {
  // 若已有稳定连接，直接返回，避免无限重连
  if (roomIdInUse === room && ws && ws.readyState === 1) {
    debugLog('init', '已有连接，直接复用')
    notify('已连接')
    return
  }
  if (isInitializing) {
    debugLog('init', '初始化并发被忽略')
    return
  }
  isInitializing = true
  roomIdInUse = room
  wsUrlOverride = urlOverride
  if (!isWebRTCSupported) {
    // 纯 WebSocket 模式，仅做房间广播
    try {
      const wsUrl = urlOverride || BASE_URL.replace(/^http/, BASE_URL.startsWith('https') ? 'wss' : 'ws') + `/ws/intercom/${room}`
      ws = createWebSocket(wsUrl)
      ws.onopen = () => {
        notify('已连接')
        debugLog('ws', '已连接')
      }
      // 若赋值时连接已经打开，立即手动触发一次
      if (ws.readyState === 1) {
        ws.onopen()
      }
      // 轮询兜底：防止 onopen 丢失
      let tries = 0
      const pollOpen = setInterval(() => {
        if (!ws) { clearInterval(pollOpen); return }
        if (ws.readyState === 1) {
          if (getStatus() !== '已连接') {
            debugLog('ws', '轮询检测到已连接')
            notify('已连接')
          }
          clearInterval(pollOpen)
        } else if (ws.readyState === 3 || ++tries > 20) {
          // 断开或 6 秒超时
          clearInterval(pollOpen)
        }
      }, 300)
      ws.onmessage = (e) => {
        // 直接播放 base64 音频
        try {
          const msg = JSON.parse(e.data)
          if (msg.type === 'audio' && msg.data) {
            const audio = new Audio()
            audio.src = msg.data // dataURL
            audio.play().then(() => {
              debugToast('音频', '已播放', 'audio_played')
            }).catch((err) => {
              debugToast('播放失败', err.message || '未知', 'audio_play_fail')
            })
            debugLog('audio', '收到音频')
          } else if (msg.type === 'welcome') {
            notify('已连接')
            debugLog('ws', '收到 welcome')
          }
        } catch (err) {
          console.error('解析消息失败', err)
        }
      }
      ws.onclose = () => { notify('断开'); debugLog('ws', '断开') }
      ws.onerror = (e) => { notify('异常'); debugLog('ws', '异常:' + e) }
    } catch (e) {
      console.error('intercom 初始化失败', e)
      notify('失败')
    } finally {
      isInitializing = false
    }
    return
  }
  try {
    // 1. 建 WebSocket
    const wsUrl = urlOverride || BASE_URL.replace(/^http/, BASE_URL.startsWith('https') ? 'wss' : 'ws') + `/ws/intercom/${room}`
    ws = createWebSocket(wsUrl)

    // 2. 建 PeerConnection
    pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    })

    pc.onicecandidate = (e) => {
      if (e.candidate) ws.send(JSON.stringify({ type: 'candidate', candidate: e.candidate }))
    }

    pc.ontrack = (e) => {
      const audio = new Audio()
      audio.autoplay = true
      audio.srcObject = e.streams[0]
      audio.play().catch(() => {})
    }

    // 3. 音频轨道
    localStream = await navigator.mediaDevices.getUserMedia({ audio: true })
    const track = localStream.getAudioTracks()[0]
    track.enabled = false // 默认关闭
    pc.addTrack(track)

    // 4. 信令交换
    ws.onopen = async () => {
      notify('已连接')
      debugLog('ws', '已连接')
      const offer = await pc.createOffer()
      await pc.setLocalDescription(offer)
      ws.send(JSON.stringify(pc.localDescription))
    }
    if (ws.readyState === 1) {
      // 手动触发，防止事件丢失
      ws.onopen()
    }
    ws.onmessage = async (e) => {
      const msg = JSON.parse(e.data)
      if (msg.type === 'offer') {
        await pc.setRemoteDescription(msg)
        const ans = await pc.createAnswer()
        await pc.setLocalDescription(ans)
        ws.send(JSON.stringify(pc.localDescription))
      } else if (msg.type === 'answer') {
        await pc.setRemoteDescription(msg)
      } else if (msg.type === 'candidate' && msg.candidate) {
        await pc.addIceCandidate(msg.candidate)
      }
    }
    ws.onclose = () => { notify('断开'); debugLog('ws', '断开') }
    ws.onerror = (e) => { notify('异常'); debugLog('ws', '异常:' + e) }
  } catch (e) {
    console.error('intercom 初始化失败', e)
    notify('失败')
  } finally {
    isInitializing = false
  }
}

function enableMic(flag) {
  if (localStream) localStream.getAudioTracks()[0].enabled = flag

  // 非 WebRTC 模式通过录音实现
  if (!isWebRTCSupported) {
    if (flag) {
      startRecord()
    } else {
      stopRecord()
    }
  }
}

function getStatus() {
  if (!ws) return '未连接'
  const rs = ws.readyState
  if (rs === 0) return '连接中'
  if (rs === 1) return '已连接'
  if (rs === 2) return '关闭中'
  return '已关闭'
}

function watchStatus(cb) {
  if (typeof cb === 'function') listeners.push(cb)
  // 新增：立即把当前状态推送给刚注册的监听器，防止已连接但页面仍显示"连接中"
  try {
    cb && cb(getStatus())
  } catch (e) {}
  return () => {
    const idx = listeners.indexOf(cb)
    if (idx > -1) listeners.splice(idx, 1)
  }
}

function unlockAudio() {
  // 播放一次极短静音，绕过浏览器自动播放限制
  const ctx = new AudioContext()
  const buffer = ctx.createBuffer(1, 22050, 44100)
  const source = ctx.createBufferSource()
  source.buffer = buffer
  source.connect(ctx.destination)
  source.start(0)
}

function disconnect() {
  try {
    if (ws) {
      if (typeof ws.close === 'function') {
        ws.close()
      } else if (typeof ws.abort === 'function') {
        ws.abort()
      }
    }
    if (pc) pc.close()
    if (localStream) {
      localStream.getTracks().forEach((t) => t.stop())
    }
  } catch (e) {
    console.error('intercom 断开失败', e)
  } finally {
    ws = pc = localStream = recorder = null
    notify('已关闭')
  }
}

// ---------- 非 WebRTC 录音 ----------
function startRecord() {
  if (!ws || ws.readyState !== 1) {
    debugToast('未连接', '请先连接服务器', 'not_connected')
    return
  }
  try {
    debugLog('record', '开始录音')
    debugToast('录音', '开始', 'record_start')
    if (typeof plus !== 'undefined' && plus.audio && plus.audio.getRecorder) {
      recorder = plus.audio.getRecorder()
      if (!recorder) {
        debugToast('录音失败', '无recorder', 'recorder_fail')
        // 尝试申请录音权限后重试一次
        if (typeof plus.android !== 'undefined') {
          const Permissions = plus.android.importClass('android.Manifest$permission')
          const main = plus.android.runtimeMainActivity()
          main.requestPermissions
            ? main.requestPermissions([Permissions.RECORD_AUDIO], 111, () => {})
            : plus.android.requestPermissions([Permissions.RECORD_AUDIO], () => {}, () => {})
          setTimeout(startRecord, 500)
        }
        return
      }
      recorder.record({ format: 'aac' }, (path) => {
        debugLog('record', '录音结束，准备发送')
        debugToast('录音', '结束，发送', 'record_end')
        readFileAndSend(path)
      }, (e) => {
        console.error('录音失败', e)
        debugToast('录音失败', e.message || '未知错误', 'record_fail')
      })
    } else if (typeof MediaRecorder !== 'undefined') {
      navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
        recorder = new MediaRecorder(stream)
        const chunks = []
        recorder.ondataavailable = (e) => chunks.push(e.data)
        recorder.onstop = () => {
          debugLog('record', '录音结束，准备发送')
          debugToast('录音', '结束，发送', 'record_end')
          const blob = new Blob(chunks, { type: 'audio/webm' })
          const reader = new FileReader()
          reader.onload = () => {
            sendAudio(reader.result)
          }
          reader.readAsDataURL(blob)
        }
        recorder.start()
      }).catch((e) => {
        debugToast('录音失败', e.message || '无权限', 'record_fail')
      })
    } else {
      debugToast('录音失败', '不支持录音', 'record_fail')
    }
  } catch (e) {
    console.error('开始录音失败', e)
    debugToast('录音失败', e.message || '未知错误', 'record_fail')
  }
}

function stopRecord() {
  if (!recorder) return
  try {
    if (recorder.stop) recorder.stop()
    debugLog('record', '手动停止录音')
    debugToast('录音', '已停止', 'record_stop')
  } catch (e) {
    console.error('停止录音失败', e)
    debugToast('录音失败', e.message || '未知错误', 'record_fail')
  }
}

function readFileAndSend(path) {
  plus.io.resolveLocalFileSystemURL(path, (entry) => {
    entry.file((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        sendAudio(e.target.result)
        entry.remove(
          () => debugLog('file', '已删除临时录音文件'),
          (err) => debugToast('删除录音文件失败', err.message || '未知', 'file_remove_fail')
        )
      }
      reader.readAsDataURL(file)
    })
  })
}

function sendAudio(dataURL) {
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify({ type: 'audio', data: dataURL }))
    debugLog('audio', '发送音频 长度:' + dataURL.length)
    debugToast('音频', '已发送', 'audio_sent')
  } else {
    debugToast('发送失败', '未连接', 'send_fail')
  }
}

export default {
  init,
  enableMic,
  getStatus,
  watchStatus,
  unlockAudio,
  disconnect,
  isWebRTCSupported,
  // 调试专用，暴露内部实例供 DevTools 查看
  __debug: {
    get recorder() {
      return recorder
    }
  }
} 