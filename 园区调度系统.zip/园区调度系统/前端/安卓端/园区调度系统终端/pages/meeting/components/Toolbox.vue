<template>
  <!-- Jitsi Web 风格底部工具栏 -->
  <div class="toolbox-background">
    <button class="toolbox-btn" :class="{ off: !micOn }" @click="$emit('toggle-mic')" title="静音/开麦">
      <span class="emoji">{{ micOn ? '🎙️' : '🔇' }}</span>
    </button>
    <button class="toolbox-btn" :class="{ off: !camOn }" @click="$emit('toggle-cam')" title="摄像头">
      <span class="emoji">{{ camOn ? '📹' : '📷' }}</span>
    </button>
    <button class="toolbox-btn hangup" @click="$emit('hangup')" title="挂断">
      <span class="emoji">📞</span>
    </button>
    <button class="toolbox-btn" @click="$emit('toggle-share')" title="屏幕共享">
      <span class="emoji">🖥️</span>
    </button>
    <button class="toolbox-btn" @click="$emit('toggle-participants')" title="成员列表">
      <span class="emoji">👥</span>
    </button>
    <button class="toolbox-btn" @click="$emit('toggle-more')" title="更多">
      <span class="emoji">⋮</span>
    </button>
  </div>
</template>

<script>
export default {
  name: 'Toolbox',
  props: {
    micOn: { type: Boolean, default: true },
    camOn: { type: Boolean, default: true }
  },
  data () {
    // 官方 svg 地址，如果需要本地请放到 static/jitsi-assets 再替换
    const base = 'https://meet.jit.si/images/';
    return {
      icons: {
        mic: base + 'toolbox/microphone.svg',
        micOff: base + 'toolbox/microphone-disabled.svg',
        cam: base + 'toolbox/camera.svg',
        camOff: base + 'toolbox/camera-disabled.svg',
        hangup: base + 'toolbox/hangup.svg',
        share: base + 'toolbox/screen-share.svg',
        participants: base + 'toolbox/participants.svg',
        more: base + 'toolbox/overflow-menu.svg'
      }
    }
  }
}
</script>

<style scoped>
/* 工具栏整体背景 */
.toolbox-background {
  position: fixed;
  left: 50%;
  bottom: 24px;
  transform: translateX(-50%);
  background: rgba(32, 33, 36, 0.9);
  padding: 8px 14px;
  border-radius: 40px;
  display: flex;
  align-items: center;
  z-index: 900;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
}
/* 单个按钮 */
.toolbox-btn {
  width: 48px;
  height: 48px;
  margin: 0 6px;
  border: none;
  border-radius: 50%;
  background: #3c4043;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.2s;
  padding: 0;
}
/* 按钮 hover / active */
.toolbox-btn:hover { background: #5f6368; }
.toolbox-btn:active { background: #202124; }
/* 麦克风或摄像头关闭态 */
.toolbox-btn.off { background: #a42828; }
/* 挂断按钮红色 */
.toolbox-btn.hangup { background: #d93025; }
.toolbox-btn.hangup:hover { background: #b3261e; }
.emoji { font-size: 24px; line-height: 24px; }
</style> 