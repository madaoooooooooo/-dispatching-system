from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter(prefix="/ws", tags=["intercom-ws"])

rooms: dict[str, set[WebSocket]] = {}

@router.websocket("/intercom/{room_id}")
async def intercom_ws(ws: WebSocket, room_id: str):
    print(f"[WS] 房间 {room_id} 有客户端正在连接…")
    await ws.accept()
    # 发送欢迎消息，供前端确认连接已建立
    await ws.send_json({"type": "welcome"})
    print(f"[WS] 房间 {room_id} 已接受连接")
    peers = rooms.setdefault(room_id, set())
    peers.add(ws)
    try:
        while True:
            data = await ws.receive_text()
            print(f"[WS] 收到消息 len={len(data)}")
            # 简单广播：转发给房间内其他客户端
            for peer in list(peers):
                if peer is not ws:
                    try:
                        await peer.send_text(data)
                    except WebSocketDisconnect:
                        peers.discard(peer)
    except WebSocketDisconnect:
        peers.discard(ws)
        print(f"[WS] 房间 {room_id} 有客户端断开，当前在线 {len(peers)}")
        if not peers:
            rooms.pop(room_id, None) 