from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import Optional, List
from pydantic import BaseModel

from 后端.工具.数据库 import 获取会话
from 后端.模型 import Organization

router = APIRouter(prefix="/api/org", tags=["organization"])

# -------------------- 请求体 --------------------

class OrgCreate(BaseModel):
    name: str
    parent_id: Optional[int] = None
    description: Optional[str] = None

class OrgUpdate(BaseModel):
    name: Optional[str] = None
    parent_id: Optional[int] = None
    description: Optional[str] = None

# -------------------- 工具函数 --------------------

def build_tree(nodes: List[Organization], parent_id: Optional[int] = None):
    tree = []
    for n in nodes:
        if n.parent_id == parent_id:
            children = build_tree(nodes, n.id)
            data = n.dict()
            if children:
                data["children"] = children
            tree.append(data)
    return tree

# -------------------- 接口 --------------------

@router.get("/")
def list_org(session: Session = Depends(获取会话)):
    """获取组织列表（平铺）"""
    orgs = session.exec(select(Organization)).all()
    return {"code": 0, "data": orgs}

@router.get("/tree")
def org_tree(session: Session = Depends(获取会话)):
    """获取组织树结构"""
    orgs = session.exec(select(Organization)).all()
    tree = build_tree(orgs)
    return {"code": 0, "data": tree}

@router.post("/")
def add_org(data: OrgCreate, session: Session = Depends(获取会话)):
    if session.exec(select(Organization).where(Organization.name == data.name)).first():
        raise HTTPException(400, "组织已存在")
    org = Organization(**data.dict())
    session.add(org)
    session.commit()
    return {"code": 0, "msg": "创建成功", "data": {"id": org.id}}

@router.put("/{org_id}")
def edit_org(org_id: int, data: OrgUpdate, session: Session = Depends(获取会话)):
    org = session.get(Organization, org_id)
    if not org:
        raise HTTPException(404, "组织不存在")
    for k, v in data.dict(exclude_unset=True).items():
        setattr(org, k, v)
    session.add(org)
    session.commit()
    return {"code": 0, "msg": "更新成功"}

@router.delete("/{org_id}")
def delete_org(org_id: int, session: Session = Depends(获取会话)):
    org = session.get(Organization, org_id)
    if not org:
        raise HTTPException(404, "组织不存在")
    # 同时删除所有子节点（简单递归）
    def _delete_children(oid):
        children = session.exec(select(Organization).where(Organization.parent_id == oid)).all()
        for c in children:
            _delete_children(c.id)
            session.delete(c)
    _delete_children(org_id)
    session.delete(org)
    session.commit()
    return {"code": 0, "msg": "已删除"} 