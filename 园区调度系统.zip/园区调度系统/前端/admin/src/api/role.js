import request from './request'

// 获取角色列表
export function fetchRoleList(params) {
  return request({
    url: 'system/roles',
    method: 'GET',
    params
  })
}

// 新增角色
export function addRole(data) {
  return request({
    url: 'system/roles',
    method: 'POST',
    data
  })
}

// 编辑角色
export function editRole(roleId, data) {
  return request({
    url: `system/roles/${roleId}`,
    method: 'PUT',
    data
  })
}

// 删除角色
export function deleteRole(roleId) {
  return request({
    url: `system/roles/${roleId}`,
    method: 'DELETE'
  })
} 