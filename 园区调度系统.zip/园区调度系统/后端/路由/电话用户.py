from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
import logging

from 后端.工具.数据库 import 获取会话
from 后端.模型 import SipUser
from 后端.路由.语音 import get_fs_client  # 复用 ESL 客户端

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/phone/user", tags=["phone_user"])

# ------------------- 请求模型 -------------------

class SipUserCreate(BaseModel):
    extension: str
    password: str
    display_name: Optional[str] = None
    bind_user: Optional[int] = None

class SipUserEdit(BaseModel):
    password: Optional[str] = None
    display_name: Optional[str] = None
    bind_user: Optional[int] = None
    status: Optional[str] = None

# ------------------- API -------------------

@router.post("/add")
def add_sip_user(data: SipUserCreate, session: Session = Depends(获取会话)):
    if session.exec(select(SipUser).where(SipUser.extension == data.extension)).first():
        raise HTTPException(400, "分机已存在")
    su = SipUser(**data.dict())
    session.add(su)
    session.commit()
    _reload_freeswitch()
    return {"code": 0, "msg": "创建成功"}

@router.put("/edit/{ext}")
def edit_sip_user(ext: str, data: SipUserEdit, session: Session = Depends(获取会话)):
    su = session.exec(select(SipUser).where(SipUser.extension == ext)).first()
    if not su:
        raise HTTPException(404, "分机不存在")
    for k, v in data.dict(exclude_unset=True).items():
        setattr(su, k, v)
    session.add(su)
    session.commit()
    _reload_freeswitch()
    return {"code": 0, "msg": "更新成功"}

@router.delete("/delete/{ext}")
def delete_sip_user(ext: str, session: Session = Depends(获取会话)):
    su = session.exec(select(SipUser).where(SipUser.extension == ext)).first()
    if not su:
        raise HTTPException(404, "分机不存在")
    session.delete(su)
    session.commit()
    _reload_freeswitch()
    return {"code": 0, "msg": "删除成功"}

@router.get("/list")
def list_sip_users(page: int = 1, size: int = 50, session: Session = Depends(获取会话)):
    total = session.exec(select(SipUser)).count()
    users: List[SipUser] = session.exec(select(SipUser).offset((page-1)*size).limit(size)).all()
    return {"code": 0, "data": {"total": total, "list": users}}

# ------------------- 工具函数 -------------------

def _reload_freeswitch():
    """调用 FreeSWITCH ESL 执行 reloadxml，使分机配置生效。
    仅作示例，如未连接成功则忽略错误。
    """
    try:
        fs = get_fs_client()
        fs.conn.send("api reloadxml")
        logger.info("已执行 FreeSWITCH reloadxml")
    except Exception as e:
        logger.warning("reloadxml 失败：%s", e) 