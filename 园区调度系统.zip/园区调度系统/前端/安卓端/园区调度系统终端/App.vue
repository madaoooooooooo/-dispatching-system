<script>
	import intercom from './common/intercom.js'
	export default {
		onLaunch: function() {
			console.log('App Launch')
			// #ifdef APP-PLUS
			if (typeof plus !== 'undefined') {
				// 取消沉浸式，全屏由系统管理，保留状态栏图标显示。
				try {
					plus.navigator.setFullscreen(false)
				} catch (e) {}
			}
			// 初始化后台对讲，无论是否支持 WebRTC，内部会自动选择合适实现
			intercom.init('default')
			try {
				plus.audio && plus.audio.setSessionCategory && plus.audio.setSessionCategory('Playback')
			} catch (e) {
				console.warn('设置音频会话失败', e)
			}
			// #endif
		},
		onShow: function() {
			console.log('App Show')
			// #ifdef APP-PLUS
			if (typeof window !== 'undefined' && window.addEventListener) {
				// 首次用户交互后解锁自动播放限制
				const unlock = () => {
					intercom.unlockAudio()
					window.removeEventListener && window.removeEventListener('touchstart', unlock, { once: true })
				}
				window.addEventListener('touchstart', unlock, { once: true })
			}
			// #endif
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			// #ifdef APP-PLUS
			// 原沉浸式方法已弃用
			// #endif
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
