import { createStore } from 'vuex'
import { login as apiLogin } from '@/api/user'
import router from '@/router'
import socket from '@/utils/socket'

export default createStore({
  state: {
    token: localStorage.getItem('token') || '',
    userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}')
  },
  mutations: {
    // 设置 token
    SET_TOKEN(state, token) {
      state.token = token
      localStorage.setItem('token', token)
    },
    // 设置用户信息
    SET_USER_INFO(state, info) {
      state.userInfo = info
      localStorage.setItem('userInfo', JSON.stringify(info))
    },
    // 清除登录状态
    CLEAR_AUTH(state) {
      state.token = ''
      state.userInfo = {}
      localStorage.removeItem('token')
      localStorage.removeItem('userInfo')
    }
  },
  actions: {
    // 登录
    async login({ commit }, payload) {
      const res = await apiLogin(payload)
      // 登录成功后保存 token 和 userInfo
      commit('SET_TOKEN', res.data.token)
      commit('SET_USER_INFO', res.data.user_info)
      // 建立 WebSocket 连接
      socket.connect(res.data.token)
      router.push('/')
    },
    // 登出
    logout({ commit }) {
      commit('CLEAR_AUTH')
      // 关闭 WebSocket
      if (socket.ws) { socket.ws.close() }
      router.push('/login')
    }
  },
  getters: {
    isLogin: (state) => !!state.token
  },
  modules: {}
}) 