import { createRouter, createWebHistory, RouterView } from 'vue-router'

import Dashboard from '../views/Dashboard.vue'
// 体积较大的页面改为懒加载，以防第三方库（Cesium 等）在主包中初始化报错导致白屏
const Map = () => import(/* webpackChunkName: "map" */ '../views/Map.vue')
const MeetingScreen = () => import(/* webpackChunkName: "meeting" */ '../views/MeetingScreen.vue')
const Dispatch = () => import(/* webpackChunkName: "dispatch" */ '../views/Dispatch.vue')
const Alarm = () => import(/* webpackChunkName: "alarm" */ '../views/Alarm.vue')
const DocumentConfig = () => import(/* webpackChunkName: "document" */ '../views/DocumentConfig.vue')
const UserManage = () => import(/* webpackChunkName: "user" */ '../views/UserManage.vue')
const OrgManage = () => import(/* webpackChunkName: "org" */ '../views/OrgManage.vue')
const RoleManage = () => import(/* webpackChunkName: "role" */ '../views/RoleManage.vue')
import Login from '../views/Login.vue'

const routes = [
  { path: '/login', component: Login },
  { path: '/', component: Dashboard, meta: { requiresAuth: true } },
  { path: '/map', component: Map, meta: { requiresAuth: true } },
  { path: '/meeting', component: MeetingScreen, meta: { requiresAuth: true } },
  { path: '/dispatch', component: Dispatch, meta: { requiresAuth: true } },
  { path: '/alarm', component: Alarm, meta: { requiresAuth: true } },
  { path: '/document', component: DocumentConfig, meta: { requiresAuth: true } },
  {
    path: '/user',
    // 直接使用官方提供的 RouterView 组件作为占位，可避免 h('router-view') 名称解析失败
    component: RouterView,
    meta: { requiresAuth: true },
    redirect: '/user/profile',
    children: [
      { path: 'profile', component: UserManage, meta: { requiresAuth: true } },
      { path: 'org', component: OrgManage, meta: { requiresAuth: true } },
      { path: 'role', component: RoleManage, meta: { requiresAuth: true } }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由全局守卫：未登录时重定向到登录页
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  if (to.path === '/login') {
    return next()
  }
  if (to.meta.requiresAuth && !token) {
    return next('/login')
  }
  next()
})

export default router 