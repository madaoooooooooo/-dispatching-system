import request from './request'

// 获取系统权限列表
export function fetchPermissionList() {
  return request({
    url: 'user/permissions',
    method: 'GET'
  }).catch((err) => {
    // 若后端未实现返回 404，则返回空权限列表以保证前端可用
    console.warn('fetchPermissionList error:', err.message)
    return { data: [] }
  })
}

// 设置角色权限
export function setRolePermissions(roleId, permissions) {
  return request({
    url: `system/roles/${roleId}/set_permissions`,
    method: 'POST',
    data: { permissions }
  })
}

// 设置用户权限（如需直接配置到用户）
export function setUserPermissions(userId, permissions) {
  return request({
    url: `user/set_permissions/${userId}`,
    method: 'POST',
    data: { permissions }
  })
}

// 新增权限
export function addPermission(data) {
  return request({
    url: 'system/permissions',
    method: 'POST',
    data
  })
} 